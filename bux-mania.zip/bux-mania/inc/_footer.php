
<html>

<div class="clr"></div>

            

        </div> <!-- content -->


    </div> <!-- wrap -->

    <br>
<center>
<div class="column_3" id="hidden_link" onclick="document.all.hidden_link1.style.display='block';" display:yes">
<?php
include "_bonlink2.php";
?>
</div>

</center>
    <br>
    <!-- footer -->
  <center>  
<table width="1015" height="140" border="1" align="center" bgcolor="#FFFFFF" style="margin-top:10px; margin-bottom:30px; border:1px solid #CCCCCC;box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);">
<tr>
<td height="88" colspan="2" align="center" class="header">
<div style="float:left; margin-top:20px; margin-left:20px">
<a href="/"><img src="/style/img/nav-logo.png" width="250" height="60" /></a>
<br clear="all" style="" /><div class="actionmen"><b><font color="#2c7394">������ �������� �������</b></font></div>
</div>
<table width="100%" border="3" align="left" class="table_stat">
<tr align="center">


<a href="http://www.free-kassa.ru"><img src="//www.free-kassa.ru/img/fk_btn/13.png" title="����� �������� �� �����"></a>
<a href="https://payeer.com/?partner=10646164" target="_blank"><img src="https://php-scripts.ru/wp-content/uploads/2019/07/ed14ad3d7aa0.png"  border="0" alt="������� � PAYEER ������"></a>
<a href="https://vk.com" target="_blank"><img src="/img/vk.gif" width="88" height="31" style="border-radius:3px"></a>
<a href="https://shop-empire.info" target="_blank"><img src="https://monrichgames.ru/img/rich-88.gif" /></a>
<a target="_blank" href="https://shop-empire.info"><img src="http://redsurf.ru/bn/1.gif" width="88" height="31" style="border-radius:3px"></a> <br>
<br>&copy; B�e �pa�a 3a���e��!. &nbsp; 2019 </br>
                ����������� � ������������� ���������� ������� ����� �����������!
</td>
</tr>
</table></center>
            </div>

           
            <div class="f_col2">
                <!-- ass  -->
            </div>
            
        </div>
    </div>

    

    

    

<!--     <div class="row">
        <div style="height: 263px; width: 263px;" class="circleGraphic1">75</div>
        <div style="height: 263px; width: 263px;" class="circleGraphic2">50</div>
        <div style="height: 263px; width: 263px;" class="circleGraphic3">20</div>
        <div style="height: 263px; width: 263px;" class="circleGraphic4">67</div>
    </div> -->

   </html>