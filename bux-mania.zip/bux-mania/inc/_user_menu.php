

<link rel="stylesheet" href="/style/bootstrap.min.css">
 
<div class="accmenu">
     <div class="title-box" data-open="1" status="2" onclick="$(this).next('.ul-box').toggle();"><?=$_SESSION["user"]; ?></div>
        <div class="balansmenu">
	<div>��������� ������: <font color="orange">{!BALANCE_B!} <i class="fa fa-rouble" style="width:16px;"></i></font></a></div>
	<div>�������� ������: <font color="orange">{!BALANCE_P!} <i class="fa fa-rouble" style="width:16px;"></i></font></a></div>
       
<center><p><table align="center">
    <tr>
        <td><a href="/account/insert" class="bt1" style="color: white">���������</a></td>
        <td><a href="/account/swap" class="bt3" style="color: white">�����</a></td>
        <td><a href="/account/payment" class="bt2" style="color: white">�������</a></td><br>
    </tr>
</table></p></center>
</div>

<div class="actionmen"> 
<div class="title-box" data-open="1" status="2" onclick="$(this).next('.ul-box').toggle();">�������� ����</div>  
<div><a href="/account/serfing" class="sombra"><i class="fa fa-link"></i> �������� ������</a></div>
<div><a href="/account/serfingb" class="sombra"><i class="fa fa-picture-o"></i> �������� ��������</a></div>
<div><a href="/account/serfingy" class="sombra"><i class="fa fa-youtube"></i> YouTube �������</a></div>
<div><a href="/account/mails" class="sombra"><i class="fa fa-envelope-open-o"></i> ������ �����</a></div>
<div><a href="/account/bonus" class="sombra"><i class="fa fa-gift"></i> ���������� �����</a></div>
<!--div><a href="/quests" class="sombra"><i class="fa fa-calendar-check-o user_menu_i"></i> �������</a></div-->
<!--div><a href="/penny" class="sombra"><i class="fa fa-themeisle"></i> ���� ��� �����</a></div-->
<div><a href="/account/lottery" class="sombra"><i class="fa fa-gamepad user_menu_i" aria-hidden="true"></i> ������� <span style="font-size:13px; color: #F44336; font-weight: bold;">NEW</span></a></div>
<div><a href="/account/pin" class="sombra"><i class="fa fa-lock user_menu_i"></i> ���-����</a></div>
<div><a href="/account" class="sombra"><i class="fa fa-bars" style="font-size: 16px;"></i> ��� �������</a></div>
<div><a href="/account/referals" class="sombra"><i class="fa fa-users"></i> ��� ��������</a></div>
<!--div><a href="/account/refleader" class="sombra"><i class="fa fa-users"></i> ������� ��������</a></div-->
<div><a href="/konkurs_ref" class="sombra"><i class="fa fa-star-half-o"></i> ������� ��������� <span style="font-size:13px; color: #F44336; font-weight: bold;">NEW</span></a></div>
<div><a href="/konkurs_adv" class="sombra"><i class="fa fa-star-half-o"></i> ������� �������������� <!--span style="font-size:13px; color: #F44336; font-weight: bold;">NEW</span--></a></div>
<div><a href="/account/config" class="sombra"><i class="fa fa-cog"></i> ���������</a></div>
<div><a href="/account/exit" class="sombra"><i class="fa fa-sign-out user_menu_i"></i><b>�����</b></a></div><b>  
</b></div><b>
</br>
	<div class="actionmen">
    <div class="title-box" data-open="1" status="2" onclick="$(this).next('.ul-box').toggle();">M���</div>  
<div><a href="/" class="sombra">�������</a></div>
<div><a href="/news" class="sombra">�������</a></div>
<div><a href="/about" class="sombra">� �������</a></div>
<div><a href="/statistic" class="sombra">����������</a></div>
<div><a href="/rules" class="sombra">�������</a></div>
<div><a href="/faq" class="sombra">�������</a></div>
<div><a href="/contacts" class="sombra">��������</a></div>
</b></div><b>
   </br>
<style>
.nume_serf {
    position: relative;
    color: #8BC34A;
    left: 50px;
    z-index: 1;
    top: 0px;
    font-weight: bold;
}
.nume_serfy {
    position: relative;
    color: #8BC34A;
    left: 50px;
    z-index: 1;
    top: 0px;
    font-weight: bold;
}
.nume_serfb {
    position: relative;
    color: #8BC34A;
    left: 30px;
    z-index: 1;
    top: 0px;
    font-weight: bold;
}
.bt1 {
    background: #369544;
    padding: 5px 10px;
    color: #7b5436;
    border-radius: 3px;
    margin-right: 5px;
    font: 14px "Comfortaa";
}
.bt1:hover {

	background: #58c167;
        border: none;
        color: #7b5436;
	text-decoration: none;
       font: 14px "Comfortaa";
}
.bt3 {
    background: #3F51B5;
    padding: 5px 10px;
    color: #fff;
    border-radius: 3px;
    margin-right: 5px;
    font: 14px "Comfortaa";
}
.bt3:hover {

	background: #2c7394;
        border: none;
        color: #7b5436;
	text-decoration: none;
       font: 14px "Comfortaa";
}
.bt2 {
    color: #fff;
    background: #F44336;
    padding: 5px 10px;
    border-radius: 3px;
    font: 14px "Comfortaa";
}
.bt2:hover {

	background: #f5584c;
        border: none;
        color: #7b5436;
	text-decoration: none;
       font: 14px "Comfortaa";
}

</style>




<style>
.h-titleleft2 {
    background-image: linear-gradient(45deg, #f4eccc00 0%, #39a50000 100%);
}
.h-titleleft2 {
    width: 235px;
    height: 40px;
    border-radius: 20px;
    text-align: left;
    text-transform: uppercase;
    font-family: "Ariel";
    font-size: 25px;
    color: #ff0057;
    margin: 0px 0 -20px 35px;
    padding: 12px 5px 5px 35px;
}
.actionmen {
    margin-bottom: 0px;
    */margin-left: 20px;*/
}
.actionmen a {
    background-image: linear-gradient(45deg, #f4fcfb 0%, #25313D 100%);
    /*border-radius: 80% 20% 83% 17% / 0% 60% 40% 100%;*/
    /*box-shadow: inset rgba(95, 95, 95, 0.6) 0 -2px 5px, inset rgba(252,255,255,.7) 0 3px 8px, rgba(86, 86, 86, 0.8) 0 3px 8px -3px;*/
}
.actionmen a:hover {
    background: #232f37;
    /*border-radius: 80% 20% 83% 17% / 0% 60% 40% 100%;*/
    /*box-shadow: inset rgba(95, 95, 95, 0.6) 0 -2px 5px, inset rgba(252,255,255,.7) 0 3px 8px, rgba(86, 86, 86, 0.8) 0 3px 8px -3px;*/
}

.actionmen a {
    text-align: left;
    width: 230px;
    background: #4687b3;
    padding: 5px 0px 8px 20px;
    font-size: 16px;
    text-decoration: none;
    margin: 2px;
    color: #eef;
    display: inline-block;
    margin-left: -1px;
    font-weight: normal;
}
.actionmen img {
margin: 0 3px -3px 4px;
    height: 25px;
    padding: 0 10px 0 0px;
}
.sombra {
    text-shadow: 0 3px 3px rgba(84, 82, 82, 0.18);
}

</style>
<style>
.balansmenu {
margin: 12 auto;
line-height: 33px;
text-align: center;
color: #eef;
font-size: 16px;
}
	.st{
		background: url(/style/star.png) no-repeat;
		width: 50px;
		height:50px;
		font-size: 12px;text-align: center;float: left;
		position:relative;
		top: 29px;
		margin-left: -10px;
	}
.title-box {
    position: relative;
    height: 30px;
    line-height: 30px;
    background: #4682B4;
    margin-top: 10px;
    margin-left: -11px;
    margin-bottom: 10px;
    padding-left: 10px;
    color: #fff;
    font-weight: bold;
    width: 80%;
    z-index: 10;
    font-size: 22px;
    font-family: "BebasBook";
    letter-spacing: 2px;
}
.title-box:before {
    position: absolute;
    content: '';
    left: 0;
    top: 30px;
    border: 10px solid transparent;
    border-top: 5px solid #4169E1;
    border-right: 1px;
}
.title-box:after {
    position: absolute;
    content: '';
    right: -10px;
    top: 0;
    border: 15px solid #4682B4;
    border-right: 10px solid transparent;
    border-left: 1px;
}
</style></div>