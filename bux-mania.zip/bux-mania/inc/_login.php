


<div class="autoriz" style="padding: 0px 0px 0px;">
	 <form action="" method="post" autocomplete="off">

            	<input type="hidden" name="csrf_token" value="73f97bc8a8c283793433a941575c55a1">
	<center><div class="h-titleleft">�����������</div></center>	
	<style>


#error {
border-color: #EE2327;
}
.alert {
color: #191A18;
margin: 5px 0;
padding: 8px 35px 8px 14px;
text-shadow: 0px 1px 0px rgba(255, 255, 255, 0.5);
background-color: #FCF8E3;
border: 2px solid #3Aa73D;
border-radius: 2px;
}
</style>


<?PHP

	if(isset($_POST["log_email"])){
	
	$lmail = $func->IsMail($_POST["log_email"]);
	
		if($lmail !== false){
		
			$db->Query("SELECT id, user, pass, referer_id, banned FROM db_users_a WHERE email = '$lmail'");
			if($db->NumRows() == 1){
			
			$log_data = $db->FetchArray();

                            $post_pass = $func->md5Password($_POST["pass"]);
			
				if(strtolower($log_data["pass"]) == strtolower($post_pass)){
				
					if($log_data["banned"] == 0){
						
						# ������� ���������
						$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '".$log_data["id"]."'");
						$refs = $db->FetchRow();
						
						$db->Query("UPDATE db_users_a SET referals = '$refs', date_login = '".time()."', ip = INET_ATON('".$func->UserIP."') WHERE id = '".$log_data["id"]."'");
						
						$_SESSION["user_id"] = $log_data["id"];
						$_SESSION["user"] = $log_data["user"];
						$_SESSION["referer_id"] = $log_data["referer_id"];
						Header("Location: /account");
						
					}else echo "<center><div class='alert' id='error'>������� ������������</div></center>";
				
				}else echo "<center><div class='alert' id='error'>������ ������ �������</div></center>";
			
			}else echo "<center><div class='alert' id='error'>��������� Email �� ��������������� � �������</div></center>";
			
		}else echo "<center><div class='alert' id='error'>Email ������ �������</div></center>";
	
	}

?>







   <center> <input name="log_email" id="log_1" type="email" style="padding: 7px 14px 7px 34px;width: 240px;height: 40px;background-color: rgba(255, 255, 255, 0.3);" required size="23" maxlength="35" onfocus="if (this.value == 'Email') this.value = '';" onblur="if (this.value == '') this.value = 'Email';" value="Email" class="lg"/></center>
 
  
  
  <center><input name="pass" id="log_2" type="password" style="padding: 7px 14px 7px 34px;width: 240px;height: 40px;background-color: rgba(255, 255, 255, 0.3);" required size="23" maxlength="35" onfocus="if (this.value == '������') this.value = '';" onblur="if (this.value == '') this.value = '������';" value="������" class="ps"/></center>

  



  <center><br></center>
 
 <center>  <input type="submit" value="�����" style="width: 76%;" class="btn_in"/></center>
<center><a href="/recovery"><font style="color:#23201F;">������ ������?</font></a></center>
  
 </form>
<a class="regsadasdasdf" href="/signup">�����������</a>
</div>	

<div class="actionmen">
   <center>  <b>***M���***</b></center> 
<div><a href="/" class="sombra">������</a></div>  
<div><a href="/news" class="sombra">�������</a></div>
<div><a href="/about" class="sombra">� �������</a></div>
<div><a href="/statistic" class="sombra">����������</a></div>
<div><a href="/rules" class="sombra">�������</a></div>
<div><a href="/faq" class="sombra">�������</a></div>
<div><a href="/contacts" class="sombra">��������</a></div>

</b></div><b>
</br>	
	
<style>
.actionmen {
    margin-bottom: 0px;
    */margin-left: 20px;*/
}
.actionmen a {
    background-image: linear-gradient(45deg, #f4fcfb 0%, #25313D 100%);
    /*border-radius: 80% 20% 83% 17% / 0% 60% 40% 100%;*/
    /*box-shadow: inset rgba(95, 95, 95, 0.6) 0 -2px 5px, inset rgba(252,255,255,.7) 0 3px 8px, rgba(86, 86, 86, 0.8) 0 3px 8px -3px;*/
}
.actionmen a:hover {
    background: #232f37;
    /*border-radius: 80% 20% 83% 17% / 0% 60% 40% 100%;*/
    /*box-shadow: inset rgba(95, 95, 95, 0.6) 0 -2px 5px, inset rgba(252,255,255,.7) 0 3px 8px, rgba(86, 86, 86, 0.8) 0 3px 8px -3px;*/
}

.actionmen a {
    text-align: left;
    width: 230px;
    background: #4687b3;
    padding: 5px 0px 8px 20px;
    font-size: 16px;
    text-decoration: none;
    margin: 2px;
    color: #eef;
    display: inline-block;
    margin-left: -1px;
    font-weight: normal;
}
.actionmen img {
margin: 0 3px -3px 4px;
    height: 25px;
    padding: 0 10px 0 0px;
}
.sombra {
    text-shadow: 0 3px 3px rgba(84, 82, 82, 0.18);
}

</style>
