﻿<center><b>Ваш баланс успешно пополнен</b>
<BR /><a href="/account">Перейти в аккаунт</a>
</center>