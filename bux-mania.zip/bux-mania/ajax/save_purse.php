<?php
session_start();

$usid = $_SESSION["user_id"];

# Константа для Include
define("CONST_RUFUS", true);

# Автоподгрузка классов
function __autoload($name){ include($_SERVER['DOCUMENT_ROOT']."/classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);


# Проверка кошелька

$error = '';
$ps = $_POST['system'];

if (empty($ps) || !isset($_POST['purse'])) {
    $error = 'Переданы не все параметры';
}
$purse = $_POST['purse'];

$availableSystems = array('payeer', 'yandex', 'qiwi', 'visa', 'mastercard', 'maestro', 'beeline', 'megafon', 'mts', 'tele2');

if (!in_array($ps, $availableSystems)) {
    $error = 'Система указана неверно';
} elseif ($_POST['ps'] == 'payeer') {
    if (substr($purse,0,1) != "P" || !preg_match("#^[0-9]{7,8}$#", substr($purse,1))) {
        $error = 'Кошелек указан неверно';
    }
} elseif ($_POST['ps'] == 'yandex') {
    if (!preg_match("#^41001[0-9]{7,10}$#", $purse)) {
        $error = 'Кошелек указан неверно';
    }
} elseif ($_POST['ps'] == 'qiwi') {
    if (!preg_match("#^\+(91|994|82|372|375|374|44|998|972|66|90|81|1|507|7|77|380|371|370|996|9955|992|373|84)[0-9]{6,14}$#",$purse)) {
        $error = 'Кошелек указан неверно';
    }
} elseif (in_array($_POST['ps'], array('beeline', 'megafon', 'mts', 'tele2'))) {
    if (!preg_match("#^[\+]{1}[7]{1}[9]{1}[\d]{9}$#", $purse)) {
        $error = 'Кошелек указан неверно';
    }
} elseif ($_POST['ps'] == 'visa') {
    if (!preg_match("#^([45]{1}[\d]{15}|[6]{1}[\d]{17})$#", $purse)) {
        $error = 'Кошелек указан неверно';
    }
} elseif ($_POST['ps'] == 'mastercard') {
    if (!preg_match("#^([45]{1}[\d]{15}|[6]{1}[\d]{17})$#", $purse)) {
        $error = 'Кошелек указан неверно';
    }
} elseif ($_POST['ps'] == 'maestro') {
    if (!preg_match("#^([45]{1}[\d]{15}|[6]{1}[\d]{15,17})$#", $purse)) {
        $error = 'Кошелек указан неверно';
    }
} else {
    $db->Query("SELECT * FROM `db_users_purse` WHERE `purse` = '{$purse}' AND `system` = '{$ps}'");
    if ($db->NumRows() != 0) {
        $error = 'Данный кошелек уже используется';
    } else {
        $db->Query("SELECT * FROM `db_users_purse` WHERE `user_id` = '{$usid}' AND `system` = '{$ps}'");
        if ($db->NumRows() != 0) {
            $error = 'Для редактирования обратитесь в поддержку';
        }
    }
}

if ($error != '') {
    die(json_encode(array(
        'status' => 'error',
        'message' => $error
    )));
}

# Сохранение кошелька
$db->Query("INSERT INTO `db_users_purse` (`user_id`, `system`, `purse`) VALUES ('$usid', '$ps', '$purse')");

die(json_encode(array(
    'status' => 'success',
    'message' => 'Сохранено'
)));
