<?PHP
$_OPTIMIZATION["title"] = "�������";
$_OPTIMIZATION["description"] = "��������� �������";
$_OPTIMIZATION["keywords"] = "��������� ������� �������";
?>

<div class="s-bk-lf">
	<div class="acc-title">��������� ���������</div>
</div>
<div class="silver-bk">
<div class="clr"></div>

<center>
<img src="/img/piar-link.png" style="vertical-align:-2px; margin-right:5px;" /><font style="font-weight: bold; color: #159420;">���� ���.������: </font><font style="font-weight: bold; color: #351594;">http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/?i=<?=$_SESSION["user_id"]; ?></font>
<center>

<BR/>

<center>
<font color="#ed6b00"><h3>������ 468x60:</h></font><p>
<img src="/img/mesbox/468x60_2.gif">
<br>
<textarea onmouseover="this.select()" style="width: 495px; height: 55px;">&lt;a href="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/?i=<?=$_SESSION["user_id"]; ?>" target="_blank"&gt;
&lt;img src="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/img/mesbox/468x60_2.gif" /&gt;&lt;/a&gt;
</textarea>
<br>
</center>
	
<center>
<font color="#ed6b00"><h3>������ 468�60:</h></font><p>
<img src="/img/mesbox/468x60.gif">
<br>
<textarea onmouseover="this.select()" style="width: 495px; height: 55px;">&lt;a href="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/?i=<?=$_SESSION["user_id"]; ?>" target="_blank"&gt;
&lt;img src="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/img/mesbox/468x60.gif" /&gt;&lt;/a&gt;
</textarea>
<br></center>

<center>
<font color="#ed6b00"><h3>������ 200�300:</h></font><p>
<img src="/img/mesbox/200x300_2.gif">
<br>
<textarea onmouseover="this.select()" style="width: 495px; height: 55px;">&lt;a href="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/?i=<?=$_SESSION["user_id"]; ?>" target="_blank"&gt;
&lt;img src="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/img/mesbox/200x300_2.gif" /&gt;&lt;/a&gt;
</textarea>
<br>
</center>

<center>
<font color="#ed6b00"><h3>������ 200�300:</h></font><p>
<img src="/img/mesbox/200x300.gif">
<br>
<textarea onmouseover="this.select()" style="width: 495px; height: 55px;">&lt;a href="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/?i=<?=$_SESSION["user_id"]; ?>" target="_blank"&gt;
&lt;img src="http://<? echo htmlspecialchars($_SERVER['HTTP_HOST']); ?>/img/mesbox/200x300.gif" /&gt;&lt;/a&gt;
</textarea>
<br>
</center>

<div class="clr"></div>
</div>



<div class="clr"></div>	
							<br>
							<br>
							</div>
						<div class="clr"></div>