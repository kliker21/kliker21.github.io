

<?php
/*
 * ������ ��� �����
 * ������: 1.00
 * SKYPE: sereega393
 * ������������� ��� ������ ���������!!!
*/
define('TIME', time());

header("Content-Type: text/html; charset=windows-1251");

$db->Query("SELECT * FROM db_users_a WHERE id = '".$_SESSION['user_id']."'");
$users_info = $db->FetchAssoc();

if (isset($_GET['delete']))
{
  $id = (int)$_GET['delete'];
  
  if (isset($_SESSION['admin']))
  {
    $db->query("SELECT money, user_name FROM db_mails WHERE id = '".$id."' LIMIT 1");
 
    $result = $db->FetchAssoc();
  
    $db->query("UPDATE db_users_b SET money_b = money_b + '".$result['money']."' WHERE user = '".$result['user_name']."'");
  
    $db->query("DELETE FROM db_mails WHERE id = '".$id."'");
    $db->query("DELETE FROM db_mails_view WHERE ident = '".$id."'");
  }  
} 
?>
<script>
 
function getHTTPRequest()
{
    var req = false;
    try {
        req = new XMLHttpRequest();
    } catch(err) {
        try {
            req = new ActiveXObject("MsXML2.XMLHTTP");
        } catch(err) {
            try {
                req = new ActiveXObject("Microsoft.XMLHTTP");
            } catch(err) {
                req = false;
            }
        }
    }
    return req;
}

jQuery(document).ready(function(){
    $(".normalm").click(function(e){
        var oLeft = 0, oTop = 0;
        element = this;
        if (element.className == 'normalm') {
            do {
                oLeft += element.offsetLeft;
                oTop  += element.offsetTop;
            } while (element = element.offsetParent);
            var sx = e.pageX - oLeft;
            var sy = e.pageY - oTop;
            var elid = $(this).attr("id");
            fixed(elid, sx, sy);
        }
    }); 
})               

function closewin(mid)
{
    $.modal.close();
    return false;
}

function fixed(p1, p2, p3)
{
    var myReq = getHTTPRequest();
    var params = "p1="+p1+"&p2="+p2+"&p3="+p3;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = myReq.responseText;
            if (resvalue != '') {
                if (resvalue.length > 12) {
                    if (elem = document.getElementById(p1)) {
                        elem.style.backgroundImage = 'none';
                        elem.className = 'goadvsite';
                        elem.innerHTML = "<span style='color: #82BA00;'>������� �� �����</span>";
                    }
                    document.getElementById('rmail').innerHTML = resvalue;
                    document.getElementById('rmail').style.display = '';
                    $('#basic-modal-content').modal();
                    
                } else {
                    if (elem = document.getElementById(resvalue)) {
                        $(elem).fadeOut('low', function() {
                            elem.innerHTML = "<td colspan='3'></td>";
                        });
                    }
                }
            }
        }
    }
    myReq.open("POST", "/ajax/us-fixedmails.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}
</script> 
<div id="basic-modal-content">
                <div id="rmail"></div>
            </div>
<link rel="stylesheet" href="/style/main.css" type="text/css" />
<link type='text/css' href='/style/guibasic3.css' rel='stylesheet' media='screen' />
<script type='text/javascript' src='/js/jquery.simplemodal.js'></script>
<script type='text/javascript' src='/js/guibasic.js'></script>
<div class="s-bk-lf">
	<div class="acc-title">������ �����</div>

<BR />
</div>
<div class="silver-bk">
  <?php
  $count_link = 0;
  
  $db->query("SELECT ident, time_add FROM db_mails_view WHERE user_id = '".$_SESSION['user_id']."'");
 
  while ($row_view = $db->FetchAssoc())
  {
    $visits[$row_view['ident']] = $row_view;    
  }      
     
  $db->query("SELECT * FROM  db_mails WHERE money >= price and status = '2'  ORDER BY high DESC, time_add DESC");
  
  if ($db->NumRows())
  {     
    $html = '<p style="text-align: center;">�����������, ����� ������ ��������������</p>';
    $html = $html.'<table class="work-serf">'; 
    
    while ($row = $db->FetchAssoc())
    {
      if ($row['mailmode'] == 1)
      {        
        if (isset($visits[$row['id']]) && (strtotime($visits[$row['id']]['time_add']) + 24*60*60) > TIME) 
        { 
          continue;
        }  
      }
      else
      {
        if (isset($visits[$row['id']]) && (strtotime($visits[$row['id']]['time_add']) + 30*24*60*60) > TIME) 
        { 
          continue;
        }  
      }        
     
      if ($row['speed'] > 1) 
      {             
        if (mt_rand(1, $row['speed']) != 1) continue;
      } 
      
      $price = $row['price'];
           
      $pay_user = number_format($price - ($price * (20/100)), 2); //������ ������������
      
      $high = ($row['high'] == 1) ? 'mailimghigh' : 'mailimg';
      
            
      $html = $html.'<tr id="tr'.$row['id'].'">';
      $html = $html.'<td class="normal" width="40" valign="top">';
      $html = $html.'<span id="adstatus'.$row['id'].'" class="'.$high.'" title="�������: '.$row['id'].', �������������: '.$row['user_id'].' | '.$row['url'].'"></span>';
      $html = $html.'</td>';
      $html = $html.'<td id="'.$row['id'].'" class="normalm" valign="top">';
      $html = $html.'<span id="m'.$row['id'].'" style="line-height: 3">'.$row['title'].'</span>';
      $html = $html.'</td>';
      $html = $html.'<td class="normal" nowrap="nowrap" valign="top" style="width: 60px; text-align: right; padding-right: 10px;">';
      $html = $html.'<span class="smoolgray" title="�������� �����">('.number_format($row['money']/$row['price'], 0, '.', '').')</span>&nbsp;<span class="clickprice">'.$pay_user.'&nbsp;�</span><br />';
      $html = $html.'<a class="workvir" href="http://online.us.drweb.com/result/?url='.$row['url'].'" title="��������� ������ �� ������" target="_blank"></a>';
      $html = $html.'</td>';
      $html = $html.'</tr>';
      
            
      $count_link ++;
    }    
    $html = $html.'</table>';    
  }
  
  
  if ($count_link) 
  { 
    echo $html; 
  }
  
    ?> 	 
    <center><a href="/account/mails/add" class="button-green-big" style="margin-top:10px;">������� ��������</a></center>
  <center><a href="/account/mails/cabinet" class="button-green-big" style="margin-top:10px;">��� ������</a></center>
        <?php
  
  ?>
</div>
 	
	<div class="clr"></div>	
							<br>
							<br>
							</div>
						<div class="clr"></div>