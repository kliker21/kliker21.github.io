<div class="s-bk-lf">
	<div class="acc-title">�������� �������</div>
</div>
<div class="silver-bk">


<style>
.menu_sh {
    width: 16.66%;
    text-align: center;
    float: left;
    margin: 5px 0;
}
.menu_sh a {
    background: #608AB9;
    margin-top: 0;
    color: #FFFFFF;
    width: 96%;
    padding: 4px 1px;
}
</style>

	<div class="menu_sh">			
		<a href="/account/serfing/add" class="btns btn btn-default ">
			<i class="fa fa-eye"></i> �������
		</a>
	</div>
        <div class="menu_sh">			
		<a href="/account/serfingy/add" class="btns btn btn-default active_url">
			<i class="fa fa-youtube"></i> YouTube
                </a>
	</div>
	<!--div class="menu_sh">			
		<a href="/account/task" class="btns btn btn-default ">
			<i class="fa fa-calendar-check-o"></i> �������
		</a>
	</div>
	<div class="menu_sh">			
		<a href="/account/loto" class="btns btn btn-default ">
			<i class="fa fa-gavel"></i> �������
                </a>
	</div>
	<div class="menu_sh">			
		<a href="/account/dep" class="btns btn btn-default ">
			<i class="fa fa-money"></i> �������
		</a>
	</div-->



</div>							<div class="clr"></div>	
							<br>
							<br>
							</div>
						<div class="clr"></div>