<div class="s-bk-lf">
	<div class="acc-title">� �����</div>
</div>
<div class="silver-bk"><div class="clr"></div>	



<?PHP

	if(isset($_POST["tx"])){
	
		$db->Query("UPDATE db_conabrul SET about = '".mysql_real_escape_string($_POST["tx"])."' WHERE id = '1'");
		echo "<center><font color = 'green'><b>���������</b></font></center><BR />";
	}

$db->Query("SELECT * FROM db_conabrul WHERE id = '1'");
$data = $db->FetchArray();
?>

<form action="" method="post">
<textarea name="tx" cols="78" rows="25"><?=$data["about"]; ?></textarea>
<BR /><BR />
<center><input type="submit" value="���������" /></center>
</form>
</div>
<div class="clr"></div>	<div class="clr"></div>	
							<br>
							<br>
							</div>
						<div class="clr"></div>