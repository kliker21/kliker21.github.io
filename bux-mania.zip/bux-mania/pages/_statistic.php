<?PHP
$_OPTIMIZATION["title"] = "��� 10 �� ������/�������";
$_OPTIMIZATION["description"] = "��� 10 �� ������/�������";
$_OPTIMIZATION["keywords"] = "��� 10, �� ������, �� �������";
?>

<?PHP
$tfstats = time() - 60*60*24;
$db->Query("SELECT 
(SELECT COUNT(*) FROM db_users_a) all_users,
(SELECT SUM(insert_sum) FROM db_users_b) all_insert, 
(SELECT SUM(payment_sum) FROM db_users_b) all_payment, 
(SELECT COUNT(*) FROM db_users_a WHERE date_reg > '$tfstats') new_users");
$stats_data = $db->FetchArray();
?>

<style>
.sdfsdgdfsf {
    font-family: "Comfortaa";
    font-size: 23px;
    color: #2c2c2c;
    background: #cccccc;
    display: block;
    margin: 30px 0px 0px 0px;
    position: relative;
    padding: 0px 20px 0px 20px;
    border: 1px solid #333;
    border-radius: 10px 10px 0px 0px;
    border-bottom: 0px solid #333;
    box-shadow: 0px 0px 12px 0px #333;
}
.content1 {
    border: 1px solid #CCCCCC;
    width: 650px;
    margin: 0 auto;
    min-height: 147px;
}
.container2 {
    margin-right: auto;
    margin-left: auto;
    /*padding-right: 15px;*/
    /*padding-left: 15px;*/
}
.col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-xs-1, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9, .col-xs-10, .col-xs-11, .col-xs-12 {
    min-height: 1px;
    padding-right: 15px;
    padding-left: 15px;
}
.course__price-item {
    margin: 15px;
}
.course__price-kind {
    float: left;
}
.course__price-value {
    float: right;
}
.course__price-item:before {
    top: 6px;
    right: 30%;
    left: 30%;
    content: '';
    border-top: 1px dashed #cadce3;
}
.course__price-item:after {
    display: table;
    clear: both;
    content: '';
}
</style>

<div class="s-bk-lf">
	<div class="acc-title">T��-10</div>
</div>
<div class="silver-bk">


<div class="sdfsdgdfsf" align="center">����� ���������� �������</div>
<div class="content1">
        <div class="container2">
      
      <div class="col-md-6">
       <div class="course__price" style="margin-bottom:15px;">
        <div class="course__price-item">
          <div class="course__price-kind"><i class="fa fa-users stats_i_1" aria-hidden="true"></i> ����� ����������:</div>
          <div class="course__price-value"><?=$stats_data["all_users"]; ?> ���.</div>
        </div>
        <div class="course__price-item">
          <div class="course__price-kind"><i class="fa fa-clock-o stats_i_2" aria-hidden="true"></i> ����� �� 24 ����:</div>
          <div class="course__price-value"><?=$stats_data["new_users"]; ?> ���.</div>
        </div>
      </div>
    </div>

<div class="col-md-6">
      <div class="course__price" style="margin-bottom:15px;">
        <div class="course__price-item">
          <div class="course__price-kind"><i class="fa fa-money stats_i_1" aria-hidden="true"></i> ����� ����������:</div>
          <div class="course__price-value"><?=sprintf("%.2f",$stats_data["all_insert"])*0.9; ?> ���.</div>
        </div>
        <div class="course__price-item">
          <div class="course__price-kind"><i class="fa fa-credit-card stats_i_1" aria-hidden="true"></i> ����� ������:</div>
          <div class="course__price-value"><?=sprintf("%.2f",$stats_data["all_payment"]); ?> ���.</div>
        </div>
 <div class="course__price-item">
          <div class="course__price-kind"><i class="fa fa-calendar stats_i_3" aria-hidden="true"></i> �� ��������:</div>
          <div class="course__price-value"><?=intval(((time() - $config->SYSTEM_START_TIME) / 86400 )+1); ?> ����</div>
        </div>
      </div>
    </div>
</div>
    </div>



        <div class="sdfsdgdfsf" align="center">��� - 10 �� ���������</div>
        <div class="content1">

        <table class="bordered" style="width:100%;margin-bottom:15px;">
            <thead>
            <tr>
              <th>�����</th>
              <th>���� �����������</th>
              <th>���������</th>
            </tr>
            </thead>
            <tbody>
<?php
	$db->Query("SELECT * FROM `db_users_a` ORDER BY referals DESC LIMIT 10 ");
	while($data = $db->FetchArray()){
	?><tr>
                  <td align="center"><?=$data["user"]; ?></td>
                  <td align="center"><?=date("d/m/Y � H:i",$data["date_reg"]); ?></td>
                  <td align="center"><?=$data["referals"]; ?> ���.</td>
              </tr>
	<?PHP
	}
?>
	  </tbody></table>
            </div>

<BR />


        <div class="sdfsdgdfsf" align="center">��� - 10 �� ������</div>
        <div class="content1">

        <table class="bordered" style="width:100%;margin-bottom:15px;">
            <thead>
            <tr>
              <th>�����</th>
              <th>���� �����������</th>
              <th>���������</th>
            </tr>
            </thead>
            <tbody  align="center">
<?php
	$db->Query("SELECT * FROM `db_users_b`,`db_users_a` WHERE db_users_b.id = db_users_a.id ORDER BY db_users_b.payment_sum DESC LIMIT 10 ");
	while($data = $db->FetchArray()){
	?><tr>
                  <td><?=$data["user"]; ?></td>
                  <td><?=date("d/m/Y � H:i",$data["date_reg"]); ?></td>
                  <td><?=sprintf("%.2f",$data["payment_sum"]); ?> ���.</td>
              </tr>
	<?PHP
	}
?></tbody></table>
            </div>

<BR />


        <div class="sdfsdgdfsf" align="center">��� - 10 �� ����������</div>
        <div class="content1">

        <table class="bordered" style="width:100%;margin-bottom:15px;">
            <thead>
            <tr>
              <th>�����</th>
              <th>���� �����������</th>
              <th>��������</th>
            </tr>
            </thead>
            <tbody  align="center">
<?php
	$db->Query("SELECT * FROM `db_users_b`,`db_users_a` WHERE db_users_b.id = db_users_a.id ORDER BY `referals` DESC LIMIT 10 ");
	
while($data = $db->FetchArray()){
	?>

               <tr>
                  <td><?=$data["user"]; ?></td>
                  <td><?=date("d/m/Y � H:i",$data["date_reg"]); ?></td>
                  <td><?=sprintf("%.2f",$data["from_referals"])*0.01; ?> ���.</td>
              </tr>
	<?PHP
	}
?> </tbody></table>
            </div>
<BR />


        <div class="sdfsdgdfsf" align="center">��������� 10 ����������</div>
        <div class="content1">

        <table class="bordered" style="width:100%;">
            <thead>
            <tr>
              <th>�����</th>
              <th>���� ����������</th>
              <th>�����</th>
            </tr>
            </thead>
            <tbody align="center">

<?PHP	
$db->Query("SELECT * FROM db_insert_money, db_users_a  WHERE  db_users_a.user = db_insert_money.user ORDER BY db_insert_money.date_add DESC LIMIT 10");
	while($data = $db->FetchArray()){
?>
<tr>
                  <td><?=$data["user"]; ?></td>
                  <td><?=date("d/m/Y � H:i",$data["date_add"]); ?></td>
                  <td><?=sprintf("%.2f",$data["money"]); ?> ���.</td>
              </tr>

	<?PHP
	}
?>
</tbody></table>

            </div> 

<br/>




       <div class="sdfsdgdfsf" align="center">��������� 10 ������</div>
       <div class="content1">
     
        <table class="bordered" style="width:100%;" text-align: "center">
            <thead>
            <tr>
              <th>�����</th>
              <th>���� �������</th>
              <th>�����</th>
            </tr>
            </thead>
            <tbody  align="center">
<?PHP

$all_pay_sum=0;
$dt = time() - 60*60*48;
$db->Query("SELECT * FROM db_payment, db_users_a  WHERE db_payment.status = '3' AND db_users_a.user = db_payment.user ORDER BY db_payment.date_add DESC LIMIT 10");
	while($data = $db->FetchArray()){
	
	$all_pay_sum += $data["serebro"]/100;
?>
		<tr>
                  <td><?=$data["user"]; ?></td>
                  <td><?=date("d/m/Y � H:i",$data["date_add"]); ?></td>
                  <td><?=sprintf("%.2f",$data["sum"]); ?> ���.</td>
              </tr>
	<?PHP
	}
?></tbody></table>
            </div>

<BR />

      
<div class="clr"></div>
</div>

<div class="clr"></div>	
							<br>
							<br>
							</div>
						<div class="clr"></div>