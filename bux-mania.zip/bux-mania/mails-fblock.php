<?php
define('TIME', time());
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);
session_start();
if (!isset($_SESSION['user_id'])) { exit(); }

if (isset($_GET['cnt']) && isset($_SESSION['view']['id']) && isset($_SESSION['view']['timer']) && $_GET['cnt'] == $_SESSION['view']['cnt'])
{
  ?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
  <head>
   <link rel="stylesheet" href="/style/style-serf.css" type="text/css" />
   <script type="text/javascript">
   function getHTTPRequest()
{
    var req = false;
    try {
        req = new XMLHttpRequest();
    } catch(err) {
        try {
            req = new ActiveXObject("MsXML2.XMLHTTP");
        } catch(err) {
            try {
                req = new ActiveXObject("Microsoft.XMLHTTP");
            } catch(err) {
                req = false;
            }
        }
    }
    return req;
}

function startClock() {
    if (vtime == stattime) {
        document.getElementById('blockwait').style.display = 'none';
        document.getElementById('blocktimer').style.display = '';
    }
    if (vtime >= 0) {
        document.forms['frm'].clock.value = vtime;
        vtime --;
        tm = setTimeout("startClock(0)", 1000);
    } else {
        if (tm)
            clearTimeout(tm);
        nextstep(0, cnt);
    }
}
                        
function vernum(vnum) {
    nextstep(vnum, cnt);
    return false;
}

function nextstep(num, cnt)
{
    var myReq = getHTTPRequest();
    var params = "num="+num+"&cnt="+cnt;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = myReq.responseText;
            if (resvalue != '') {
                if (resvalue.substr(0, 2) == 'OK') {
                    vars = resvalue.split(";"); 
                    document.getElementById("blockverify").innerHTML = '<div class="blocksuccess">������� �� ���������!<br /><span>����� �� ������ ������ ('+vars[1]+' ���.) ���������</span></div>';
                    if ((vars[2] != '0')&&(vars[2].length > 1)) {
                        setTimeout("top.location = '"+vars[2]+"'", 500);
                    }
                } else
                if (resvalue == '0')
                    document.getElementById("blockverify").innerHTML = '<div class="blockerror">�������� �� �����������</div>';
                else
                    document.getElementById("blockverify").innerHTML = resvalue;
            }
        } else {
            document.getElementById("blockverify").innerHTML = "<span class='loading' title='��������� ����������...'></span>";
        }
    }
    myReq.open("POST", "/ajax/us-stepmail.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}
   </script>
   <script type="text/javascript" language="JavaScript">
       var vtime = stattime = <?php echo $_SESSION['view']['timer']; ?>;
       var cnt = '<?php echo $_SESSION['view']['cnt']; ?>';
   </script>
  </head>
  <body>
   <table class="serfframe" border="0" cellspacing="0" cellpadding="0">
    <tr>
     <td>
      <div id="blockverify">
       <div id="blockwait">
       </div>
       <div id="blocktimer" style="display: none;">
        <form class="clockalert" name="frm" method="post" action="" onsubmit="return false;">
         <input name="clock" size="3" readonly="readonly" type="text" value=""/>
        </form>
       </div>
      </div>
     </td>
     <td align="right" class="footer" width="500" height="60">
      <div id="linkslot_257573"><script src="https://linkslot.ru/bancode.php?id=257573" async></script></div>
     </td>
    </tr>
   </table>
  </body>
  </html>
  <?php
}
?>