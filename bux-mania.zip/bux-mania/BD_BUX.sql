-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Авг 08 2019 г., 12:37
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `balahou5_test22`
--

-- --------------------------------------------------------

--
-- Структура таблицы `db_advpic`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_advpic`;
CREATE TABLE `db_advpic` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(20) NOT NULL DEFAULT '',
  `sum` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `url` varchar(50) NOT NULL DEFAULT '',
  `banner` varchar(80) NOT NULL DEFAULT '/img/468x60.jpg',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `days` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `db_bonus_list`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_bonus_list`;
CREATE TABLE `db_bonus_list` (
  `id` int(11) NOT NULL,
  `user` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_bonus_list`
--

INSERT INTO `db_bonus_list` (`id`, `user`, `user_id`, `sum`, `date_add`, `date_del`) VALUES
(327, 'thuynguyen', 167, 34, 1565235334, 1565321734),
(307, 'mehanic', 90, 31, 1565182612, 1565269012),
(310, 'elenaek', 128, 19, 1565184974, 1565271374),
(312, 'Olga36', 190, 2, 1565186295, 1565272695),
(313, 'sarovs', 118, 17, 1565190641, 1565277041),
(320, 'lara1955', 104, 25, 1565219189, 1565305589),
(318, 'szmassiel', 169, 5, 1565210617, 1565297017),
(305, 'Quelepso', 7, 7, 1565176707, 1565263107),
(306, 'ranaadnan0', 198, 10, 1565177197, 1565263597),
(321, 'CTEPXXX', 200, 1, 1565223704, 1565310104),
(319, 'mkjnb', 121, 14, 1565217942, 1565304342),
(322, 'cosmo', 21, 57, 1565232345, 1565318745),
(301, 'soko', 182, 14, 1565171020, 1565257420),
(300, 'Chooddy', 74, 15, 1565169932, 1565256332),
(299, 'vipppp', 196, 14, 1565169289, 1565255689),
(298, 'SherriQQ5', 197, 3, 1565169274, 1565255674),
(303, 'daokeke', 23, 13, 1565173443, 1565259843),
(302, 'lexa1970', 24, 44, 1565171029, 1565257429),
(309, 'Evelina', 76, 41, 1565183992, 1565270392),
(297, 'Pando', 137, 4, 1565161642, 1565248042),
(308, 'samiramis', 100, 1, 1565183976, 1565270376),
(311, 'vavka', 199, 2, 1565185160, 1565271560),
(314, 'Perri', 9, 1, 1565192627, 1565279027),
(316, 'kolyamba67', 202, 54, 1565208173, 1565294573),
(315, 'Chincho', 81, 18, 1565195076, 1565281476),
(317, 'mpp131', 181, 13, 1565208503, 1565294903),
(326, 'toropoffig', 47, 21, 1565234433, 1565320833),
(325, 'Chungdurkm', 110, 54, 1565233973, 1565320373),
(324, 'juando', 129, 46, 1565232969, 1565319369),
(323, 'gbh2294', 176, 65, 1565232741, 1565319141),
(304, 'Gorelka55', 117, 9, 1565175648, 1565262048),
(328, 'DIGMA5366', 166, 2, 1565235380, 1565321780),
(329, 'Guleke', 183, 29, 1565241338, 1565327738);

-- --------------------------------------------------------

--
-- Структура таблицы `db_bonus_list3`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_bonus_list3`;
CREATE TABLE `db_bonus_list3` (
  `id` int(11) NOT NULL,
  `user` varchar(10) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_bonus_list3`
--

INSERT INTO `db_bonus_list3` (`id`, `user`, `user_id`, `sum`, `date_add`, `date_del`) VALUES
(798, 'cosmo', 21, 4, 1565255872, 1565257672);

-- --------------------------------------------------------

--
-- Структура таблицы `db_bonus_list4`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_bonus_list4`;
CREATE TABLE `db_bonus_list4` (
  `id` int(11) NOT NULL,
  `user` varchar(10) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_bonus_list4`
--

INSERT INTO `db_bonus_list4` (`id`, `user`, `user_id`, `sum`, `date_add`, `date_del`) VALUES
(315, 'gbh2294', 176, 11, 1565248471, 1565252071);

-- --------------------------------------------------------

--
-- Структура таблицы `db_bonus_list5`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_bonus_list5`;
CREATE TABLE `db_bonus_list5` (
  `id` int(11) NOT NULL,
  `user` varchar(10) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_bonus_list5`
--

INSERT INTO `db_bonus_list5` (`id`, `user`, `user_id`, `sum`, `date_add`, `date_del`) VALUES
(292, 'Chungdurkm', 110, 11, 1565233995, 1565255595),
(293, 'Chooddy', 74, 4, 1565241012, 1565262612),
(295, 'cosmo', 21, 13, 1565252265, 1565273865),
(294, 'Guleke', 183, 5, 1565241291, 1565262891),
(291, 'juando', 129, 3, 1565232997, 1565254597),
(290, 'gbh2294', 176, 9, 1565232750, 1565254350);

-- --------------------------------------------------------

--
-- Структура таблицы `db_bonus_list6`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_bonus_list6`;
CREATE TABLE `db_bonus_list6` (
  `id` int(11) NOT NULL,
  `user` varchar(10) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_bonus_list6`
--

INSERT INTO `db_bonus_list6` (`id`, `user`, `user_id`, `sum`, `date_add`, `date_del`) VALUES
(243, 'Guleke', 183, 4, 1565241319, 1565284519),
(234, 'mpp131', 181, 32, 1565208487, 1565251687),
(236, 'Pando', 137, 23, 1565222091, 1565265291),
(241, 'Chungdurkm', 110, 3, 1565234003, 1565277203),
(242, 'Chooddy', 74, 2, 1565241022, 1565284222),
(240, 'juando', 129, 5, 1565233009, 1565276209),
(239, 'gbh2294', 176, 17, 1565232754, 1565275954),
(235, 'kolyamba67', 202, 3, 1565210312, 1565253512),
(238, 'cosmo', 21, 2, 1565232345, 1565275545),
(237, 'daokeke', 23, 3, 1565225696, 1565268896);

-- --------------------------------------------------------

--
-- Структура таблицы `db_chat_message`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_chat_message`;
CREATE TABLE `db_chat_message` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(255) NOT NULL DEFAULT '',
  `user_to_id` int(11) NOT NULL DEFAULT '0',
  `user_to_name` varchar(255) CHARACTER SET cp1250 NOT NULL DEFAULT '',
  `time_add` int(11) NOT NULL DEFAULT '0',
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `message` tinytext NOT NULL,
  `ava` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_chat_online`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_chat_online`;
CREATE TABLE `db_chat_online` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `color` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `time_add` int(11) NOT NULL DEFAULT '0',
  `ava` varchar(255) NOT NULL DEFAULT '',
  `banan` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_competition`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_competition`;
CREATE TABLE `db_competition` (
  `id` int(11) NOT NULL,
  `1m` double NOT NULL DEFAULT '0',
  `2m` double NOT NULL DEFAULT '0',
  `3m` double NOT NULL DEFAULT '0',
  `user_1` varchar(10) NOT NULL,
  `user_2` varchar(10) NOT NULL,
  `user_3` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_end` int(11) NOT NULL DEFAULT '0',
  `priz_1` double NOT NULL DEFAULT '0',
  `priz_2` double NOT NULL DEFAULT '0',
  `priz_3` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_competition`
--

INSERT INTO `db_competition` (`id`, `1m`, `2m`, `3m`, `user_1`, `user_2`, `user_3`, `status`, `date_add`, `date_end`, `priz_1`, `priz_2`, `priz_3`) VALUES
(1, 15, 10, 5, 'WMonitor', 'iskrime', 'Pando', 1, 1564516148, 1565120948, 405, 100, 25);

-- --------------------------------------------------------

--
-- Структура таблицы `db_competition_users`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_competition_users`;
CREATE TABLE `db_competition_users` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_conabrul`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_conabrul`;
CREATE TABLE `db_conabrul` (
  `id` int(11) NOT NULL,
  `rules` text NOT NULL,
  `about` text NOT NULL,
  `contacts` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_conabrul`
--

INSERT INTO `db_conabrul` (`id`, `rules`, `about`, `contacts`) VALUES
(1, '<p><strong>1. ОБЩИЕ ПОЛОЖЕНИЯ</strong><br /><strong>1.1.</strong><span>&nbsp;Зарегистрировавшись на проекте, Вы соглашаетесь с данными правилами в полном объеме.</span><br /><strong>1.2.</strong><span>&nbsp;Администрация не несет ответственности за возможный ущерб, нанесенный Вам в результате использования данного проекта.</span><br /><strong>1.3.</strong><span>&nbsp;В случае игнорирования данных правил или их несоблюдения аккаунт подлежит блокировке.</span><br /><strong>1.4.</strong><span>&nbsp;Администрация может вносить в эти правила изменения без предупреждения пользователей.</span><br /><strong>1.5.</strong><span>&nbsp;Администрация не несет ответственности за возможный взлом аккаунтов.</span><br /><strong>1.6.</strong><span>&nbsp;Регистрируясь на проекте, пользователь соглашается быть чьим-либо партнером, и обязуется не выражать свои претензии по этому поводу администрации.</span><br /><strong>1.7.</strong><span>&nbsp;Администрация проекта не несет ответственности за возможное снижение или повышение заработка и активности партнеров.</span><br /><strong>1.8.</strong><span>&nbsp;При оплате каких либо услуг, а затем отказа от их использования, денежные средства не возвращаются.</span><br /><strong>1.9.</strong><span>&nbsp;Администрация вправе устанавливать цены на любые услуги по своему усмотрению.&nbsp;</span><br /><br /><strong>2. ОБЯЗАННОСТИ ПРОЕКТА</strong><br /><strong>2.1.</strong><span>&nbsp;Сохранять конфиденциальность информации зарегистрированного пользователя, полученной от него при регистрации.</span><br /><strong>2.2.</strong><span>&nbsp;При возникновении технических проблем возобновить работу проекта в течение 24 часов.</span><br /><strong>2.3.</strong><span>&nbsp;Выплачивать пользователям заработанные денежные средства в автоматическом режиме в любое время.</span><br /><strong>2.4.</strong><span>&nbsp;Отвечать на письма, присланные в службу технической поддержки в течение 12-х часов.&nbsp;</span><br /><br /><strong>3. ОБЯЗАННОСТИ ПОЛЬЗОВАТЕЛЕЙ</strong><br /><strong>3.1.</strong><span>&nbsp;При регистрации указывать правдивую информацию во всех полях регистрационной формы.</span><br /><strong>3.2.</strong><span>&nbsp;Не реже одного раза в неделю знакомиться с данными правилами.</span><br /><strong>3.3.</strong><span>&nbsp;Не регистрировать более одного аккаунта с одного компьютера. (Вход в два разных аккаунта с одного компьютера считается нарушением).</span><br /><strong>3.4.</strong><span>&nbsp;При обнаружении неисправностей либо некоторых погрешностей проекта сообщать в службу поддержки.</span><br /><strong>3.5.</strong><span>&nbsp;Не проводить попыток взлома проекта и не использовать возможные ошибки.</span><br /><strong>3.6.</strong><span>&nbsp;Не использовать для рекламы своей партнерской ссылки СПАМ в любом виде (почта, форумы, гостевые книги и пр.).</span><br /><strong>3.7.</strong><span>&nbsp;Не публиковать оскорбительных сообщений, клевету и иные виды сообщений портящих репутацию проекта или пользователей.</span><br /><strong>3.8.</strong><span>&nbsp;Не выражать недовольство по поводу проекта и его работы.</span><br /><strong>3.9.</strong><span>&nbsp;Принимать участие в игре, могут только лица, достигшие совершеннолетнего возраста.</span></p>', '<p>Доход в игре каждые 10 минут! В месяц от 30 до 90 процентов!<br />Автоматическая система накопления билетов! Сбор билетов без потерь, без ограничений по срокам! Собирайте билеты, так как удобно именно Вам, Хоть раз в час, хоть раз в день, хоть раз в месяц! Системный рынок позволит мгновенно обменять билеты на Серебро!&nbsp;</p>\r\n<p>Вам даже не нужно звать людей в игру для того, чтобы получить прибыль, система всё делает сама!&nbsp;<br />Максимально быстрые выплаты денег на Ваш кошелек! Любую сумму без дополнительных лимитов и ограничений!<br />В игре всегда можно посмотреть системный резервный фонд на выкуп билетов! Он отображается в реальном времени и Вы всегда в курсе!<br />Резерв системы на выкуп билетов гарантирует пользователям автоматический выкуп билетов и получение стабильного дохода.&nbsp;<br />Резерв системы показывается и обновляется в он-лайн режиме. Администрация проекта гарантирует выкуп билетов на сумму, которая есть в резерве!&nbsp;<br /><br />Резерв системы - это гарант, который Администрация обязуется выплачивать!<br />Каждый пользователь стабильно будет получать доход.<br />В процессе игры дополнительно будут добавлены новые блоки, которые позволят стабильно пополнять резерв на выкуп билетов, что даст дополнительную гарантию участникам!<br />Также при большом сборе средств в резерве на выкуп билетов, администрация проекта планирует инвестиции для получения дохода, который будет пополнять резерв системы на выкуп!<br />Ваш таксопарк будет приносить прибыль всегда!<br />И даже, если резерв системы опустошиться и станет равен нулю Вы всё равно будете продолжать стабильно получать доход!<br />Билеты будут накапливаться дальше и Вы будете получать серебро, просто заявки на продажу билетов будут формироваться в виде очереди!<br />Стабильный прирост резерва всегда будет обеспечивать все выплаты, а далее и очередь обмена билетов, которые будут обрабатываться по очереди!</p>', '<p>&nbsp;</p>\r\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\" width=\"99%\" align=\"center\">\r\n<tbody>\r\n<tr>\r\n<td rowspan=\"5\">&nbsp;</td>\r\n<td width=\"50%\"></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\" height=\"300px\" align=\"center\">\r\n<div class=\"right_map\"><iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d462568.4775927783!2d54.94971263176154!3d25.07421699977329!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43496ad9c645%3A0xbde66e5084295162!2z0JTRg9Cx0LDQuSAtINCe0LHRitC10LTQuNC90LXQvdC90YvQtSDQkNGA0LDQsdGB0LrQuNC1INCt0LzQuNGA0LDRgtGL!5e0!3m2!1sru!2sru!4v1466509894671\" width=\"100%\" height=\"100%\" frameborder=\"0\" style=\"border: 0;\"></iframe></div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>');

-- --------------------------------------------------------

--
-- Структура таблицы `db_config`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:37
--

DROP TABLE IF EXISTS `db_config`;
CREATE TABLE `db_config` (
  `id` int(11) NOT NULL,
  `admin` varchar(10) NOT NULL DEFAULT '',
  `pass` varchar(20) NOT NULL DEFAULT '',
  `min_pay` double NOT NULL DEFAULT '15',
  `ser_per_wmr` int(11) NOT NULL DEFAULT '1000',
  `ser_per_wmz` int(11) NOT NULL DEFAULT '3300',
  `ser_per_wme` int(11) NOT NULL DEFAULT '4200',
  `percent_swap` int(11) NOT NULL DEFAULT '0',
  `percent_sell` int(2) NOT NULL DEFAULT '10',
  `items_per_coin` int(11) NOT NULL DEFAULT '7',
  `a_in_h` int(11) NOT NULL DEFAULT '0',
  `b_in_h` int(11) NOT NULL DEFAULT '0',
  `c_in_h` int(11) NOT NULL DEFAULT '0',
  `d_in_h` int(11) NOT NULL DEFAULT '0',
  `e_in_h` int(11) NOT NULL DEFAULT '0',
  `amount_a_t` int(11) NOT NULL DEFAULT '0',
  `amount_b_t` int(11) NOT NULL DEFAULT '0',
  `amount_c_t` int(11) NOT NULL DEFAULT '0',
  `amount_d_t` int(11) NOT NULL DEFAULT '0',
  `amount_e_t` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_config`
--

INSERT INTO `db_config` (`id`, `admin`, `pass`, `min_pay`, `ser_per_wmr`, `ser_per_wmz`, `ser_per_wme`, `percent_swap`, `percent_sell`, `items_per_coin`, `a_in_h`, `b_in_h`, `c_in_h`, `d_in_h`, `e_in_h`, `amount_a_t`, `amount_b_t`, `amount_c_t`, `amount_d_t`, `amount_e_t`) VALUES
(1, 'ADMONKA', 'ADMINPASS', 20, 100, 3300, 4200, 2, 40, 100, 100, 205, 420, 860, 1800, 500, 1000, 2000, 3000, 4000);

-- --------------------------------------------------------

--
-- Структура таблицы `db_games_coinflip`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_games_coinflip`;
CREATE TABLE `db_games_coinflip` (
  `id` int(1) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(40) COLLATE cp1251_bin NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT '0',
  `sum` int(10) NOT NULL DEFAULT '0',
  `stavka` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COLLATE=cp1251_bin;

-- --------------------------------------------------------

--
-- Структура таблицы `db_games_kamikadze`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_games_kamikadze`;
CREATE TABLE `db_games_kamikadze` (
  `id` int(1) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(40) COLLATE cp1251_bin NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT '0',
  `sum` int(10) NOT NULL DEFAULT '0',
  `stavka` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COLLATE=cp1251_bin;

-- --------------------------------------------------------

--
-- Структура таблицы `db_games_knb`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_games_knb`;
CREATE TABLE `db_games_knb` (
  `id` int(11) NOT NULL,
  `summa` decimal(7,2) NOT NULL DEFAULT '0.00',
  `item` int(1) NOT NULL DEFAULT '0',
  `login` varchar(10) NOT NULL DEFAULT '',
  `dat` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `db_insert_money`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_insert_money`;
CREATE TABLE `db_insert_money` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `money` double NOT NULL DEFAULT '0',
  `serebro` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_insert_money`
--

INSERT INTO `db_insert_money` (`id`, `user`, `user_id`, `money`, `serebro`, `date_add`, `date_del`) VALUES
(1, 'lovenee', 15, 20, 2000, 1564136297, 1565432297),
(2, 'IDan', 27, 20, 2000, 1564149770, 1565445770),
(3, 'iskrime', 28, 50, 5000, 1564149977, 1565445977),
(4, 'Basyak', 16, 10, 1000, 1564155068, 1565451068),
(5, 'WellBux', 1, 2, 200, 1564174462, 1565470462),
(6, 'bubikaa', 49, 3, 300, 1564232027, 1565528027),
(7, 'Andrey56', 55, 3, 300, 1564242060, 1565538060),
(8, 'luckypro', 34, 10, 1000, 1564248510, 1565544510),
(9, 'dinaparado', 14, 10, 1000, 1564254275, 1565550275),
(10, 'Chooddy', 74, 2, 200, 1564311164, 1565607164),
(11, 'Evelina', 76, 2, 200, 1564312305, 1565608305),
(12, 'mumu11', 78, 10, 1000, 1564320129, 1565616129),
(13, 'moisescent', 92, 2, 200, 1564420589, 1565716589),
(14, 'WMonitor', 17, 2, 200, 1564426651, 1565722651),
(15, 'mehanic', 90, 3, 300, 1564434538, 1565730538),
(16, 'llisa', 94, 2, 200, 1564471403, 1565767403),
(17, 'Fedor2019', 46, 2, 200, 1564479275, 1565775275),
(18, 'Nana1998', 35, 3, 300, 1564497350, 1565793350),
(19, 'robot200', 116, 10, 1000, 1564602878, 1565898878),
(20, 'xxxxx', 108, 3, 300, 1564641884, 1565937884),
(21, 'denito220', 50, 2, 200, 1564662628, 1565958628),
(22, 'tqlit', 3, 2, 200, 1564719311, 1566015311),
(23, 'NOVA220', 109, 2, 200, 1564735425, 1566031425),
(24, 'elenaek', 128, 2.5, 250, 1564745926, 1566041926),
(25, 'cosmo', 21, 2, 200, 1564749732, 1566045732),
(26, 'daokeke', 23, 2, 200, 1564750480, 1566046480),
(27, 'ANTHOUSE', 132, 5, 500, 1564768806, 1566064806),
(28, 'samiramis', 100, 2.2, 220, 1564778350, 1566074350),
(29, 'Chincho', 81, 2, 200, 1564805537, 1566101537),
(30, 'namcat23vn', 136, 2, 200, 1564826512, 1566122512),
(31, 'oliga', 135, 2, 200, 1564826803, 1566122803),
(32, 'CMK191187', 144, 5, 500, 1564843731, 1566139731),
(33, 'jgfjf', 160, 3, 300, 1564897825, 1566193825),
(34, 'toropoffig', 47, 3, 300, 1564977039, 1566273039),
(35, 'szmassiel', 169, 3, 300, 1564989986, 1566285986),
(36, 'Gorelka55', 117, 2, 200, 1564994715, 1566290715),
(37, 'Pando', 137, 2, 200, 1565001238, 1566297238),
(38, 'gbh2294', 176, 2, 200, 1565004072, 1566300072),
(39, 'Thien94', 179, 3, 300, 1565010185, 1566306185),
(40, 'Guleke', 183, 2, 200, 1565037735, 1566333735),
(41, 'Pyhpyntik', 188, 3, 300, 1565077750, 1566373750),
(42, 'vard78', 173, 2, 200, 1565153002, 1566449002),
(43, 'soko', 182, 2, 200, 1565170958, 1566466958),
(44, 'ranaadnan0', 198, 2, 200, 1565177750, 1566473750),
(45, 'kolyamba67', 202, 2.05, 205, 1565208027, 1566504027),
(46, 'mkjnb', 121, 2, 200, 1565218344, 1566514344);

-- --------------------------------------------------------

--
-- Структура таблицы `db_investors`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_investors`;
CREATE TABLE `db_investors` (
  `id` int(11) NOT NULL,
  `1m` double NOT NULL DEFAULT '0',
  `2m` double NOT NULL DEFAULT '0',
  `3m` double NOT NULL DEFAULT '0',
  `user_1` varchar(10) NOT NULL,
  `user_2` varchar(10) NOT NULL,
  `user_3` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_end` int(11) NOT NULL DEFAULT '0',
  `priz_1` double NOT NULL DEFAULT '0',
  `priz_2` double NOT NULL DEFAULT '0',
  `priz_3` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_investors_users`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_investors_users`;
CREATE TABLE `db_investors_users` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_lottery`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_lottery`;
CREATE TABLE `db_lottery` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL DEFAULT '',
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_lottery`
--

INSERT INTO `db_lottery` (`id`, `user_id`, `user`, `date_add`) VALUES
(1, 176, 'gbh2294', 1565153350),
(2, 183, 'Guleke', 1565182456),
(3, 128, 'elenaek', 1565186451),
(4, 179, 'Thien94', 1565189909),
(5, 169, 'szmassiel', 1565210826),
(6, 129, 'juando', 1565233088),
(7, 1, 'WellBux', 1565252740);

-- --------------------------------------------------------

--
-- Структура таблицы `db_lottery_winners`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_lottery_winners`;
CREATE TABLE `db_lottery_winners` (
  `id` int(11) NOT NULL,
  `user_a` varchar(10) NOT NULL DEFAULT '',
  `bil_a` int(11) NOT NULL DEFAULT '0',
  `user_b` varchar(10) NOT NULL DEFAULT '',
  `bil_b` int(11) NOT NULL DEFAULT '0',
  `user_c` varchar(10) NOT NULL DEFAULT '',
  `bil_c` int(11) NOT NULL DEFAULT '0',
  `bank` float NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_lottery_winners`
--

INSERT INTO `db_lottery_winners` (`id`, `user_a`, `bil_a`, `user_b`, `bil_b`, `user_c`, `bil_c`, `bank`, `date_add`) VALUES
(1, 'Thien94', 6, 'Bagira', 2, 'gbh2294', 10, 1000, 1565153332);

-- --------------------------------------------------------

--
-- Структура таблицы `db_mails`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_mails`;
CREATE TABLE `db_mails` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `time_add` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(55) NOT NULL,
  `desc` text NOT NULL,
  `url` varchar(300) NOT NULL,
  `question` varchar(50) NOT NULL,
  `reply1` varchar(30) NOT NULL,
  `reply2` varchar(30) NOT NULL,
  `reply3` varchar(30) NOT NULL,
  `timer` enum('20','30','40','50','60') NOT NULL DEFAULT '20',
  `move` enum('0','1') NOT NULL DEFAULT '0',
  `high` enum('0','1') NOT NULL DEFAULT '0',
  `speed` enum('1','2','3','4','5','6','7') NOT NULL DEFAULT '1',
  `mailmode` enum('1','2') NOT NULL DEFAULT '1',
  `view` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `price` double(10,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `money` double(10,3) UNSIGNED NOT NULL DEFAULT '0.000',
  `status` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `db_mails`
--

INSERT INTO `db_mails` (`id`, `user_id`, `time_add`, `title`, `desc`, `url`, `question`, `reply1`, `reply2`, `reply3`, `timer`, `move`, `high`, `speed`, `mailmode`, `view`, `price`, `money`, `status`) VALUES
(1, 17, 1564345991, 'Тест', 'Тестовое сообщение. На него отвечать не стоит\r\n[b]Текст №1[/b]\r\nЛожно Правильно\r\n[i]Текст №2[/i]\r\n[u]Текст №3[/u]\r\n[url]www.well-monitor.ru[/url]', 'https://www.well-monitor.ru', 'Логин', 'Правильно', 'Ложно', 'Ложно', '20', '1', '1', '1', '1', 2, 6.30, 1.400, '2'),
(2, 28, 1564568716, 'тест', 'Ачюметь [u]как смотритца меня все устраивает. Короче проверим все досконально и нада уже запускать[/u], не забудь добавить просмотры [b]ЮТ[/b]', 'https://www.iskrime-monitor.ru', 'Атятя', 'ПРАВИЛЬНЫЙ', 'ЛОЖНЫЙ', 'ЛОЖНЫЙ', '20', '0', '0', '1', '1', 0, 5.00, 0.000, '1');

-- --------------------------------------------------------

--
-- Структура таблицы `db_mails_view`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_mails_view`;
CREATE TABLE `db_mails_view` (
  `id` int(10) UNSIGNED NOT NULL,
  `ident` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `time_add` datetime NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `db_mails_view`
--

INSERT INTO `db_mails_view` (`id`, `ident`, `time_add`, `user_id`) VALUES
(1, 1, '2019-07-30 18:20:56', 17),
(2, 1, '2019-07-30 22:16:05', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `db_news`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_news`;
CREATE TABLE `db_news` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '',
  `news` text NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_payeer_insert`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_payeer_insert`;
CREATE TABLE `db_payeer_insert` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL DEFAULT '',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_payeer_insert`
--

INSERT INTO `db_payeer_insert` (`id`, `user_id`, `user`, `sum`, `date_add`, `status`) VALUES
(1, 15, 'lovenee', 20, 1564136259, 1),
(2, 27, 'IDan', 20, 1564149736, 1),
(3, 28, 'iskrime', 50, 1564149959, 1),
(4, 16, 'Basyak', 10, 1564154999, 1),
(5, 1, 'WellBux', 2, 1564174446, 1),
(6, 49, 'bubikaa', 3, 1564231989, 1),
(7, 55, 'Andrey56', 3, 1564242027, 1),
(8, 34, 'luckypro', 10, 1564248454, 1),
(9, 14, 'dinaparado', 10, 1564254245, 1),
(10, 71, 'druid88', 10, 1564296537, 0),
(11, 74, 'Chooddy', 2, 1564311082, 1),
(12, 76, 'Evelina', 2, 1564312245, 0),
(13, 76, 'Evelina', 2, 1564312264, 1),
(14, 78, 'mumu11', 10, 1564320116, 1),
(15, 81, 'Chincho', 2, 1564334184, 0),
(16, 92, 'moisescent', 2, 1564420443, 1),
(17, 17, 'WMonitor', 2, 1564426640, 1),
(18, 90, 'mehanic', 3, 1564434507, 1),
(19, 94, 'llisa', 2, 1564471317, 1),
(20, 46, 'Fedor2019', 2, 1564479225, 1),
(21, 35, 'Nana1998', 3, 1564497316, 1),
(22, 108, 'xxxxx', 2, 1564572324, 0),
(23, 109, 'NOVA220', 5, 1564574954, 0),
(24, 109, 'NOVA220', 5, 1564575985, 0),
(25, 116, 'robot200', 10, 1564602853, 1),
(26, 108, 'xxxxx', 3, 1564641865, 1),
(27, 109, 'NOVA220', 5, 1564645401, 0),
(28, 50, 'denito220', 2, 1564662563, 1),
(29, 109, 'NOVA220', 5, 1564678898, 0),
(30, 3, 'tqlit', 2, 1564719238, 1),
(31, 109, 'NOVA220', 3, 1564734631, 0),
(32, 109, 'NOVA220', 3, 1564734856, 0),
(33, 109, 'NOVA220', 3, 1564735028, 0),
(34, 109, 'NOVA220', 3, 1564735172, 0),
(35, 109, 'NOVA220', 3, 1564735292, 0),
(36, 109, 'NOVA220', 5, 1564735370, 0),
(37, 109, 'NOVA220', 2, 1564735399, 1),
(38, 128, 'elenaek', 2.5, 1564745848, 1),
(39, 21, 'cosmo', 2, 1564749643, 1),
(40, 23, 'daokeke', 2, 1564750415, 1),
(41, 87, 'viktor1961', 3, 1564752602, 0),
(42, 132, 'ANTHOUSE', 5, 1564768783, 0),
(43, 132, 'ANTHOUSE', 5, 1564768795, 1),
(44, 100, 'samiramis', 2.2, 1564778225, 1),
(45, 81, 'Chincho', 2, 1564805519, 1),
(46, 136, 'namcat23vn', 2, 1564826463, 1),
(47, 135, 'oliga', 2, 1564826785, 1),
(48, 144, 'CMK191187', 5, 1564843586, 1),
(49, 158, 'ageldiev', 2, 1564891942, 0),
(50, 160, 'jgfjf', 3, 1564897687, 1),
(51, 47, 'toropoffig', 3, 1564977004, 1),
(52, 169, 'szmassiel', 3, 1564989889, 1),
(53, 58, 'stasss38', 2, 1564992053, 0),
(54, 117, 'Gorelka55', 2, 1564994658, 1),
(55, 137, 'Pando', 2, 1565001193, 1),
(56, 176, 'gbh2294', 2, 1565003993, 1),
(57, 179, 'Thien94', 3, 1565010160, 1),
(58, 183, 'Guleke', 2, 1565037650, 0),
(59, 183, 'Guleke', 2, 1565037698, 1),
(60, 188, 'Pyhpyntik', 3, 1565077607, 1),
(61, 173, 'vard78', 2, 1565152983, 1),
(62, 198, 'ranaadnan0', 2, 1565177700, 1),
(63, 202, 'kolyamba67', 2.07, 1565207991, 0),
(64, 202, 'kolyamba67', 2.05, 1565208009, 1),
(65, 121, 'mkjnb', 2, 1565218308, 1),
(66, 17, 'WMonitor', 0, 1565255371, 0),
(67, 17, 'WMonitor', 1, 1565255384, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `db_payment`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_payment`;
CREATE TABLE `db_payment` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `purse` varchar(20) NOT NULL DEFAULT '',
  `sum` double NOT NULL DEFAULT '0',
  `comission` double NOT NULL DEFAULT '0',
  `valuta` char(3) NOT NULL DEFAULT 'RUB',
  `serebro` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `pay_sys` varchar(100) NOT NULL DEFAULT '0',
  `pay_sys_id` int(11) NOT NULL DEFAULT '0',
  `response` int(1) NOT NULL DEFAULT '0',
  `payment_id` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_payment`
--

INSERT INTO `db_payment` (`id`, `user`, `user_id`, `purse`, `sum`, `comission`, `valuta`, `serebro`, `status`, `pay_sys`, `pay_sys_id`, `response`, `payment_id`, `date_add`, `date_del`) VALUES
(1, 'WellBux', 1, 'P4085295', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1564173383, 0),
(2, 'Fedor2019', 46, 'P40303414', 1.07, 0, 'RUB', 107, 3, '0', 1136053, 0, 0, 1564479443, 0),
(3, 'bubikaa', 49, 'P21015012', 1.02, 0, 'RUB', 102, 3, '0', 1136053, 0, 0, 1564517777, 0),
(4, 'Evelina', 76, 'P1008723802', 1.03, 0, 'RUB', 103, 3, '0', 1136053, 0, 0, 1564591645, 0),
(5, 'tqlit', 3, 'P1014685142', 2.15, 0, 'RUB', 215, 3, '0', 1136053, 0, 0, 1564719331, 0),
(6, 'moisescent', 92, 'P1007423174', 1.2, 0, 'RUB', 120, 3, '0', 1136053, 0, 0, 1564723564, 0),
(7, 'Chooddy', 74, 'P98345185', 1.17, 0, 'RUB', 117, 3, '0', 1136053, 0, 0, 1564725458, 0),
(8, 'cosmo', 21, 'P1346761', 2.13, 0, 'RUB', 213, 3, '0', 1136053, 0, 0, 1564749762, 0),
(9, 'daokeke', 23, 'P60938511', 1.13, 0, 'RUB', 113, 3, '0', 1136053, 0, 0, 1564750492, 0),
(10, 'samiramis', 100, 'P1013254503', 1.36, 0, 'RUB', 136, 3, '0', 1136053, 0, 0, 1564778546, 0),
(11, 'bubikaa', 49, 'P21015012', 1.4, 0, 'RUB', 140, 3, '0', 1136053, 0, 0, 1564779272, 0),
(12, 'Andrey56', 55, 'P1005962386', 1.02, 0, 'RUB', 102, 3, '0', 1136053, 0, 0, 1564779613, 0),
(13, 'Fedor2019', 46, 'P40303414', 1.42, 0, 'RUB', 142, 3, '0', 1136053, 0, 0, 1564823195, 0),
(14, 'llisa', 94, 'P1009808979', 1.19, 0, 'RUB', 119, 3, '0', 1136053, 0, 0, 1564833059, 0),
(15, 'xxxxx', 108, 'P35495385', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1564834837, 0),
(16, 'denito220', 50, 'P1007009772', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1564836280, 0),
(17, 'elenaek', 128, 'P90018970', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1564859007, 0),
(18, 'Chooddy', 74, 'P98345185', 1.03, 0, 'RUB', 103, 3, '0', 1136053, 0, 0, 1564907863, 0),
(19, 'Evelina', 76, 'P1008723802', 1.13, 0, 'RUB', 113, 3, '0', 1136053, 0, 0, 1564914449, 0),
(20, 'Chincho', 81, 'P1013363388', 1.37, 0, 'RUB', 137, 3, '0', 1136053, 0, 0, 1564926427, 0),
(21, 'CMK191187', 144, 'P87342589', 1.01, 0, 'RUB', 101, 3, '0', 1136053, 0, 0, 1564948764, 0),
(22, 'toropoffig', 47, 'P1012875210', 1.33, 0, 'RUB', 133, 3, '0', 1136053, 0, 0, 1564977111, 0),
(23, 'WMonitor', 17, 'P1000179150', 3.01, 0, 'RUB', 301, 3, '0', 1136053, 0, 0, 1564987111, 0),
(24, 'namcat23vn', 136, 'P1014849880', 1.08, 0, 'RUB', 108, 3, '0', 1136053, 0, 0, 1564987739, 0),
(25, 'cosmo', 21, 'P1346761', 1.35, 0, 'RUB', 135, 3, '0', 1136053, 0, 0, 1564991316, 0),
(26, 'Gorelka55', 117, 'P77577576', 2.14, 0, 'RUB', 214, 3, '0', 1136053, 0, 0, 1564994822, 0),
(27, 'Pando', 137, 'P1011937173', 2.17, 0, 'RUB', 217, 3, '0', 1136053, 0, 0, 1565001327, 0),
(28, 'oliga', 135, 'P1008386545', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1565013538, 0),
(29, 'WMonitor', 17, 'P1000179150', 5.97, 0, 'RUB', 597, 3, '0', 1136053, 0, 0, 1565116282, 0),
(30, 'bubikaa', 49, 'P21015012', 1.13, 0, 'RUB', 113, 3, '0', 1136053, 0, 0, 1565129362, 0),
(31, 'llisa', 94, 'P1009808979', 1.03, 0, 'RUB', 103, 3, '0', 1136053, 0, 0, 1565154642, 0),
(32, 'Pando', 137, 'P1011937173', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1565178940, 0),
(33, 'Fedor2019', 46, 'P40303414', 1.1, 0, 'RUB', 110, 3, '0', 1136053, 0, 0, 1565179367, 0),
(34, 'mehanic', 90, 'P1003748951', 1.17, 0, 'RUB', 117, 3, '0', 1136053, 0, 0, 1565183105, 0),
(35, 'Thien94', 179, 'P1013450534', 1.07, 0, 'RUB', 107, 3, '0', 1136053, 0, 0, 1565189899, 0),
(36, 'szmassiel', 169, 'P1012533731', 1, 0, 'RUB', 100, 3, '0', 1136053, 0, 0, 1565209867, 0),
(37, 'mkjnb', 121, 'P1002961696', 2.06, 0, 'RUB', 206, 3, '0', 1136053, 0, 0, 1565218414, 0),
(38, 'gbh2294', 176, 'P1014004168', 1.14, 0, 'RUB', 114, 3, '0', 1136053, 0, 0, 1565233228, 0),
(39, 'daokeke', 23, 'P60938511', 1.28, 0, 'RUB', 128, 3, '0', 1136053, 0, 0, 1565244163, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `db_pay_dat`
--
-- Создание: Авг 08 2019 г., 09:34
-- Последнее обновление: Авг 08 2019 г., 09:34
--

DROP TABLE IF EXISTS `db_pay_dat`;
CREATE TABLE `db_pay_dat` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_pay_dat`
--

INSERT INTO `db_pay_dat` (`id`, `user_id`, `user`, `sum`, `date_add`, `date_del`) VALUES
(0, 11, '', 100, 1563804735, 1563811935);

-- --------------------------------------------------------

--
-- Структура таблицы `db_recovery`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_recovery`;
CREATE TABLE `db_recovery` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL DEFAULT '',
  `ip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_recovery`
--

INSERT INTO `db_recovery` (`id`, `email`, `ip`, `date_add`, `date_del`) VALUES
(10, 'm.xxx.ru@gmail.com', 2989556979, 1565255727, 1565256627);

-- --------------------------------------------------------

--
-- Структура таблицы `db_regkey`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_regkey`;
CREATE TABLE `db_regkey` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL DEFAULT '',
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `referer_name` varchar(10) NOT NULL DEFAULT '',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_sell_items`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_sell_items`;
CREATE TABLE `db_sell_items` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `a_s` int(11) NOT NULL DEFAULT '0',
  `b_s` int(11) NOT NULL DEFAULT '0',
  `c_s` int(11) NOT NULL DEFAULT '0',
  `d_s` int(11) NOT NULL DEFAULT '0',
  `e_s` int(11) NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `all_sell` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_sender`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_sender`;
CREATE TABLE `db_sender` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `mess` text NOT NULL,
  `page` int(5) NOT NULL DEFAULT '0',
  `sended` int(7) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_serfing`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_serfing`;
CREATE TABLE `db_serfing` (
  `id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `time_add` int(11) NOT NULL DEFAULT '0',
  `title` varchar(55) NOT NULL,
  `desc` varchar(55) NOT NULL,
  `url` varchar(255) NOT NULL,
  `timer` enum('20','30','40','50','60') NOT NULL DEFAULT '20',
  `move` enum('0','1','','') NOT NULL DEFAULT '0',
  `high` enum('0','1','','') NOT NULL DEFAULT '0',
  `speed` enum('1','2','3','4','5','6','7') NOT NULL DEFAULT '1',
  `rating` int(11) NOT NULL DEFAULT '0',
  `country` varchar(50) NOT NULL,
  `crev` enum('0','1','','') NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `price` double(10,2) NOT NULL DEFAULT '0.00',
  `money` double(10,2) NOT NULL DEFAULT '0.00',
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_serfing`
--

INSERT INTO `db_serfing` (`id`, `user_name`, `time_add`, `title`, `desc`, `url`, `timer`, `move`, `high`, `speed`, `rating`, `country`, `crev`, `view`, `price`, `money`, `status`) VALUES
(1, 'WellBux', 1564091652, 'НОВАЯ ИГРА. GREEN POWER.  До 45%', 'Новый проект. Серфин. Бонусы. 10 руб за регистрацию', 'https://greenpower.games/ref/115', '20', '1', '1', '1', 0, '', '0', 52, 6.30, 2.40, 2),
(2, 'WellBux', 1564091709, 'WELL-MONITOR.RU Мониторинг игр. РЕФБЕК 100%', 'Рефбек 100% Страховка до 110%', 'http://well-monitor.ru', '20', '1', '1', '1', 0, '', '0', 356, 6.30, 4057.20, 2),
(3, 'Quelepso', 1564126029, '¦ NEW ¦ «MEGA - BIT» ПЕРСПЕКТИВНЫЙ ХИТ!', '+ ЕЖЕДНЕВНЫЙ БОНУС + СЕРФИНГ', 'https://mega-bit.org/?i=110', '20', '1', '0', '1', 0, '', '0', 10, 5.80, 0.00, 2),
(4, 'Perri', 1564133750, 'MoneyGame', 'Мониторинг | Серфинг | Бонусы', 'https://moneygame.pro/', '20', '1', '0', '1', 0, '', '0', 20, 5.80, 4.00, 2),
(5, 'Hoang2607C', 1564134512, 'Ki&#7871;m ti&#7873;n free', '20 phut/l&#7847;n', 'http://bonusfree.ga/', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 0),
(6, 'Basyak', 1564136112, 'ЗАРАБОТОК В ИНТЕРНЕТЕ!', 'Мы проверяем вы зарабатываете без риска!', 'http://zarabotokrf.advear.ru/', '20', '1', '0', '1', 0, '', '0', 141, 5.80, 4.20, 2),
(7, 'IDan', 1564150032, 'Freya-Etalon.', 'Игра с выводом денег.Ресурсно-строительный симулятор.', 'https://freya-etalon.website/?i=2720', '20', '1', '1', '1', 0, '', '0', 354, 6.30, 2520.60, 2),
(8, 'iskrime', 1564150095, 'Инвестиции с быстрым окупом', 'бонус на первый депозит от 10 долларов', 'http://https://richman.company/?ref=iskrime', '20', '1', '1', '1', 0, '', '0', 253, 6.30, 906.10, 2),
(9, 'iskrime', 1564150226, 'Новинка только стартовала.', 'бонусы задания баунти', 'https://super-wings.space/?i=74', '20', '1', '0', '5', 0, '', '0', 111, 5.80, 1856.20, 2),
(10, 'IDan', 1564155404, 'Freya-etalon', 'Игра с выводом денег.Ресурсно-строительный симулятор.', 'https://freya-etalon.website/?i=2720', '20', '1', '1', '1', 0, '', '0', 0, 6.30, 0.00, 3),
(11, 'IDan', 1564155421, 'Freya-etalon', 'Игра с выводом денег.Ресурсно-строительный симулятор.', 'https://freya-etalon.website/?i=2720', '20', '1', '1', '1', 0, '', '0', 0, 6.30, 0.00, 0),
(12, 'cosmo', 1564223034, 'БОНУСНИК новый', 'СЕРФ,,БОНУСЫ', 'http://bonusrur.ru/?r=5', '20', '1', '0', '1', 0, '', '0', 124, 5.80, 0.80, 2),
(13, 'Basyak', 1564236063, 'НОВИНКА +25% В СУТКИ', 'Мы проверяем вы зарабатываете без риска!', 'https://royalfast.ltd/?ref=905', '20', '1', '0', '1', 0, '', '0', 11, 5.80, 1.20, 3),
(14, 'Andrey56', 1564241502, 'wellbux', 'Отличный  букс и заработок!', 'http://wellbux.ru/?i=55', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 3),
(15, 'WellBux', 1564241668, 'Well-Monitor - Мониторинг игр Рефбек 100%', 'РЕФБЕК 100% СТРАХОВКА ВКЛАДОВ', 'https://www.well-monitor.ru', '20', '1', '1', '1', 0, '', '0', 0, 6.30, 0.00, 3),
(16, 'mumu11', 1564320185, 'СУПЕР СТАРТ ДЕНЕЖНОГО водопада', 'При регистрации бонус +10 руб', 'https://waterfall.site', '20', '0', '0', '1', 0, '', '0', 200, 5.00, 0.00, 2),
(17, 'lovenee', 1564361491, '&#3648;&#3585;&#3617;&#3626;&#3621;&#3655;&#3629;&#3605', '&#3626;&#3621;&#3655;&#3629;&#3605;&#3648;&#3627;&#3619', 'http://ethcombo.com/?i=449838', '20', '1', '1', '1', 0, '', '0', 0, 6.30, 0.00, 3),
(18, 'moisescent', 1564437466, 'EARN RUBLES FAST WITH', 'HOW TO EARN: LIKE, RETWEET, JOIN GROUPS ON FACEBOOK VK', 'https://vktarget.ru/?ref=7170539', '30', '0', '0', '1', 0, '', '0', 0, 5.20, 10.40, 3),
(19, 'NA1HAL', 1564476731, 'BIRDS INFO', 'СУПЕР ИГРА ПЛАТИТ', 'https://money-birdc.info/?i=41', '20', '1', '0', '1', 0, '', '0', 11, 5.80, 0.00, 2),
(20, 'gaisman', 1564592698, 'Бонусы каждый час !!!', 'Депозит выводят стабильно, инвестируй под 2 %', 'http://haltura-club.ru/i/1', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 3),
(21, 'WMonitor', 1564650281, 'НОВАЯ ИГРА * HAPPY FARM * БЕЗ БАЛЛОВ.', 'Сегодня старт. Без вложений. Серфинг.', 'https://happyfarm.biz/partner/WMonitor', '20', '1', '1', '1', 0, '', '0', 48, 6.30, 3.60, 2),
(22, 'denito220', 1564663028, 'KALYM', '80% от заработка привлечённых вами людей.', 'http://www.doxodcenter.ru/reg/?refid=831', '20', '0', '0', '1', 0, '', '0', 54, 5.00, 1.00, 2),
(23, 'cosmo', 1564749489, 'ваши рефы здесь', '+ плюшки', 'http://referal.info/?ref=1860', '20', '1', '0', '1', 0, '', '0', 86, 5.80, 1.20, 2),
(24, 'ANTHOUSE', 1564768746, 'НОВИНКА +50% за 24 часа на АВТОВЫПЛАТАХ', 'Минималка всего 10 RUB - ТОП админ! Умеет работать!', 'https://malina-investing.site/?ref=324', '20', '0', '0', '1', 0, '', '0', 107, 5.00, 1.00, 2),
(25, 'denito220', 1564800610, 'SUPER OTPLATA', '80% от заработка привлечённых вами людей.', 'http://brainbux.com/?ref=denito220', '20', '0', '0', '1', 0, '', '0', 21, 5.00, 0.00, 2),
(26, 'daokeke', 1564817234, 'make money free', 'make money free', 'https://kiemtiencungsunny.blogspot.com/', '20', '0', '0', '1', 0, '', '0', 80, 5.00, 0.00, 2),
(27, 'WellBux', 1564824323, 'Надежный проект. 100% гарантия.', 'Проект платит. Честно и без обмана. Без скама', 'http://lucky-evolutiongame.pro/?i=27', '20', '1', '0', '1', 0, '', '0', 68, 5.80, 5.60, 2),
(28, 'Pando', 1564907755, 'Комфортный серфинг, Мгновенная оплата от 1 рубля', 'Плати престиж', 'https://entrym.ru/i/1846', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 250.00, 3),
(29, 'cosmo', 1564991374, 'ваши рефы здесь', 'СЕРФ', 'http://zeclick.biz/?i=332', '20', '1', '0', '1', 0, '', '0', 20, 5.80, 0.00, 2),
(30, 'tqlit', 1565058311, 'clicks adv to earn money', 'make money easy', 'http://bestclix.xyz/?ref=tqlit', '20', '0', '0', '2', 0, '', '0', 0, 5.00, 533.00, 3),
(31, 'cosmo', 1565098203, 'новое лото', '3 бонуса', 'https://cash-bonus.fun/?ref=90', '20', '1', '0', '1', 0, '', '0', 28, 5.80, 5.60, 2),
(32, 'Pando', 1565106145, 'Earn BTC Watching Youtube', 'No Minimum Withdrawal. Instant Withdrawals', 'https://bittube.me/ref/83388', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 3),
(33, 'rodor', 1565109375, 'Инвестиционный проект CAPITAL GROUP.', 'Платит!!    Платит!!   Платит!!', 'https://capitals-group.ru/?go=80', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 3),
(34, 'vipppp', 1565169989, 'Самы грандиозны проект', 'Платит реально', 'https://sea-port.biz/?i=4034', '20', '0', '0', '1', 0, '', '0', 2, 5.00, 0.00, 2),
(35, 'vard78', 1565181419, 'ENTRYM - НОВЫЕ ЦЕНЫ И ДЕШЕВАЯ РЕКЛАМА', 'REF 100%', 'https://entrym.ru/i/9', '20', '1', '1', '1', 0, '', '0', 29, 6.30, 0.30, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `db_serfingb`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_serfingb`;
CREATE TABLE `db_serfingb` (
  `id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `time_add` int(11) NOT NULL DEFAULT '0',
  `title` varchar(55) NOT NULL,
  `desc` varchar(55) NOT NULL,
  `url` varchar(255) NOT NULL,
  `timer` enum('20','30','40','50','60') NOT NULL DEFAULT '20',
  `move` enum('0','1','','') NOT NULL DEFAULT '0',
  `high` enum('0','1','','') NOT NULL DEFAULT '0',
  `speed` enum('1','2','3','4','5','6','7') NOT NULL DEFAULT '1',
  `baner` enum('0','1','','') NOT NULL,
  `baner_url` varchar(250) NOT NULL,
  `crev` enum('0','1','','') NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `price` double(10,2) NOT NULL DEFAULT '0.00',
  `money` double(10,2) NOT NULL DEFAULT '0.00',
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_serfingb`
--

INSERT INTO `db_serfingb` (`id`, `user_name`, `time_add`, `title`, `desc`, `url`, `timer`, `move`, `high`, `speed`, `baner`, `baner_url`, `crev`, `view`, `price`, `money`, `status`) VALUES
(3, 'alexey', 1564255617, 'Простая  регистрация через ВК .', 'мини-букс', 'https://i-serfer.ru/i/208', '20', '0', '0', '1', '0', '', '0', 19, 5.00, 2.00, 3),
(4, 'cosmo', 1564298009, 'ваши рефы здесь', 'СЕРФ,,БОНУСЫ', 'http://zeclick.biz/?i=332', '20', '1', '0', '1', '1', 'http://zeclick.biz/img/468x60.png', '0', 69, 6.00, 1.00, 2),
(9, 'WellBux', 1564303216, 'Well-Monitor - Мониторинг игр Рефбек 100%', 'Рефбек 100% Есть страховка', 'http://well-monitor.ru', '20', '1', '0', '1', '1', 'http://mmgr.ucoz.org/468kh60.gif', '0', 1, 6.00, 0.00, 3),
(10, 'lovenee', 1564361858, '&#3648;&#3585;&#3617;&#3626;&#3621;&#3655;&#3629;&#3605', '&#3626;&#3621;&#3655;&#3629;&#3605;&#3648;&#3627;&#3619', 'https://popspins.com/?bonus=18102', '30', '1', '1', '1', '1', '', '0', 0, 7.40, 0.00, 3),
(12, 'robot200', 1564602950, 'ТОЛЬКО СТАРТОВАЛ!Бонусы!ИГРА БОМБА!', 'Бонусы! Акции!Чат!Группа в ВК!', 'https://happyfarm.biz/partner/robot200', '20', '1', '1', '1', '1', 'https://happyfarm.biz/HF-468.gif', '0', 142, 7.00, 6.00, 2),
(13, 'WellBux', 1564603303, 'КАПИТАЛ СИТИ  - Проект на полном автомате.', 'Игра с выводом денег. Все автоматизировано', 'https://capital-city.net/?ref=197', '20', '1', '0', '1', '1', 'https://capital-city.net/imgr/cc468x60.gif', '0', 150, 6.00, 0.00, 2),
(14, 'WMonitor', 1564731457, 'ПТИЧКИ СНОВА НЕСУТ ЯЙЦА. ДО 65% В МЕСЯЦ.', 'Надежный админ. Без баллов и вложений. 50 руб новым уч.', 'http://moneybirds.site/?i=211', '60', '1', '0', '1', '1', 'http://moneybirds.site/img/MB-4688.gif', '0', 24, 7.60, 5.40, 2),
(16, 'Pando', 1564929924, 'http://kalymka.com/?ref=5391', 'http://kalymka.com/?ref=5391', 'http://kalymka.com/?ref=5391', '20', '0', '0', '1', '1', '', '0', 0, 5.00, 0.00, 3),
(17, 'luckypro', 1565011857, 'Lucky-evolution game от 30% за месяц', 'Баунти программа ,серфинг заработок без вложения и с', 'http://lucky-evolutiongame.pro/?i=1', '20', '0', '1', '1', '1', 'http://images.vfl.ru/ii/1565011764/f74a17c3/27446721.gif', '0', 0, 6.00, 0.00, 3),
(19, 'WMonitor', 1565084008, 'ТОП ПРОЕКТ. БЕЗ БАЛЛОВ И ВЛОЖЕНИЙ', 'Увлекательная игра. Советую присоединиться', 'https://happyfarm.biz/partner/WMonitor', '20', '1', '0', '1', '1', 'https://happyfarm.biz/HF-468.gif', '0', 19, 6.00, 51.00, 2),
(20, 'cosmo', 1565097711, 'новое лото', '3 бонуса', 'https://cash-bonus.fun/?ref=90', '20', '1', '0', '1', '1', 'https://cash-bonus.fun/images/46860.gif', '0', 64, 6.00, 216.00, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `db_serfingb_view`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_serfingb_view`;
CREATE TABLE `db_serfingb_view` (
  `id` int(11) NOT NULL,
  `ident` int(11) NOT NULL DEFAULT '0',
  `time_add` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `db_serfingb_view`
--

INSERT INTO `db_serfingb_view` (`id`, `ident`, `time_add`, `user_id`) VALUES
(4, 3, '2019-07-27 23:42:23', 46),
(5, 3, '2019-07-28 02:46:50', 65),
(6, 3, '2019-07-28 03:28:18', 33),
(7, 3, '2019-07-28 05:27:27', 67),
(8, 3, '2019-07-28 07:03:30', 68),
(9, 3, '2019-07-28 07:43:15', 15),
(10, 3, '2019-07-28 09:21:08', 70),
(11, 3, '2019-07-28 09:41:16', 71),
(12, 4, '2019-08-07 07:45:47', 72),
(13, 3, '2019-07-28 11:39:13', 72),
(14, 9, '2019-07-28 11:44:29', 1),
(15, 4, '2019-07-28 12:00:18', 73),
(16, 3, '2019-07-28 12:01:18', 73),
(17, 3, '2019-07-28 12:02:02', 3),
(18, 4, '2019-08-05 11:08:59', 3),
(19, 4, '2019-07-28 12:26:25', 11),
(20, 3, '2019-07-28 12:28:21', 11),
(21, 4, '2019-07-28 12:53:21', 70),
(22, 4, '2019-07-29 14:22:50', 7),
(23, 3, '2019-07-28 13:45:42', 7),
(24, 4, '2019-07-28 13:46:09', 74),
(25, 3, '2019-07-28 13:47:04', 74),
(26, 4, '2019-08-06 20:53:11', 33),
(27, 4, '2019-07-29 16:46:38', 76),
(28, 3, '2019-07-28 14:06:41', 76),
(29, 4, '2019-07-28 14:14:07', 51),
(30, 3, '2019-07-28 14:14:54', 51),
(31, 3, '2019-07-28 15:14:20', 77),
(32, 4, '2019-08-06 16:30:16', 46),
(33, 4, '2019-08-06 20:56:00', 77),
(34, 4, '2019-07-28 16:24:37', 42),
(35, 3, '2019-07-28 16:25:28', 42),
(36, 4, '2019-07-29 17:15:13', 79),
(37, 3, '2019-07-28 16:44:19', 79),
(38, 4, '2019-07-29 18:11:19', 15),
(39, 4, '2019-07-28 17:36:40', 31),
(40, 4, '2019-07-28 19:21:34', 80),
(41, 4, '2019-07-28 20:08:23', 81),
(42, 4, '2019-07-28 23:19:16', 17),
(43, 4, '2019-08-07 01:09:05', 49),
(44, 4, '2019-07-30 09:20:10', 83),
(45, 4, '2019-07-29 03:57:42', 85),
(46, 4, '2019-07-29 07:42:41', 82),
(47, 4, '2019-07-29 08:07:01', 87),
(48, 4, '2019-07-29 09:30:26', 5),
(49, 4, '2019-07-29 11:26:45', 35),
(50, 4, '2019-07-29 15:59:48', 89),
(51, 4, '2019-07-29 16:50:55', 90),
(52, 4, '2019-07-29 20:17:39', 92),
(53, 4, '2019-07-29 21:23:10', 60),
(61, 4, '2019-07-30 10:18:59', 94),
(90, 12, '2019-07-31 23:21:52', 1),
(91, 12, '2019-08-02 00:35:19', 100),
(92, 12, '2019-08-04 14:24:06', 24),
(93, 13, '2019-08-02 00:36:11', 100),
(94, 13, '2019-08-06 13:11:23', 24),
(96, 12, '2019-08-01 02:14:30', 79),
(97, 13, '2019-08-01 02:15:08', 79),
(99, 12, '2019-08-05 02:54:08', 104),
(100, 13, '2019-08-06 02:22:55', 104),
(101, 12, '2019-08-03 14:31:46', 110),
(102, 13, '2019-08-03 14:32:50', 110),
(103, 12, '2019-08-02 08:14:51', 92),
(104, 13, '2019-08-02 08:15:31', 92),
(105, 12, '2019-08-05 11:42:19', 117),
(106, 13, '2019-08-06 02:19:04', 117),
(107, 12, '2019-08-05 11:08:27', 3),
(108, 13, '2019-08-07 11:15:19', 3),
(109, 12, '2019-08-01 05:32:54', 42),
(110, 13, '2019-08-01 05:33:33', 42),
(112, 12, '2019-08-04 07:20:53', 118),
(114, 13, '2019-08-06 10:36:58', 118),
(115, 12, '2019-08-01 07:08:11', 119),
(116, 13, '2019-08-01 07:08:49', 119),
(118, 12, '2019-08-01 08:46:09', 5),
(119, 13, '2019-08-01 08:47:11', 5),
(120, 12, '2019-08-04 10:00:14', 51),
(121, 13, '2019-08-07 08:59:25', 51),
(123, 12, '2019-08-02 14:21:25', 98),
(124, 13, '2019-08-02 14:22:07', 98),
(125, 12, '2019-08-05 13:13:12', 72),
(126, 13, '2019-08-06 11:09:02', 72),
(127, 12, '2019-08-04 17:35:11', 108),
(128, 12, '2019-08-02 11:46:47', 109),
(129, 12, '2019-08-04 22:10:11', 77),
(130, 13, '2019-08-06 20:55:31', 77),
(131, 12, '2019-08-05 13:51:28', 7),
(132, 13, '2019-08-06 13:12:02', 7),
(133, 12, '2019-08-01 13:31:44', 17),
(134, 12, '2019-08-04 06:07:45', 23),
(135, 13, '2019-08-04 06:08:58', 23),
(136, 12, '2019-08-04 13:26:27', 76),
(137, 13, '2019-08-05 22:13:41', 76),
(138, 12, '2019-08-01 16:43:38', 123),
(139, 13, '2019-08-01 16:44:25', 123),
(140, 12, '2019-08-04 18:58:24', 46),
(141, 13, '2019-08-06 16:32:05', 46),
(142, 12, '2019-08-04 08:37:50', 120),
(143, 13, '2019-08-07 08:03:56', 120),
(144, 13, '2019-08-01 19:31:21', 109),
(145, 12, '2019-08-01 19:38:27', 70),
(146, 13, '2019-08-01 19:39:21', 70),
(147, 12, '2019-08-01 19:56:08', 114),
(148, 13, '2019-08-01 19:56:41', 114),
(149, 12, '2019-08-03 20:15:07', 26),
(150, 13, '2019-08-03 20:15:37', 26),
(151, 12, '2019-08-01 21:14:57', 80),
(152, 13, '2019-08-05 22:26:39', 80),
(153, 12, '2019-08-01 21:44:03', 124),
(154, 13, '2019-08-01 21:46:20', 124),
(155, 12, '2019-08-05 00:33:19', 49),
(156, 13, '2019-08-07 01:08:34', 49),
(157, 12, '2019-08-05 16:47:51', 15),
(158, 13, '2019-08-06 01:28:16', 15),
(159, 12, '2019-08-02 06:01:42', 37),
(160, 13, '2019-08-02 06:02:53', 37),
(161, 12, '2019-08-04 07:08:19', 50),
(162, 13, '2019-08-04 07:09:05', 50),
(163, 12, '2019-08-03 20:49:11', 60),
(164, 13, '2019-08-03 20:50:05', 60),
(165, 12, '2019-08-04 11:34:53', 74),
(166, 13, '2019-08-06 12:06:04', 74),
(167, 14, '2019-08-04 18:59:33', 46),
(168, 12, '2019-08-02 11:45:56', 126),
(169, 14, '2019-08-02 11:47:12', 126),
(170, 13, '2019-08-02 11:48:02', 126),
(171, 14, '2019-08-02 11:49:42', 109),
(172, 14, '2019-08-02 12:04:13', 110),
(173, 14, '2019-08-02 12:10:12', 24),
(174, 14, '2019-08-04 17:34:40', 108),
(175, 13, '2019-08-03 15:14:21', 108),
(176, 14, '2019-08-02 12:27:20', 3),
(177, 14, '2019-08-04 17:37:59', 15),
(178, 14, '2019-08-04 18:55:20', 26),
(179, 14, '2019-08-02 14:17:21', 7),
(180, 12, '2019-08-03 16:24:06', 127),
(181, 12, '2019-08-05 07:40:49', 128),
(182, 13, '2019-08-03 16:24:46', 127),
(183, 13, '2019-08-06 14:27:46', 128),
(184, 12, '2019-08-02 15:02:44', 83),
(185, 13, '2019-08-02 15:03:44', 83),
(186, 12, '2019-08-04 02:37:24', 129),
(187, 13, '2019-08-06 17:23:05', 129),
(188, 12, '2019-08-04 20:27:20', 121),
(189, 13, '2019-08-03 19:55:38', 121),
(190, 12, '2019-08-05 01:44:04', 84),
(191, 12, '2019-08-02 19:40:17', 131),
(192, 13, '2019-08-02 19:43:16', 131),
(193, 12, '2019-08-02 23:39:45', 55),
(194, 14, '2019-08-02 23:41:22', 55),
(195, 12, '2019-08-02 23:52:06', 113),
(196, 14, '2019-08-02 23:52:30', 49),
(197, 14, '2019-08-02 23:53:23', 113),
(198, 13, '2019-08-02 23:54:15', 113),
(199, 14, '2019-08-04 21:20:42', 51),
(200, 12, '2019-08-04 16:45:03', 81),
(201, 13, '2019-08-03 07:23:06', 81),
(202, 12, '2019-08-03 08:50:30', 134),
(203, 13, '2019-08-03 08:51:38', 134),
(204, 12, '2019-08-05 16:57:31', 135),
(205, 13, '2019-08-03 13:08:26', 135),
(206, 12, '2019-08-05 01:24:17', 136),
(207, 12, '2019-08-04 16:12:41', 137),
(208, 13, '2019-08-07 10:13:51', 137),
(209, 13, '2019-08-03 13:52:06', 87),
(210, 12, '2019-08-03 13:52:42', 87),
(211, 12, '2019-08-04 16:23:29', 94),
(212, 13, '2019-08-06 10:11:55', 94),
(213, 12, '2019-08-03 15:07:54', 142),
(214, 13, '2019-08-03 15:11:21', 142),
(215, 12, '2019-08-05 11:33:58', 143),
(216, 13, '2019-08-03 15:40:13', 143),
(217, 12, '2019-08-03 16:41:04', 152),
(218, 12, '2019-08-04 22:34:37', 107),
(219, 13, '2019-08-03 16:42:07', 107),
(220, 13, '2019-08-03 16:42:08', 152),
(221, 12, '2019-08-03 16:45:10', 153),
(222, 13, '2019-08-06 18:42:05', 153),
(223, 12, '2019-08-03 16:56:59', 154),
(224, 13, '2019-08-03 16:58:03', 154),
(225, 13, '2019-08-03 17:43:59', 144),
(226, 12, '2019-08-05 00:29:04', 144),
(227, 12, '2019-08-03 18:41:12', 155),
(228, 12, '2019-08-03 19:50:11', 156),
(229, 13, '2019-08-03 19:50:56', 156),
(230, 12, '2019-08-05 13:46:51', 33),
(231, 13, '2019-08-06 02:39:57', 33),
(232, 13, '2019-08-04 04:49:27', 136),
(233, 12, '2019-08-05 06:49:17', 47),
(234, 13, '2019-08-07 06:33:41', 47),
(235, 12, '2019-08-04 05:52:33', 157),
(236, 13, '2019-08-06 15:40:24', 157),
(237, 13, '2019-08-04 07:21:37', 158),
(238, 12, '2019-08-04 07:22:26', 158),
(239, 12, '2019-08-04 08:42:29', 159),
(240, 13, '2019-08-06 15:56:15', 159),
(241, 12, '2019-08-04 08:52:49', 160),
(242, 13, '2019-08-04 13:21:51', 84),
(243, 14, '2019-08-04 17:44:46', 137),
(244, 14, '2019-08-04 20:10:05', 128),
(245, 14, '2019-08-04 20:17:06', 33),
(246, 14, '2019-08-04 20:28:33', 121),
(247, 14, '2019-08-04 22:11:20', 77),
(248, 12, '2019-08-05 05:46:56', 166),
(249, 12, '2019-08-05 06:56:43', 167),
(250, 12, '2019-08-05 10:23:22', 169),
(251, 12, '2019-08-05 11:12:25', 58),
(252, 4, '2019-08-05 11:12:56', 58),
(253, 4, '2019-08-05 11:34:42', 143),
(254, 12, '2019-08-05 11:34:46', 171),
(255, 4, '2019-08-05 11:35:40', 171),
(256, 4, '2019-08-05 11:42:51', 117),
(257, 4, '2019-08-07 06:34:16', 47),
(258, 12, '2019-08-05 12:22:46', 174),
(259, 4, '2019-08-05 12:23:21', 174),
(260, 4, '2019-08-06 18:38:38', 137),
(261, 4, '2019-08-05 13:38:33', 24),
(262, 12, '2019-08-05 13:40:21', 175),
(263, 12, '2019-08-05 14:33:52', 176),
(264, 12, '2019-08-05 15:34:04', 178),
(265, 12, '2019-08-05 16:00:50', 179),
(266, 12, '2019-08-05 16:19:59', 90),
(267, 13, '2019-08-07 03:22:27', 183),
(268, 13, '2019-08-07 00:30:48', 182),
(269, 13, '2019-08-07 02:50:09', 179),
(270, 13, '2019-08-07 07:47:18', 176),
(271, 13, '2019-08-06 08:37:49', 184),
(272, 13, '2019-08-06 08:42:38', 185),
(273, 13, '2019-08-06 09:52:56', 186),
(274, 13, '2019-08-06 10:40:56', 188),
(275, 13, '2019-08-06 11:01:24', 170),
(276, 13, '2019-08-06 11:04:03', 90),
(277, 19, '2019-08-06 12:43:48', 24),
(278, 19, '2019-08-06 12:49:32', 188),
(279, 19, '2019-08-06 13:06:07', 190),
(280, 13, '2019-08-06 13:06:54', 190),
(281, 19, '2019-08-06 13:07:46', 117),
(282, 19, '2019-08-06 13:11:08', 7),
(283, 19, '2019-08-06 13:33:06', 176),
(284, 19, '2019-08-06 13:51:06', 137),
(285, 19, '2019-08-06 14:26:35', 128),
(286, 19, '2019-08-08 11:58:38', 47),
(287, 19, '2019-08-06 15:35:14', 157),
(288, 19, '2019-08-06 15:55:37', 159),
(289, 19, '2019-08-06 16:20:48', 94),
(290, 19, '2019-08-06 16:30:52', 46),
(291, 20, '2019-08-07 23:15:18', 46),
(292, 20, '2019-08-07 17:57:56', 179),
(293, 19, '2019-08-06 17:10:59', 179),
(294, 4, '2019-08-06 17:11:39', 179),
(295, 20, '2019-08-06 17:21:50', 129),
(296, 19, '2019-08-06 17:22:24', 129),
(297, 4, '2019-08-06 17:23:41', 129),
(298, 20, '2019-08-08 00:25:42', 190),
(299, 4, '2019-08-06 17:53:21', 190),
(300, 20, '2019-08-07 18:54:35', 153),
(301, 20, '2019-08-07 18:44:29', 137),
(302, 19, '2019-08-06 18:39:57', 153),
(303, 4, '2019-08-06 18:43:45', 153),
(304, 20, '2019-08-06 18:56:39', 178),
(305, 19, '2019-08-06 19:00:51', 178),
(306, 13, '2019-08-06 19:01:25', 178),
(307, 4, '2019-08-06 19:01:54', 178),
(308, 20, '2019-08-07 23:25:55', 169),
(309, 13, '2019-08-06 20:09:26', 169),
(310, 4, '2019-08-06 20:10:35', 169),
(311, 20, '2019-08-07 21:13:40', 33),
(312, 20, '2019-08-06 20:55:00', 77),
(313, 20, '2019-08-06 20:58:05', 100),
(314, 4, '2019-08-06 21:00:52', 100),
(315, 4, '2019-08-06 21:28:30', 128),
(316, 20, '2019-08-07 22:07:09', 128),
(317, 20, '2019-08-07 00:07:09', 181),
(318, 13, '2019-08-07 00:08:16', 181),
(319, 4, '2019-08-07 00:09:34', 181),
(320, 20, '2019-08-08 10:12:48', 182),
(321, 4, '2019-08-07 00:31:44', 182),
(322, 20, '2019-08-07 01:08:04', 49),
(323, 20, '2019-08-08 08:09:55', 183),
(324, 4, '2019-08-07 03:23:33', 183),
(325, 20, '2019-08-08 05:52:07', 176),
(326, 4, '2019-08-07 04:48:35', 176),
(327, 20, '2019-08-07 06:01:50', 32),
(328, 13, '2019-08-07 06:03:19', 32),
(329, 4, '2019-08-07 06:04:01', 32),
(330, 20, '2019-08-08 11:58:00', 47),
(331, 20, '2019-08-07 07:45:06', 72),
(332, 20, '2019-08-07 08:03:13', 120),
(333, 20, '2019-08-08 10:10:01', 94),
(334, 20, '2019-08-08 11:10:43', 51),
(335, 20, '2019-08-07 11:07:11', 17),
(336, 20, '2019-08-07 11:13:05', 3),
(337, 20, '2019-08-07 12:13:31', 170),
(338, 20, '2019-08-07 12:13:37', 196),
(339, 13, '2019-08-07 12:14:13', 196),
(340, 20, '2019-08-07 12:14:21', 195),
(341, 20, '2019-08-07 12:17:46', 197),
(342, 13, '2019-08-07 12:18:22', 197),
(343, 20, '2019-08-07 12:25:13', 74),
(344, 20, '2019-08-07 13:12:44', 194),
(345, 20, '2019-08-07 13:21:04', 24),
(346, 20, '2019-08-07 14:00:31', 117),
(347, 20, '2019-08-07 14:22:17', 7),
(348, 20, '2019-08-07 14:38:51', 198),
(349, 20, '2019-08-07 15:59:59', 90),
(350, 20, '2019-08-07 16:18:12', 23),
(351, 20, '2019-08-07 16:24:06', 76),
(352, 20, '2019-08-07 16:36:59', 199),
(353, 20, '2019-08-07 17:00:52', 70),
(354, 20, '2019-08-07 17:09:44', 200),
(355, 20, '2019-08-07 17:12:04', 131),
(356, 20, '2019-08-07 18:15:51', 118),
(357, 20, '2019-08-07 19:30:53', 81),
(358, 20, '2019-08-07 23:03:36', 202),
(359, 20, '2019-08-08 01:57:41', 121),
(360, 20, '2019-08-08 06:12:19', 110),
(361, 20, '2019-08-08 06:38:05', 167),
(362, 20, '2019-08-08 06:49:20', 166),
(363, 20, '2019-08-08 11:54:45', 97),
(364, 19, '2019-08-08 12:08:31', 97);

-- --------------------------------------------------------

--
-- Структура таблицы `db_serfingy`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_serfingy`;
CREATE TABLE `db_serfingy` (
  `id` int(11) NOT NULL,
  `user_name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `time_add` int(11) NOT NULL DEFAULT '0',
  `title` varchar(70) CHARACTER SET utf8 NOT NULL,
  `desc` varchar(70) CHARACTER SET utf8 NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 NOT NULL,
  `url1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timer` enum('20','30','40','50','60') CHARACTER SET utf8 NOT NULL DEFAULT '20',
  `move` enum('0','1','','') CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `high` enum('0','1','','') CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `speed` enum('1','2','3','4','5','6','7') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `rating` int(11) NOT NULL DEFAULT '0',
  `country` varchar(50) CHARACTER SET utf8 NOT NULL,
  `crev` enum('0','1','','') CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `price` double(20,2) NOT NULL DEFAULT '0.00',
  `money` double(20,2) NOT NULL DEFAULT '0.00',
  `status` int(1) NOT NULL DEFAULT '0',
  `baner` int(11) NOT NULL,
  `baner_url` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `db_serfingy`
--

INSERT INTO `db_serfingy` (`id`, `user_name`, `time_add`, `title`, `desc`, `url`, `url1`, `timer`, `move`, `high`, `speed`, `rating`, `country`, `crev`, `view`, `price`, `money`, `status`, `baner`, `baner_url`) VALUES
(1, 'Basyak', 1564136555, 'SUPER WINGS новый топ проект!', 'Мы проверяем вы зарабатываете без риска!', 'https://super-wings.space/?i=294', 'G5ar1qEHsog', '60', '1', '0', '1', 0, '', '0', 50, 6.60, 0.00, 3, 0, 0),
(2, 'luckypro', 1564248836, 'Крутой браузер который платит по 5$ за человека', 'В видео показан очередной вывод 90$', 'https://youtu.be/rnG2yQZJghk', 'rnG2yQZJghk', '60', '1', '1', '1', 0, '', '0', 140, 7.10, 6.00, 2, 0, 0),
(3, 'Admin11', 1564844147, 'авыавыа', 'вававыавыавыа', 'https://seobon.ru/', 'Yy66NvzJoqU', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 0, 0, 0),
(4, 'leducanh', 1565083534, 'xe t&#7843;i foton t3', 'xe t&#7843;i foton t3 khuy&#7871;n m&#7841;i kh&#7911;n', 'https://denhatototuyenquang.com/', 'https://www.youtube.com/watch?v=O2uZT3ViM5E&t=195s', '20', '0', '0', '1', 0, '', '0', 0, 5.00, 0.00, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `db_serfingy_view`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_serfingy_view`;
CREATE TABLE `db_serfingy_view` (
  `id` int(11) NOT NULL,
  `ident` int(11) NOT NULL DEFAULT '0',
  `time_add` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `db_serfingy_view`
--

INSERT INTO `db_serfingy_view` (`id`, `ident`, `time_add`, `user_id`) VALUES
(1, 1, '2019-07-26 18:12:32', 16),
(2, 1, '2019-07-26 18:31:31', 24),
(3, 1, '2019-07-26 18:44:52', 1),
(4, 1, '2019-07-26 18:44:54', 30),
(5, 1, '2019-07-28 17:31:16', 31),
(6, 1, '2019-07-27 21:01:53', 3),
(7, 1, '2019-07-28 03:29:57', 33),
(8, 1, '2019-07-26 23:01:24', 12),
(9, 1, '2019-07-27 00:42:24', 38),
(10, 1, '2019-07-27 00:52:58', 37),
(11, 1, '2019-07-28 07:47:09', 15),
(12, 1, '2019-07-27 06:28:16', 8),
(13, 1, '2019-07-27 07:07:18', 40),
(14, 1, '2019-07-27 09:38:13', 41),
(15, 1, '2019-07-28 13:49:18', 7),
(16, 1, '2019-07-28 15:14:24', 46),
(17, 1, '2019-07-27 15:52:04', 48),
(18, 1, '2019-07-29 01:48:08', 49),
(19, 1, '2019-07-27 17:16:53', 51),
(20, 1, '2019-07-27 17:47:02', 53),
(21, 1, '2019-07-27 17:48:10', 54),
(22, 1, '2019-07-27 18:12:22', 55),
(23, 1, '2019-07-27 19:11:24', 57),
(24, 1, '2019-07-27 19:43:01', 21),
(25, 1, '2019-07-27 20:14:17', 34),
(26, 1, '2019-07-27 20:28:26', 59),
(27, 2, '2019-07-27 20:38:15', 59),
(28, 2, '2019-07-30 03:56:52', 33),
(29, 2, '2019-08-02 07:07:44', 3),
(30, 2, '2019-08-02 06:48:19', 60),
(31, 1, '2019-07-27 21:45:23', 60),
(32, 1, '2019-07-27 22:25:11', 61),
(33, 2, '2019-07-27 23:01:24', 17),
(34, 2, '2019-08-03 12:04:42', 46),
(35, 2, '2019-08-01 05:35:43', 42),
(36, 1, '2019-07-28 01:25:19', 42),
(37, 2, '2019-07-28 01:39:32', 21),
(38, 2, '2019-08-03 00:03:34', 51),
(39, 2, '2019-07-28 02:51:13', 65),
(40, 1, '2019-07-28 02:54:10', 65),
(41, 2, '2019-07-28 04:18:45', 47),
(42, 1, '2019-07-28 04:19:57', 47),
(43, 2, '2019-07-28 05:30:22', 67),
(44, 1, '2019-07-28 05:31:47', 67),
(45, 2, '2019-08-02 05:49:50', 15),
(46, 2, '2019-08-01 19:41:20', 70),
(47, 1, '2019-07-28 09:24:35', 70),
(48, 2, '2019-07-28 09:42:57', 71),
(49, 1, '2019-07-28 09:44:46', 71),
(50, 2, '2019-08-03 10:50:53', 72),
(51, 1, '2019-07-28 11:36:53', 72),
(52, 2, '2019-07-28 11:51:15', 73),
(53, 1, '2019-07-28 11:52:36', 73),
(54, 2, '2019-08-02 15:26:52', 7),
(55, 2, '2019-08-02 08:56:19', 74),
(56, 1, '2019-07-28 13:50:43', 74),
(57, 2, '2019-07-31 19:47:02', 76),
(58, 1, '2019-07-28 14:09:34', 76),
(59, 1, '2019-07-28 15:24:32', 77),
(60, 2, '2019-08-02 00:53:51', 77),
(61, 2, '2019-08-01 02:19:11', 79),
(62, 1, '2019-07-28 16:55:12', 79),
(63, 2, '2019-07-28 17:03:51', 31),
(64, 2, '2019-08-01 21:13:29', 80),
(65, 1, '2019-07-28 19:20:08', 80),
(66, 2, '2019-08-03 07:57:46', 81),
(67, 1, '2019-07-28 20:13:50', 81),
(68, 2, '2019-07-28 23:05:53', 82),
(69, 2, '2019-08-02 23:54:16', 49),
(70, 2, '2019-08-02 15:25:30', 83),
(71, 2, '2019-07-29 03:58:57', 85),
(72, 1, '2019-07-29 04:00:12', 85),
(73, 2, '2019-07-29 08:06:22', 87),
(74, 2, '2019-07-31 12:11:47', 5),
(75, 2, '2019-07-31 17:48:44', 90),
(76, 2, '2019-08-02 08:17:42', 92),
(77, 2, '2019-07-31 11:12:54', 94),
(78, 2, '2019-07-30 11:58:43', 18),
(79, 2, '2019-07-30 14:45:13', 95),
(80, 2, '2019-07-30 15:45:37', 99),
(81, 2, '2019-07-30 16:10:29', 102),
(82, 2, '2019-08-02 23:41:45', 100),
(83, 2, '2019-07-31 17:25:52', 97),
(84, 2, '2019-07-30 16:49:20', 52),
(85, 2, '2019-07-30 17:38:43', 35),
(86, 2, '2019-08-02 14:23:44', 98),
(87, 2, '2019-08-02 03:20:16', 104),
(88, 2, '2019-07-31 10:32:22', 105),
(89, 2, '2019-08-02 12:12:01', 108),
(90, 2, '2019-07-31 14:24:47', 107),
(91, 2, '2019-08-02 12:10:54', 109),
(92, 2, '2019-08-03 08:24:38', 110),
(93, 2, '2019-07-31 15:52:54', 11),
(94, 2, '2019-08-02 23:56:22', 113),
(95, 2, '2019-07-31 20:17:11', 114),
(96, 2, '2019-08-02 08:31:00', 117),
(97, 2, '2019-08-02 12:17:40', 24),
(98, 2, '2019-08-01 06:35:37', 118),
(99, 2, '2019-08-01 07:12:57', 119),
(100, 2, '2019-08-01 16:19:54', 23),
(101, 2, '2019-08-01 16:37:08', 2),
(102, 2, '2019-08-01 16:41:39', 123),
(103, 2, '2019-08-01 18:21:29', 111),
(104, 2, '2019-08-01 20:10:24', 26),
(105, 2, '2019-08-01 21:41:46', 16),
(106, 2, '2019-08-01 21:50:00', 124),
(107, 2, '2019-08-02 06:04:27', 37),
(108, 2, '2019-08-02 14:34:05', 128),
(109, 2, '2019-08-02 14:34:59', 127),
(110, 2, '2019-08-02 15:59:32', 121),
(111, 2, '2019-08-02 17:30:21', 120),
(112, 2, '2019-08-02 19:46:44', 131),
(113, 2, '2019-08-02 21:48:47', 89),
(114, 2, '2019-08-02 23:50:30', 55),
(115, 2, '2019-08-03 05:57:55', 50),
(116, 2, '2019-08-03 13:09:44', 135),
(117, 2, '2019-08-03 13:11:30', 136);

-- --------------------------------------------------------

--
-- Структура таблицы `db_serfing_view`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_serfing_view`;
CREATE TABLE `db_serfing_view` (
  `id` int(11) NOT NULL,
  `ident` int(11) NOT NULL DEFAULT '0',
  `time_add` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `db_serfing_view`
--

INSERT INTO `db_serfing_view` (`id`, `ident`, `time_add`, `user_id`) VALUES
(1, 2, '2019-07-26 01:23:57', 14),
(2, 1, '2019-07-26 01:24:35', 14),
(3, 2, '2019-08-05 19:55:48', 2),
(4, 1, '2019-07-26 01:52:48', 2),
(5, 2, '2019-07-26 02:48:47', 1),
(6, 2, '2019-08-07 11:11:09', 3),
(7, 1, '2019-07-28 12:07:17', 3),
(8, 2, '2019-07-31 12:05:41', 5),
(9, 1, '2019-07-26 08:51:21', 5),
(10, 2, '2019-07-26 10:06:25', 6),
(11, 1, '2019-07-26 10:07:21', 6),
(12, 2, '2019-08-07 14:21:33', 7),
(13, 1, '2019-07-28 13:41:11', 7),
(14, 2, '2019-07-27 17:53:42', 8),
(15, 1, '2019-07-27 17:54:49', 8),
(16, 3, '2019-07-26 10:53:32', 8),
(17, 4, '2019-07-26 12:37:48', 8),
(18, 2, '2019-07-26 12:41:47', 10),
(19, 1, '2019-07-26 12:42:34', 10),
(20, 4, '2019-07-26 12:44:31', 10),
(21, 3, '2019-07-26 12:45:11', 10),
(22, 4, '2019-07-26 13:01:13', 7),
(23, 2, '2019-08-05 16:40:21', 15),
(24, 1, '2019-07-27 18:35:27', 15),
(25, 4, '2019-07-27 18:40:35', 15),
(26, 3, '2019-07-26 13:11:07', 15),
(27, 2, '2019-07-27 16:36:40', 16),
(28, 4, '2019-07-26 13:24:44', 17),
(29, 2, '2019-07-26 14:45:55', 20),
(30, 1, '2019-07-26 14:46:40', 20),
(31, 4, '2019-07-26 14:57:30', 20),
(32, 3, '2019-07-26 14:59:54', 20),
(33, 2, '2019-08-08 05:46:50', 21),
(34, 1, '2019-07-27 15:11:16', 21),
(35, 4, '2019-08-07 18:54:23', 21),
(36, 3, '2019-07-26 15:06:29', 21),
(37, 2, '2019-07-27 22:24:36', 22),
(38, 1, '2019-07-27 22:25:35', 22),
(39, 4, '2019-07-26 15:13:41', 22),
(40, 3, '2019-07-26 15:14:52', 22),
(41, 2, '2019-08-07 16:17:44', 23),
(42, 2, '2019-08-07 13:17:00', 24),
(43, 1, '2019-07-26 16:12:41', 24),
(44, 4, '2019-07-26 16:26:12', 24),
(45, 3, '2019-07-26 16:31:09', 24),
(46, 2, '2019-07-26 16:31:43', 25),
(47, 3, '2019-07-26 16:33:08', 25),
(48, 4, '2019-07-26 16:34:33', 25),
(49, 1, '2019-07-26 16:35:05', 25),
(50, 2, '2019-08-03 20:09:18', 26),
(51, 1, '2019-07-26 16:36:59', 26),
(52, 4, '2019-07-26 16:37:39', 26),
(53, 3, '2019-07-26 16:38:38', 26),
(54, 7, '2019-07-26 17:34:20', 17),
(55, 7, '2019-08-08 05:46:28', 21),
(56, 1, '2019-07-26 18:14:14', 16),
(57, 7, '2019-07-26 18:24:19', 16),
(58, 4, '2019-07-26 18:25:43', 16),
(59, 3, '2019-07-26 18:28:45', 16),
(60, 7, '2019-08-07 13:10:25', 24),
(61, 6, '2019-07-26 18:33:40', 16),
(62, 6, '2019-08-01 19:42:53', 21),
(63, 7, '2019-07-26 18:41:08', 30),
(64, 2, '2019-07-26 18:42:04', 30),
(65, 1, '2019-07-26 18:42:48', 30),
(66, 6, '2019-07-26 18:43:29', 30),
(67, 7, '2019-07-28 17:40:43', 31),
(68, 2, '2019-07-28 17:42:45', 31),
(69, 1, '2019-07-26 19:14:03', 31),
(70, 6, '2019-07-28 18:15:42', 31),
(71, 7, '2019-08-07 14:20:49', 7),
(72, 6, '2019-08-01 15:21:26', 7),
(73, 7, '2019-08-07 05:58:24', 32),
(74, 2, '2019-08-07 06:00:16', 32),
(75, 1, '2019-07-26 19:29:42', 32),
(76, 6, '2019-07-26 19:30:54', 32),
(77, 7, '2019-08-07 11:10:27', 3),
(78, 6, '2019-07-30 11:03:07', 3),
(79, 7, '2019-08-07 21:05:10', 33),
(80, 2, '2019-08-07 21:10:34', 33),
(81, 1, '2019-07-28 03:22:51', 33),
(82, 6, '2019-07-30 13:57:16', 33),
(83, 7, '2019-07-26 23:03:47', 12),
(84, 7, '2019-07-26 23:07:52', 1),
(85, 6, '2019-07-26 23:08:51', 1),
(86, 7, '2019-08-02 05:53:46', 37),
(87, 2, '2019-08-02 05:55:24', 37),
(88, 1, '2019-07-27 00:14:46', 37),
(89, 6, '2019-07-27 00:16:45', 37),
(90, 6, '2019-07-28 23:18:36', 17),
(91, 2, '2019-07-27 00:25:30', 17),
(92, 7, '2019-07-27 00:38:21', 38),
(93, 2, '2019-07-27 00:39:09', 38),
(94, 1, '2019-07-27 00:39:57', 38),
(95, 6, '2019-07-27 00:40:40', 38),
(96, 7, '2019-08-05 16:37:15', 15),
(97, 6, '2019-07-31 20:21:59', 15),
(98, 7, '2019-07-27 06:24:23', 8),
(99, 6, '2019-07-27 06:26:35', 8),
(100, 7, '2019-07-27 07:09:22', 40),
(101, 2, '2019-07-27 07:10:49', 40),
(102, 1, '2019-07-27 07:12:38', 40),
(103, 6, '2019-07-27 07:13:31', 40),
(104, 2, '2019-07-27 08:21:18', 12),
(105, 1, '2019-07-27 08:22:29', 12),
(106, 6, '2019-07-27 08:28:38', 12),
(107, 7, '2019-07-27 09:39:22', 41),
(108, 7, '2019-07-27 09:56:42', 42),
(109, 2, '2019-07-27 09:57:31', 42),
(110, 1, '2019-07-27 09:58:32', 42),
(111, 6, '2019-07-27 09:59:23', 42),
(112, 7, '2019-07-27 11:11:18', 10),
(113, 6, '2019-07-27 11:12:21', 10),
(114, 7, '2019-07-27 12:23:59', 44),
(115, 12, '2019-08-04 22:01:27', 21),
(116, 7, '2019-08-07 23:13:38', 46),
(117, 6, '2019-08-01 18:48:42', 46),
(118, 1, '2019-07-27 13:50:55', 46),
(119, 2, '2019-08-07 23:14:13', 46),
(120, 12, '2019-08-04 18:53:29', 46),
(121, 7, '2019-08-08 06:19:04', 47),
(122, 2, '2019-08-08 06:19:44', 47),
(123, 1, '2019-07-27 14:29:22', 47),
(124, 12, '2019-08-05 06:48:39', 47),
(125, 6, '2019-07-27 14:32:55', 47),
(126, 12, '2019-07-27 15:43:23', 1),
(127, 7, '2019-07-27 15:44:35', 48),
(128, 2, '2019-07-27 15:45:50', 48),
(129, 1, '2019-07-27 15:46:53', 48),
(130, 7, '2019-08-07 01:05:37', 49),
(131, 12, '2019-07-27 15:48:21', 48),
(132, 2, '2019-08-07 01:06:21', 49),
(133, 6, '2019-07-27 15:49:32', 48),
(134, 1, '2019-07-27 15:49:49', 49),
(135, 12, '2019-08-04 11:31:29', 49),
(136, 6, '2019-08-01 22:50:09', 49),
(137, 7, '2019-08-04 07:05:02', 50),
(138, 12, '2019-07-27 16:35:39', 42),
(139, 12, '2019-07-27 16:57:05', 16),
(140, 7, '2019-08-08 11:12:38', 51),
(141, 2, '2019-08-07 09:01:56', 51),
(142, 1, '2019-07-27 17:19:38', 51),
(143, 7, '2019-08-07 16:17:19', 23),
(144, 7, '2019-07-27 17:49:38', 54),
(145, 1, '2019-07-27 17:51:27', 23),
(146, 12, '2019-08-04 06:03:50', 23),
(147, 12, '2019-07-27 17:55:59', 8),
(148, 7, '2019-07-27 17:57:17', 53),
(149, 6, '2019-08-01 14:28:23', 23),
(150, 7, '2019-08-05 17:29:22', 55),
(151, 2, '2019-07-27 18:01:53', 53),
(152, 2, '2019-08-05 17:32:09', 55),
(153, 1, '2019-07-27 18:02:41', 53),
(154, 1, '2019-07-27 18:03:54', 55),
(155, 12, '2019-08-02 23:38:53', 55),
(156, 6, '2019-07-27 18:07:22', 53),
(157, 6, '2019-07-27 18:08:23', 55),
(158, 13, '2019-07-27 18:36:29', 15),
(159, 12, '2019-08-04 06:43:11', 15),
(160, 13, '2019-07-27 18:42:33', 21),
(161, 13, '2019-07-27 18:48:09', 55),
(162, 4, '2019-07-27 18:49:22', 55),
(163, 7, '2019-07-27 18:59:28', 57),
(164, 2, '2019-07-27 19:00:17', 57),
(165, 1, '2019-07-27 19:01:12', 57),
(166, 13, '2019-07-27 19:02:20', 57),
(167, 6, '2019-07-27 19:05:20', 57),
(168, 4, '2019-07-27 19:08:12', 57),
(169, 4, '2019-07-27 19:59:42', 46),
(170, 13, '2019-07-27 20:00:13', 46),
(171, 7, '2019-07-27 20:07:01', 34),
(172, 2, '2019-07-27 20:08:01', 34),
(173, 1, '2019-07-27 20:09:00', 34),
(174, 13, '2019-07-27 20:10:06', 34),
(175, 6, '2019-07-27 20:11:12', 34),
(176, 12, '2019-07-27 20:11:51', 34),
(177, 7, '2019-07-27 20:29:17', 59),
(178, 2, '2019-07-27 20:29:55', 59),
(179, 1, '2019-07-27 20:30:28', 59),
(180, 13, '2019-07-27 20:31:11', 59),
(181, 12, '2019-07-27 20:31:59', 59),
(182, 6, '2019-07-27 20:36:10', 59),
(183, 13, '2019-07-27 20:36:38', 33),
(184, 12, '2019-08-04 03:21:19', 33),
(185, 13, '2019-07-27 21:06:49', 3),
(186, 12, '2019-08-05 11:06:58', 3),
(187, 7, '2019-08-03 20:42:27', 60),
(188, 2, '2019-08-03 20:43:01', 60),
(189, 1, '2019-07-27 21:39:38', 60),
(190, 13, '2019-07-27 21:40:22', 60),
(191, 12, '2019-08-03 20:47:21', 60),
(192, 6, '2019-07-31 18:03:00', 60),
(193, 7, '2019-07-27 22:23:55', 22),
(194, 13, '2019-07-27 22:26:58', 22),
(195, 12, '2019-07-27 22:27:53', 22),
(196, 6, '2019-07-27 22:29:24', 22),
(197, 12, '2019-07-27 23:29:35', 17),
(198, 12, '2019-08-04 21:37:36', 51),
(199, 6, '2019-08-01 09:00:49', 51),
(200, 7, '2019-07-28 02:34:51', 65),
(201, 2, '2019-07-28 02:39:41', 65),
(202, 1, '2019-07-28 02:40:42', 65),
(203, 12, '2019-07-28 02:42:50', 65),
(204, 6, '2019-07-28 03:00:43', 65),
(205, 7, '2019-07-28 04:01:44', 66),
(206, 7, '2019-07-28 05:17:49', 67),
(207, 2, '2019-07-28 05:21:57', 67),
(208, 1, '2019-07-28 05:22:36', 67),
(209, 12, '2019-07-28 05:23:38', 67),
(210, 6, '2019-07-28 05:26:11', 67),
(211, 7, '2019-07-28 06:55:31', 68),
(212, 2, '2019-07-28 06:56:44', 68),
(213, 1, '2019-07-28 06:57:37', 68),
(214, 12, '2019-07-28 06:58:40', 68),
(215, 6, '2019-07-28 07:02:42', 68),
(216, 6, '2019-07-28 07:32:04', 69),
(217, 7, '2019-08-07 16:59:21', 70),
(218, 2, '2019-08-07 17:00:06', 70),
(219, 1, '2019-07-28 09:18:21', 70),
(220, 12, '2019-07-28 09:18:53', 70),
(221, 6, '2019-08-01 19:30:02', 70),
(222, 7, '2019-07-28 09:25:11', 71),
(223, 2, '2019-07-28 09:28:31', 71),
(224, 1, '2019-07-28 09:29:33', 71),
(225, 12, '2019-07-28 09:30:20', 71),
(226, 6, '2019-07-28 09:34:51', 71),
(227, 7, '2019-07-28 11:38:35', 73),
(228, 2, '2019-07-28 11:39:44', 73),
(229, 7, '2019-08-07 07:47:13', 72),
(230, 1, '2019-07-28 11:41:43', 73),
(231, 12, '2019-07-28 11:42:45', 73),
(232, 6, '2019-07-28 11:43:57', 73),
(233, 7, '2019-08-07 12:23:08', 74),
(234, 2, '2019-08-07 12:24:31', 74),
(235, 1, '2019-07-28 13:29:22', 74),
(236, 12, '2019-08-04 11:33:59', 74),
(237, 6, '2019-07-30 14:29:45', 74),
(238, 12, '2019-08-04 13:32:58', 7),
(239, 7, '2019-08-07 16:21:39', 76),
(240, 2, '2019-08-07 16:22:34', 76),
(241, 12, '2019-08-04 13:25:37', 76),
(242, 6, '2019-07-31 20:52:42', 76),
(243, 7, '2019-08-06 20:52:48', 77),
(244, 2, '2019-08-06 20:53:22', 77),
(245, 12, '2019-08-04 14:33:05', 77),
(246, 6, '2019-08-02 00:51:50', 77),
(247, 12, '2019-07-28 16:21:28', 78),
(248, 16, '2019-08-04 22:01:05', 21),
(249, 7, '2019-08-01 02:10:21', 79),
(250, 2, '2019-08-01 02:11:18', 79),
(251, 16, '2019-08-01 02:12:03', 79),
(252, 12, '2019-07-28 16:40:39', 79),
(253, 6, '2019-08-01 02:13:18', 79),
(254, 16, '2019-08-04 06:40:29', 15),
(255, 16, '2019-08-04 18:54:01', 46),
(256, 16, '2019-07-28 17:45:02', 31),
(257, 12, '2019-07-28 17:48:55', 31),
(258, 7, '2019-08-05 22:22:40', 80),
(259, 2, '2019-08-05 22:24:21', 80),
(260, 16, '2019-08-01 21:33:58', 80),
(261, 12, '2019-07-28 19:28:03', 80),
(262, 6, '2019-08-01 21:36:38', 80),
(263, 7, '2019-08-07 19:27:21', 81),
(264, 2, '2019-08-07 19:28:21', 81),
(265, 16, '2019-08-04 16:42:55', 81),
(266, 12, '2019-08-04 16:44:07', 81),
(267, 6, '2019-07-28 20:07:31', 81),
(268, 16, '2019-08-05 13:41:22', 33),
(269, 16, '2019-08-04 13:25:05', 76),
(270, 7, '2019-07-30 00:00:15', 82),
(271, 2, '2019-07-30 00:00:56', 82),
(272, 16, '2019-08-04 11:31:01', 49),
(273, 7, '2019-08-02 14:57:17', 83),
(274, 2, '2019-08-02 14:31:26', 83),
(275, 16, '2019-08-02 15:23:38', 83),
(276, 6, '2019-07-29 02:17:32', 83),
(277, 7, '2019-07-29 03:55:00', 85),
(278, 2, '2019-07-29 03:55:38', 85),
(279, 16, '2019-07-29 03:56:12', 85),
(280, 6, '2019-07-29 03:56:55', 85),
(281, 7, '2019-07-29 04:41:06', 84),
(282, 2, '2019-07-29 04:42:40', 84),
(283, 16, '2019-07-29 04:46:35', 84),
(284, 6, '2019-07-29 04:50:51', 84),
(285, 16, '2019-08-04 11:32:12', 74),
(286, 16, '2019-08-05 11:06:13', 3),
(287, 2, '2019-08-07 07:48:36', 72),
(288, 16, '2019-08-05 13:22:13', 72),
(289, 6, '2019-08-01 09:42:56', 72),
(290, 16, '2019-07-29 07:40:52', 82),
(291, 6, '2019-07-29 07:42:02', 82),
(292, 7, '2019-07-29 07:53:50', 87),
(293, 2, '2019-07-29 07:56:26', 87),
(294, 16, '2019-07-29 08:01:57', 87),
(295, 6, '2019-07-29 08:03:57', 87),
(296, 7, '2019-07-31 11:59:33', 5),
(297, 16, '2019-07-31 12:06:38', 5),
(298, 6, '2019-07-31 12:07:51', 5),
(299, 16, '2019-08-05 13:50:43', 7),
(300, 7, '2019-07-30 17:30:42', 35),
(301, 2, '2019-07-30 17:31:30', 35),
(302, 16, '2019-07-30 17:32:44', 35),
(303, 6, '2019-07-30 17:37:18', 35),
(304, 7, '2019-07-29 15:56:13', 89),
(305, 7, '2019-08-07 16:02:54', 90),
(306, 2, '2019-08-07 16:04:10', 90),
(307, 16, '2019-07-31 17:52:35', 90),
(308, 6, '2019-07-31 17:55:26', 90),
(309, 16, '2019-08-04 14:32:33', 77),
(310, 2, '2019-08-02 08:22:24', 92),
(311, 16, '2019-08-02 08:24:37', 92),
(312, 6, '2019-07-31 22:01:17', 92),
(313, 7, '2019-08-02 08:21:21', 92),
(314, 16, '2019-08-03 20:46:33', 60),
(315, 7, '2019-07-29 22:23:40', 93),
(316, 2, '2019-07-29 22:25:29', 93),
(317, 7, '2019-08-07 16:37:18', 94),
(318, 2, '2019-08-07 16:38:05', 94),
(319, 16, '2019-08-04 16:21:32', 94),
(320, 6, '2019-07-31 11:10:53', 94),
(321, 7, '2019-07-30 11:53:02', 18),
(322, 2, '2019-07-30 11:53:41', 18),
(323, 16, '2019-07-30 11:55:43', 18),
(324, 6, '2019-07-30 11:56:46', 18),
(325, 19, '2019-07-30 12:18:27', 21),
(326, 19, '2019-07-30 12:29:27', 49),
(327, 19, '2019-07-30 12:31:41', 46),
(328, 19, '2019-07-30 12:56:58', 94),
(329, 19, '2019-07-30 13:58:45', 33),
(330, 19, '2019-07-30 14:27:25', 74),
(331, 19, '2019-07-30 14:39:44', 92),
(332, 19, '2019-07-30 14:43:00', 7),
(333, 7, '2019-07-30 14:47:30', 95),
(334, 2, '2019-07-30 14:49:03', 95),
(335, 19, '2019-07-30 14:49:43', 95),
(336, 16, '2019-07-30 14:50:46', 95),
(337, 6, '2019-07-30 14:52:13', 95),
(338, 7, '2019-08-07 17:22:37', 97),
(339, 7, '2019-08-02 14:18:42', 98),
(340, 7, '2019-07-30 15:47:31', 99),
(341, 6, '2019-08-01 09:32:24', 98),
(342, 2, '2019-07-30 15:48:17', 99),
(343, 19, '2019-07-30 15:49:03', 99),
(344, 16, '2019-07-30 15:49:48', 99),
(345, 6, '2019-07-30 15:52:46', 99),
(346, 2, '2019-08-07 17:24:02', 97),
(347, 7, '2019-07-30 16:03:31', 102),
(348, 7, '2019-08-06 20:55:29', 100),
(349, 2, '2019-08-06 20:56:46', 100),
(350, 19, '2019-07-30 16:06:18', 77),
(351, 16, '2019-08-02 00:32:28', 100),
(352, 6, '2019-08-02 00:34:17', 100),
(353, 16, '2019-07-31 17:20:57', 97),
(354, 6, '2019-07-31 17:23:40', 97),
(355, 16, '2019-07-30 16:36:54', 27),
(356, 7, '2019-07-30 16:37:50', 52),
(357, 2, '2019-07-30 16:41:41', 52),
(358, 16, '2019-07-30 16:43:40', 52),
(359, 6, '2019-07-30 16:46:31', 52),
(360, 2, '2019-08-02 14:19:37', 98),
(361, 16, '2019-08-02 14:20:14', 98),
(362, 16, '2019-07-30 18:39:12', 102),
(363, 7, '2019-08-08 02:12:43', 104),
(364, 2, '2019-08-08 02:09:45', 104),
(365, 16, '2019-08-05 03:01:03', 104),
(366, 6, '2019-08-02 03:28:34', 104),
(367, 7, '2019-07-31 10:17:58', 105),
(368, 2, '2019-07-31 10:23:28', 105),
(369, 16, '2019-07-31 10:25:03', 105),
(370, 7, '2019-07-31 10:26:55', 106),
(371, 6, '2019-07-31 10:28:17', 105),
(372, 7, '2019-08-04 22:30:59', 107),
(373, 2, '2019-08-04 22:32:21', 107),
(374, 16, '2019-08-04 22:28:43', 107),
(375, 6, '2019-07-31 14:22:32', 107),
(376, 7, '2019-08-08 06:09:50', 110),
(377, 2, '2019-08-08 06:10:57', 110),
(378, 16, '2019-08-03 08:21:45', 110),
(379, 6, '2019-08-01 19:17:11', 110),
(380, 7, '2019-08-01 19:19:01', 109),
(381, 2, '2019-08-01 19:19:59', 109),
(382, 16, '2019-08-01 19:30:03', 109),
(383, 6, '2019-07-31 16:15:18', 111),
(384, 7, '2019-07-31 16:33:30', 111),
(385, 16, '2019-08-01 19:29:19', 70),
(386, 7, '2019-07-31 19:34:32', 112),
(387, 2, '2019-07-31 19:35:29', 112),
(388, 16, '2019-07-31 19:39:33', 112),
(389, 6, '2019-07-31 19:40:38', 112),
(390, 7, '2019-08-02 23:33:01', 113),
(391, 2, '2019-08-02 23:33:41', 113),
(392, 16, '2019-08-02 23:43:54', 113),
(393, 6, '2019-07-31 19:55:06', 113),
(394, 7, '2019-07-31 20:10:56', 114),
(395, 2, '2019-07-31 20:11:50', 114),
(396, 16, '2019-07-31 20:12:41', 114),
(397, 6, '2019-07-31 20:13:58', 114),
(398, 7, '2019-07-31 21:33:11', 115),
(399, 2, '2019-07-31 21:34:03', 115),
(400, 16, '2019-07-31 21:35:06', 115),
(401, 6, '2019-07-31 21:35:37', 115),
(402, 8, '2019-08-08 05:46:07', 21),
(403, 8, '2019-08-07 13:58:28', 117),
(404, 7, '2019-08-07 13:59:01', 117),
(405, 2, '2019-08-07 13:59:44', 117),
(406, 16, '2019-08-05 01:36:26', 117),
(407, 6, '2019-07-31 22:38:44', 117),
(408, 9, '2019-08-08 09:17:31', 21),
(409, 8, '2019-08-07 12:56:58', 24),
(410, 16, '2019-08-05 14:37:57', 24),
(411, 8, '2019-08-06 20:53:49', 100),
(412, 6, '2019-07-31 23:46:17', 24),
(413, 9, '2019-08-02 12:03:13', 24),
(414, 8, '2019-08-01 02:08:07', 79),
(415, 8, '2019-08-08 02:08:07', 104),
(416, 9, '2019-08-08 02:13:24', 104),
(417, 8, '2019-08-08 06:08:38', 110),
(418, 8, '2019-08-02 08:20:22', 92),
(419, 8, '2019-08-07 11:08:50', 3),
(420, 6, '2019-08-01 06:30:04', 118),
(421, 16, '2019-08-04 07:16:38', 118),
(422, 2, '2019-08-07 18:14:14', 118),
(423, 7, '2019-08-07 18:13:21', 118),
(424, 8, '2019-08-07 18:12:14', 118),
(425, 8, '2019-08-01 07:03:06', 119),
(426, 7, '2019-08-01 07:03:54', 119),
(427, 2, '2019-08-01 07:05:09', 119),
(428, 16, '2019-08-01 07:10:05', 119),
(429, 6, '2019-08-01 07:11:21', 119),
(430, 8, '2019-08-01 08:45:32', 5),
(431, 8, '2019-08-08 11:11:38', 51),
(432, 16, '2019-08-04 21:36:49', 51),
(433, 8, '2019-08-02 14:17:56', 98),
(434, 8, '2019-08-07 07:46:30', 72),
(435, 8, '2019-08-04 17:32:56', 108),
(436, 7, '2019-08-04 17:32:22', 108),
(437, 16, '2019-08-05 12:35:54', 108),
(438, 9, '2019-08-01 09:52:07', 108),
(439, 6, '2019-08-01 09:53:36', 108),
(440, 8, '2019-08-02 11:45:58', 109),
(441, 6, '2019-08-01 10:41:17', 109),
(442, 9, '2019-08-01 10:41:57', 109),
(443, 8, '2019-08-06 20:52:09', 77),
(444, 21, '2019-08-05 22:31:20', 21),
(445, 21, '2019-08-01 12:20:31', 120),
(446, 8, '2019-08-07 07:56:26', 120),
(447, 7, '2019-08-07 07:57:33', 120),
(448, 2, '2019-08-07 08:00:32', 120),
(449, 16, '2019-08-04 08:34:00', 120),
(450, 6, '2019-08-01 12:27:26', 120),
(451, 21, '2019-08-02 14:11:24', 7),
(452, 8, '2019-08-07 14:19:24', 7),
(453, 9, '2019-08-02 14:20:44', 7),
(454, 21, '2019-08-02 15:35:43', 23),
(455, 8, '2019-08-07 16:16:53', 23),
(456, 16, '2019-08-04 06:02:59', 23),
(457, 21, '2019-08-01 14:36:51', 110),
(458, 21, '2019-08-02 15:56:53', 121),
(459, 8, '2019-08-08 01:47:34', 121),
(460, 7, '2019-08-08 01:48:14', 121),
(461, 2, '2019-08-08 01:48:51', 121),
(462, 21, '2019-08-01 15:30:13', 100),
(463, 22, '2019-08-03 15:57:48', 21),
(464, 21, '2019-08-01 15:40:52', 50),
(465, 8, '2019-08-04 06:57:44', 50),
(466, 16, '2019-08-04 07:01:43', 50),
(467, 2, '2019-08-04 07:06:12', 50),
(468, 21, '2019-08-05 22:10:05', 76),
(469, 8, '2019-08-07 16:20:58', 76),
(470, 6, '2019-08-01 15:54:49', 50),
(471, 22, '2019-08-01 15:55:09', 76),
(472, 9, '2019-08-04 07:07:13', 50),
(473, 21, '2019-08-01 16:21:57', 3),
(474, 9, '2019-08-05 11:07:46', 3),
(475, 21, '2019-08-01 16:32:17', 2),
(476, 8, '2019-08-05 19:54:38', 2),
(477, 8, '2019-08-01 16:39:20', 123),
(478, 21, '2019-08-01 16:45:32', 123),
(479, 7, '2019-08-01 16:46:30', 123),
(480, 2, '2019-08-01 16:47:29', 123),
(481, 22, '2019-08-01 16:48:47', 123),
(482, 16, '2019-08-01 16:49:25', 123),
(483, 6, '2019-08-01 16:51:06', 123),
(484, 22, '2019-08-01 17:07:51', 17),
(485, 21, '2019-08-01 17:41:16', 98),
(486, 22, '2019-08-01 17:42:41', 98),
(487, 21, '2019-08-01 17:48:47', 111),
(488, 8, '2019-08-07 23:14:43', 46),
(489, 21, '2019-08-01 18:57:22', 46),
(490, 22, '2019-08-01 18:58:07', 46),
(491, 22, '2019-08-01 19:15:47', 110),
(492, 21, '2019-08-01 19:17:45', 109),
(493, 22, '2019-08-01 19:20:36', 3),
(494, 21, '2019-08-01 19:24:44', 70),
(495, 8, '2019-08-07 16:58:41', 70),
(496, 22, '2019-08-01 19:27:42', 109),
(497, 22, '2019-08-01 19:28:06', 120),
(498, 22, '2019-08-01 19:28:14', 70),
(499, 9, '2019-08-01 19:31:35', 70),
(500, 21, '2019-08-01 19:53:13', 114),
(501, 8, '2019-08-01 19:53:49', 114),
(502, 22, '2019-08-01 19:54:27', 114),
(503, 9, '2019-08-01 19:55:10', 114),
(504, 21, '2019-08-01 20:04:07', 26),
(505, 8, '2019-08-03 20:07:47', 26),
(506, 7, '2019-08-03 20:08:40', 26),
(507, 22, '2019-08-03 20:12:52', 26),
(508, 16, '2019-08-03 20:13:24', 26),
(509, 6, '2019-08-01 20:08:01', 26),
(510, 21, '2019-08-01 21:14:19', 124),
(511, 8, '2019-08-01 21:16:04', 124),
(512, 21, '2019-08-05 22:21:41', 80),
(513, 21, '2019-08-01 21:25:42', 16),
(514, 8, '2019-08-05 19:57:45', 80),
(515, 22, '2019-08-01 21:32:29', 80),
(516, 7, '2019-08-01 21:33:32', 124),
(517, 2, '2019-08-01 21:36:40', 124),
(518, 9, '2019-08-05 22:28:05', 80),
(519, 22, '2019-08-01 21:39:58', 124),
(520, 16, '2019-08-01 21:42:16', 124),
(521, 6, '2019-08-01 21:53:18', 124),
(522, 21, '2019-08-01 22:27:59', 117),
(523, 22, '2019-08-01 22:28:46', 117),
(524, 21, '2019-08-01 22:45:37', 49),
(525, 8, '2019-08-07 01:04:56', 49),
(526, 22, '2019-08-02 23:47:04', 49),
(527, 9, '2019-08-07 01:07:26', 49),
(528, 21, '2019-08-01 23:17:48', 24),
(529, 22, '2019-08-01 23:21:37', 24),
(530, 22, '2019-08-02 00:31:32', 100),
(531, 9, '2019-08-02 00:33:18', 100),
(532, 21, '2019-08-02 00:47:40', 77),
(533, 22, '2019-08-02 00:50:06', 77),
(534, 9, '2019-08-04 22:09:35', 77),
(535, 22, '2019-08-02 02:57:39', 23),
(536, 21, '2019-08-02 03:22:19', 104),
(537, 22, '2019-08-02 03:25:50', 104),
(538, 21, '2019-08-02 05:33:02', 15),
(539, 8, '2019-08-05 16:36:21', 15),
(540, 22, '2019-08-02 05:45:05', 15),
(541, 21, '2019-08-02 05:49:53', 37),
(542, 8, '2019-08-02 05:51:00', 37),
(543, 22, '2019-08-02 05:58:43', 37),
(544, 16, '2019-08-02 05:59:42', 37),
(545, 21, '2019-08-02 06:42:53', 60),
(546, 8, '2019-08-03 20:41:49', 60),
(547, 22, '2019-08-03 20:45:55', 60),
(548, 8, '2019-08-05 17:28:44', 55),
(549, 21, '2019-08-02 07:49:17', 55),
(550, 22, '2019-08-02 08:18:48', 92),
(551, 21, '2019-08-02 08:19:34', 92),
(552, 21, '2019-08-02 08:48:30', 74),
(553, 8, '2019-08-07 12:22:29', 74),
(554, 22, '2019-08-02 08:52:18', 74),
(555, 21, '2019-08-02 08:53:14', 72),
(556, 22, '2019-08-02 08:53:53', 72),
(557, 9, '2019-08-07 07:51:36', 72),
(558, 21, '2019-08-02 11:39:05', 126),
(559, 8, '2019-08-02 11:39:35', 126),
(560, 7, '2019-08-02 11:42:33', 126),
(561, 2, '2019-08-02 11:43:16', 126),
(562, 22, '2019-08-02 11:43:46', 126),
(563, 16, '2019-08-02 11:44:22', 126),
(564, 9, '2019-08-02 11:45:18', 126),
(565, 21, '2019-08-02 12:26:17', 108),
(566, 9, '2019-08-02 13:51:11', 26),
(567, 21, '2019-08-02 14:06:08', 84),
(568, 21, '2019-08-02 14:07:31', 83),
(569, 8, '2019-08-02 14:08:56', 83),
(570, 22, '2019-08-02 14:14:00', 7),
(571, 21, '2019-08-02 14:21:33', 127),
(572, 8, '2019-08-03 16:19:31', 127),
(573, 7, '2019-08-03 16:20:14', 127),
(574, 21, '2019-08-02 14:27:28', 128),
(575, 2, '2019-08-03 16:21:00', 127),
(576, 16, '2019-08-05 07:33:02', 128),
(577, 22, '2019-08-03 16:22:07', 127),
(578, 22, '2019-08-02 14:28:34', 128),
(579, 16, '2019-08-03 16:22:41', 127),
(580, 8, '2019-08-07 16:41:19', 128),
(581, 2, '2019-08-07 16:44:30', 128),
(582, 9, '2019-08-07 16:45:36', 128),
(583, 22, '2019-08-02 14:32:18', 83),
(584, 9, '2019-08-02 14:37:08', 127),
(585, 23, '2019-08-04 22:00:43', 21),
(586, 12, '2019-08-05 12:34:29', 108),
(587, 22, '2019-08-02 16:18:19', 108),
(588, 2, '2019-08-02 16:22:00', 108),
(589, 23, '2019-08-04 20:25:31', 121),
(590, 22, '2019-08-03 19:47:40', 121),
(591, 16, '2019-08-04 20:26:06', 121),
(592, 12, '2019-08-04 20:26:36', 121),
(593, 21, '2019-08-02 16:54:55', 130),
(594, 8, '2019-08-02 16:55:40', 130),
(595, 23, '2019-08-02 17:02:02', 130),
(596, 23, '2019-08-02 17:12:09', 98),
(597, 12, '2019-08-02 17:12:47', 98),
(598, 23, '2019-08-04 08:32:58', 120),
(599, 12, '2019-08-04 08:35:19', 120),
(600, 9, '2019-08-07 08:02:22', 120),
(601, 8, '2019-08-07 16:57:15', 131),
(602, 7, '2019-08-07 16:59:49', 131),
(603, 2, '2019-08-07 17:05:02', 131),
(604, 23, '2019-08-02 19:29:33', 131),
(605, 22, '2019-08-02 19:32:04', 131),
(606, 12, '2019-08-05 07:34:10', 128),
(607, 7, '2019-08-07 16:40:21', 128),
(608, 16, '2019-08-02 19:34:39', 131),
(609, 12, '2019-08-02 19:38:47', 131),
(610, 12, '2019-08-04 05:55:26', 127),
(611, 24, '2019-08-05 22:00:55', 21),
(612, 24, '2019-08-05 11:40:18', 117),
(613, 23, '2019-08-05 11:40:58', 117),
(614, 8, '2019-08-02 21:52:03', 89),
(615, 12, '2019-08-05 11:41:31', 117),
(616, 2, '2019-08-02 21:56:25', 89),
(617, 12, '2019-08-02 22:03:10', 89),
(618, 22, '2019-08-02 22:04:04', 89),
(619, 24, '2019-08-05 22:13:00', 76),
(620, 8, '2019-08-02 23:32:15', 113),
(621, 24, '2019-08-04 14:29:36', 100),
(622, 12, '2019-08-02 23:35:36', 100),
(623, 24, '2019-08-05 17:33:41', 55),
(624, 23, '2019-08-05 17:36:12', 55),
(625, 22, '2019-08-02 23:37:37', 55),
(626, 16, '2019-08-02 23:38:16', 55),
(627, 22, '2019-08-02 23:42:06', 113),
(628, 12, '2019-08-02 23:43:25', 113),
(629, 23, '2019-08-02 23:44:29', 100),
(630, 23, '2019-08-02 23:45:04', 113),
(631, 24, '2019-08-04 11:29:57', 49),
(632, 23, '2019-08-04 11:30:28', 49),
(633, 24, '2019-08-02 23:49:05', 113),
(634, 9, '2019-08-02 23:49:50', 113),
(635, 9, '2019-08-05 17:41:08', 55),
(636, 24, '2019-08-04 10:05:56', 51),
(637, 24, '2019-08-04 20:24:40', 121),
(638, 8, '2019-08-03 02:21:41', 133),
(639, 12, '2019-08-03 02:24:30', 133),
(640, 24, '2019-08-04 07:00:14', 50),
(641, 12, '2019-08-04 07:02:24', 50),
(642, 23, '2019-08-04 07:00:55', 50),
(643, 8, '2019-08-07 19:26:29', 81),
(644, 25, '2019-08-03 07:17:00', 81),
(645, 24, '2019-08-04 16:40:40', 81),
(646, 23, '2019-08-04 16:42:07', 81),
(647, 25, '2019-08-03 07:47:09', 127),
(648, 24, '2019-08-03 07:47:41', 127),
(649, 24, '2019-08-03 07:59:11', 110),
(650, 12, '2019-08-03 08:16:50', 110),
(651, 23, '2019-08-03 08:20:53', 110),
(652, 9, '2019-08-03 08:22:50', 110),
(653, 8, '2019-08-03 08:38:23', 134),
(654, 7, '2019-08-03 08:39:27', 134),
(655, 2, '2019-08-03 08:41:07', 134),
(656, 24, '2019-08-03 08:41:49', 134),
(657, 23, '2019-08-03 08:45:36', 134),
(658, 16, '2019-08-03 08:46:51', 134),
(659, 12, '2019-08-03 08:47:32', 134),
(660, 9, '2019-08-03 08:49:14', 134),
(661, 24, '2019-08-04 11:30:45', 74),
(662, 23, '2019-08-04 11:31:23', 74),
(663, 9, '2019-08-06 12:05:17', 74),
(664, 24, '2019-08-05 12:37:25', 108),
(665, 24, '2019-08-03 09:34:49', 98),
(666, 24, '2019-08-03 09:49:19', 131),
(667, 26, '2019-08-05 13:18:15', 72),
(668, 24, '2019-08-05 13:18:51', 72),
(669, 23, '2019-08-05 13:20:14', 72),
(670, 12, '2019-08-05 13:23:04', 72),
(671, 26, '2019-08-03 11:58:30', 127),
(672, 23, '2019-08-03 11:59:19', 127),
(673, 23, '2019-08-04 18:54:32', 46),
(674, 26, '2019-08-04 18:55:34', 46),
(675, 24, '2019-08-04 18:55:03', 46),
(676, 26, '2019-08-03 12:01:29', 23),
(677, 8, '2019-08-05 16:54:26', 135),
(678, 7, '2019-08-05 16:55:01', 135),
(679, 2, '2019-08-05 16:55:35', 135),
(680, 8, '2019-08-07 10:10:06', 137),
(681, 27, '2019-08-03 13:02:12', 135),
(682, 26, '2019-08-03 13:03:23', 135),
(683, 24, '2019-08-05 16:56:03', 135),
(684, 8, '2019-08-05 01:19:49', 136),
(685, 23, '2019-08-05 16:56:39', 135),
(686, 16, '2019-08-03 13:05:06', 135),
(687, 12, '2019-08-03 13:05:53', 135),
(688, 7, '2019-08-07 10:11:05', 137),
(689, 2, '2019-08-05 01:22:45', 136),
(690, 7, '2019-08-05 01:21:54', 136),
(691, 27, '2019-08-04 20:02:39', 128),
(692, 26, '2019-08-04 20:04:13', 128),
(693, 24, '2019-08-05 20:29:43', 128),
(694, 2, '2019-08-07 10:12:37', 137),
(695, 27, '2019-08-04 15:56:11', 137),
(696, 26, '2019-08-04 16:08:06', 137),
(697, 24, '2019-08-04 16:08:43', 137),
(698, 23, '2019-08-04 16:10:09', 137),
(699, 16, '2019-08-04 16:11:05', 137),
(700, 12, '2019-08-04 16:11:41', 137),
(701, 27, '2019-08-04 14:30:10', 77),
(702, 26, '2019-08-04 14:30:41', 77),
(703, 24, '2019-08-05 20:28:03', 77),
(704, 23, '2019-08-05 20:28:37', 77),
(705, 27, '2019-08-04 21:59:38', 21),
(706, 26, '2019-08-04 22:00:00', 21),
(707, 8, '2019-08-03 13:58:33', 138),
(708, 7, '2019-08-03 13:59:37', 138),
(709, 2, '2019-08-03 14:01:02', 138),
(710, 27, '2019-08-03 14:01:45', 138),
(711, 26, '2019-08-03 14:05:35', 138),
(712, 8, '2019-08-03 14:07:45', 139),
(713, 27, '2019-08-04 21:22:27', 51),
(714, 26, '2019-08-04 21:35:03', 51),
(715, 27, '2019-08-03 14:14:03', 98),
(716, 26, '2019-08-03 14:14:39', 98),
(717, 9, '2019-08-03 14:15:19', 98),
(718, 27, '2019-08-05 00:32:15', 49),
(719, 26, '2019-08-05 00:32:46', 49),
(720, 27, '2019-08-03 14:30:17', 110),
(721, 26, '2019-08-03 14:30:56', 110),
(722, 27, '2019-08-04 21:23:19', 117),
(723, 26, '2019-08-05 01:37:11', 117),
(724, 9, '2019-08-03 14:34:51', 117),
(725, 9, '2019-08-05 15:41:14', 142),
(726, 12, '2019-08-03 14:40:57', 142),
(727, 8, '2019-08-07 16:36:46', 94),
(728, 16, '2019-08-03 14:42:28', 142),
(729, 27, '2019-08-04 16:18:21', 94),
(730, 26, '2019-08-04 16:18:54', 94),
(731, 24, '2019-08-04 16:19:25', 94),
(732, 23, '2019-08-04 16:20:59', 94),
(733, 12, '2019-08-04 16:22:04', 94),
(734, 23, '2019-08-03 14:50:14', 142),
(735, 9, '2019-08-07 16:38:44', 94),
(736, 24, '2019-08-03 14:51:46', 142),
(737, 26, '2019-08-03 14:53:06', 142),
(738, 8, '2019-08-04 22:29:14', 144),
(739, 27, '2019-08-03 14:54:38', 142),
(740, 7, '2019-08-04 22:31:56', 144),
(741, 2, '2019-08-04 22:33:58', 144),
(742, 7, '2019-08-03 15:00:00', 142),
(743, 8, '2019-08-03 15:00:59', 142),
(744, 27, '2019-08-04 22:35:54', 144),
(745, 8, '2019-08-03 15:04:42', 147),
(746, 7, '2019-08-03 15:05:46', 147),
(747, 2, '2019-08-03 15:16:23', 142),
(748, 26, '2019-08-04 17:28:52', 108),
(749, 27, '2019-08-04 18:56:04', 46),
(750, 8, '2019-08-05 11:24:57', 143),
(751, 7, '2019-08-05 11:25:41', 143),
(752, 2, '2019-08-05 11:27:55', 143),
(753, 27, '2019-08-03 15:29:32', 143),
(754, 8, '2019-08-05 04:47:56', 148),
(755, 7, '2019-08-05 04:48:44', 148),
(756, 2, '2019-08-05 04:50:14', 148),
(757, 27, '2019-08-05 04:51:38', 148),
(758, 26, '2019-08-05 11:29:13', 143),
(759, 24, '2019-08-05 11:29:50', 143),
(760, 26, '2019-08-05 04:53:01', 148),
(761, 23, '2019-08-05 11:30:51', 143),
(762, 24, '2019-08-05 04:54:00', 148),
(763, 16, '2019-08-05 11:31:28', 143),
(764, 12, '2019-08-05 11:32:17', 143),
(765, 9, '2019-08-05 11:33:16', 143),
(766, 16, '2019-08-05 04:56:18', 148),
(767, 23, '2019-08-05 04:58:38', 148),
(768, 25, '2019-08-03 15:41:10', 143),
(769, 22, '2019-08-03 15:41:46', 143),
(770, 12, '2019-08-05 04:57:56', 148),
(771, 27, '2019-08-03 15:42:29', 50),
(772, 26, '2019-08-03 15:43:19', 50),
(773, 25, '2019-08-03 15:44:59', 148),
(774, 22, '2019-08-03 15:47:36', 148),
(775, 25, '2019-08-03 15:47:55', 94),
(776, 22, '2019-08-03 15:48:25', 94),
(777, 25, '2019-08-03 15:57:04', 21),
(778, 8, '2019-08-03 16:05:36', 150),
(779, 8, '2019-08-03 16:17:41', 151),
(780, 7, '2019-08-03 16:20:07', 151),
(781, 27, '2019-08-03 16:21:33', 127),
(782, 9, '2019-08-05 04:57:06', 148),
(783, 12, '2019-08-04 22:28:02', 107),
(784, 8, '2019-08-03 16:32:55', 152),
(785, 8, '2019-08-07 18:43:32', 153),
(786, 22, '2019-08-03 16:33:51', 107),
(787, 7, '2019-08-03 16:34:00', 152),
(788, 7, '2019-08-07 18:45:08', 153),
(789, 23, '2019-08-04 22:29:31', 107),
(790, 2, '2019-08-03 16:35:20', 152),
(791, 24, '2019-08-04 22:31:36', 107),
(792, 27, '2019-08-03 16:36:13', 152),
(793, 25, '2019-08-03 16:36:25', 107),
(794, 26, '2019-08-03 16:37:10', 152),
(795, 26, '2019-08-04 22:33:39', 107),
(796, 27, '2019-08-04 22:32:58', 107),
(797, 2, '2019-08-07 18:48:05', 153),
(798, 24, '2019-08-03 16:39:35', 152),
(799, 27, '2019-08-03 16:40:19', 153),
(800, 8, '2019-08-04 22:30:12', 107),
(801, 26, '2019-08-03 16:41:17', 153),
(802, 12, '2019-08-03 16:48:35', 153),
(803, 22, '2019-08-03 16:52:46', 153),
(804, 8, '2019-08-03 16:54:29', 154),
(805, 24, '2019-08-05 20:04:25', 153),
(806, 23, '2019-08-05 20:08:25', 153),
(807, 7, '2019-08-03 16:59:12', 154),
(808, 16, '2019-08-03 17:00:32', 153),
(809, 22, '2019-08-03 17:14:11', 135),
(810, 9, '2019-08-05 16:58:03', 135),
(811, 8, '2019-08-03 17:29:20', 63),
(812, 7, '2019-08-03 17:30:20', 63),
(813, 27, '2019-08-03 17:47:58', 100),
(814, 8, '2019-08-03 18:01:42', 155),
(815, 26, '2019-08-04 22:37:27', 144),
(816, 24, '2019-08-04 22:39:20', 144),
(817, 23, '2019-08-03 18:13:49', 144),
(818, 22, '2019-08-03 18:15:38', 144),
(819, 16, '2019-08-04 22:51:45', 144),
(820, 12, '2019-08-04 22:52:53', 144),
(821, 9, '2019-08-04 22:58:23', 144),
(822, 22, '2019-08-03 18:26:40', 155),
(823, 7, '2019-08-03 18:30:26', 155),
(824, 8, '2019-08-03 19:14:32', 156),
(825, 7, '2019-08-03 19:20:45', 156),
(826, 2, '2019-08-03 19:23:35', 156),
(827, 27, '2019-08-03 19:26:07', 156),
(828, 26, '2019-08-03 19:28:10', 156),
(829, 24, '2019-08-03 19:30:17', 156),
(830, 27, '2019-08-04 20:21:51', 121),
(831, 26, '2019-08-04 20:23:56', 121),
(832, 23, '2019-08-03 19:44:42', 156),
(833, 22, '2019-08-03 19:46:27', 156),
(834, 16, '2019-08-03 19:47:12', 156),
(835, 12, '2019-08-03 19:48:04', 156),
(836, 9, '2019-08-04 20:17:51', 121),
(837, 27, '2019-08-03 20:09:51', 26),
(838, 26, '2019-08-03 20:10:31', 26),
(839, 24, '2019-08-03 20:11:31', 26),
(840, 23, '2019-08-03 20:12:12', 26),
(841, 12, '2019-08-03 20:13:58', 26),
(842, 27, '2019-08-03 20:15:25', 81),
(843, 26, '2019-08-03 20:16:00', 81),
(844, 22, '2019-08-03 20:17:23', 81),
(845, 27, '2019-08-03 20:43:38', 60),
(846, 26, '2019-08-03 20:44:12', 60),
(847, 24, '2019-08-03 20:44:47', 60),
(848, 23, '2019-08-03 20:45:25', 60),
(849, 2, '2019-08-03 23:27:28', 147),
(850, 27, '2019-08-03 23:32:31', 147),
(851, 24, '2019-08-03 23:33:17', 147),
(852, 26, '2019-08-03 23:33:50', 147),
(853, 12, '2019-08-03 23:35:14', 147),
(854, 23, '2019-08-03 23:35:49', 147),
(855, 16, '2019-08-03 23:36:35', 147),
(856, 8, '2019-08-08 05:53:49', 129),
(857, 7, '2019-08-08 05:54:55', 129),
(858, 2, '2019-08-08 05:55:46', 129),
(859, 27, '2019-08-04 02:28:12', 129),
(860, 12, '2019-08-04 02:28:58', 129),
(861, 26, '2019-08-04 02:29:33', 129),
(862, 24, '2019-08-05 16:42:35', 129),
(863, 16, '2019-08-04 02:33:02', 129),
(864, 23, '2019-08-04 02:34:03', 129),
(865, 9, '2019-08-08 05:57:49', 129),
(866, 8, '2019-08-07 21:01:01', 33),
(867, 27, '2019-08-04 02:47:48', 33),
(868, 26, '2019-08-05 13:30:19', 33),
(869, 24, '2019-08-05 13:33:02', 33),
(870, 9, '2019-08-08 03:03:46', 33),
(871, 27, '2019-08-05 09:43:24', 136),
(872, 26, '2019-08-05 09:44:00', 136),
(873, 24, '2019-08-05 09:46:33', 136),
(874, 23, '2019-08-05 09:47:41', 136),
(875, 16, '2019-08-05 09:48:23', 136),
(876, 12, '2019-08-05 09:44:49', 136),
(877, 8, '2019-08-08 06:18:20', 47),
(878, 27, '2019-08-05 06:45:27', 47),
(879, 26, '2019-08-05 06:46:07', 47),
(880, 24, '2019-08-05 06:46:41', 47),
(881, 23, '2019-08-05 06:47:21', 47),
(882, 16, '2019-08-05 06:47:53', 47),
(883, 8, '2019-08-06 15:30:56', 157),
(884, 7, '2019-08-06 15:32:22', 157),
(885, 2, '2019-08-06 15:33:36', 157),
(886, 27, '2019-08-04 05:35:17', 157),
(887, 26, '2019-08-04 05:35:53', 157),
(888, 24, '2019-08-04 05:36:43', 157),
(889, 23, '2019-08-04 05:39:57', 157),
(890, 16, '2019-08-04 05:41:34', 157),
(891, 12, '2019-08-04 05:42:56', 157),
(892, 27, '2019-08-04 05:59:25', 23),
(893, 24, '2019-08-04 06:00:33', 23),
(894, 23, '2019-08-04 06:01:45', 23),
(895, 9, '2019-08-07 16:18:37', 23),
(896, 26, '2019-08-04 06:12:57', 15),
(897, 24, '2019-08-05 16:41:07', 15),
(898, 23, '2019-08-05 16:44:17', 15),
(899, 8, '2019-08-04 07:10:06', 158),
(900, 7, '2019-08-04 07:10:48', 158),
(901, 25, '2019-08-04 07:13:21', 118),
(902, 24, '2019-08-04 07:15:02', 118),
(903, 23, '2019-08-04 07:15:50', 118),
(904, 12, '2019-08-04 07:17:21', 118),
(905, 27, '2019-08-04 07:17:52', 118),
(906, 26, '2019-08-04 07:18:36', 118),
(907, 2, '2019-08-04 07:24:18', 158),
(908, 26, '2019-08-04 07:26:24', 158),
(909, 24, '2019-08-04 07:27:24', 158),
(910, 12, '2019-08-04 07:28:40', 158),
(911, 16, '2019-08-04 07:31:04', 158),
(912, 23, '2019-08-04 07:32:08', 158),
(913, 27, '2019-08-04 08:26:48', 120),
(914, 26, '2019-08-04 08:29:01', 120),
(915, 25, '2019-08-04 08:29:38', 120),
(916, 24, '2019-08-04 08:31:28', 120),
(917, 8, '2019-08-06 15:56:50', 159),
(918, 7, '2019-08-06 15:57:37', 159),
(919, 2, '2019-08-06 15:58:09', 159),
(920, 27, '2019-08-04 08:46:34', 159),
(921, 8, '2019-08-04 08:47:01', 160),
(922, 26, '2019-08-04 08:47:32', 159),
(923, 25, '2019-08-04 08:48:21', 159),
(924, 23, '2019-08-04 08:49:56', 159),
(925, 16, '2019-08-04 08:51:00', 159),
(926, 24, '2019-08-04 08:52:51', 159),
(927, 12, '2019-08-04 08:53:48', 159),
(928, 25, '2019-08-04 10:04:34', 51),
(929, 27, '2019-08-04 10:18:50', 72),
(930, 25, '2019-08-04 10:19:38', 72),
(931, 27, '2019-08-04 10:20:24', 15),
(932, 25, '2019-08-04 10:22:08', 15),
(933, 25, '2019-08-04 10:57:53', 135),
(934, 25, '2019-08-04 11:00:04', 137),
(935, 25, '2019-08-04 11:20:46', 108),
(936, 27, '2019-08-04 11:28:38', 74),
(937, 26, '2019-08-04 11:29:17', 74),
(938, 25, '2019-08-04 11:29:28', 49),
(939, 25, '2019-08-04 11:30:11', 74),
(940, 25, '2019-08-04 12:53:34', 128),
(941, 25, '2019-08-04 13:13:32', 33),
(942, 27, '2019-08-04 13:21:19', 76),
(943, 26, '2019-08-04 13:21:51', 76),
(944, 25, '2019-08-04 13:23:35', 76),
(945, 27, '2019-08-04 13:26:34', 7),
(946, 26, '2019-08-05 13:47:15', 7),
(947, 24, '2019-08-05 13:48:56', 7),
(948, 23, '2019-08-05 13:49:50', 7),
(949, 27, '2019-08-04 13:42:38', 24),
(950, 26, '2019-08-05 14:11:52', 24),
(951, 24, '2019-08-05 14:15:14', 24),
(952, 23, '2019-08-05 14:35:07', 24),
(953, 12, '2019-08-04 14:20:52', 24),
(954, 26, '2019-08-04 14:28:57', 100),
(955, 27, '2019-08-04 17:29:26', 108),
(956, 9, '2019-08-06 16:28:41', 46),
(957, 8, '2019-08-04 20:44:50', 164),
(958, 7, '2019-08-04 20:47:54', 164),
(959, 2, '2019-08-04 20:48:48', 164),
(960, 27, '2019-08-04 20:50:44', 164),
(961, 26, '2019-08-04 20:51:46', 164),
(962, 24, '2019-08-04 20:53:13', 164),
(963, 26, '2019-08-04 22:18:54', 17),
(964, 9, '2019-08-05 01:23:28', 136),
(965, 9, '2019-08-05 02:54:57', 15),
(966, 27, '2019-08-05 02:56:45', 104),
(967, 26, '2019-08-05 02:57:23', 104),
(968, 12, '2019-08-05 03:03:41', 104),
(969, 24, '2019-08-05 03:04:38', 104),
(970, 9, '2019-08-06 06:45:08', 137),
(971, 8, '2019-08-05 04:50:55', 165),
(972, 7, '2019-08-05 04:51:49', 165),
(973, 2, '2019-08-05 04:52:37', 165),
(974, 27, '2019-08-05 04:53:15', 165),
(975, 26, '2019-08-05 04:54:32', 165),
(976, 24, '2019-08-05 04:55:23', 165),
(977, 23, '2019-08-05 04:59:17', 165),
(978, 16, '2019-08-05 05:00:03', 165),
(979, 12, '2019-08-05 05:00:49', 165),
(980, 9, '2019-08-08 06:47:33', 166),
(981, 12, '2019-08-05 05:23:56', 166),
(982, 16, '2019-08-05 05:26:13', 166),
(983, 8, '2019-08-08 06:43:09', 166),
(984, 7, '2019-08-08 06:45:02', 166),
(985, 26, '2019-08-05 06:48:29', 167),
(986, 8, '2019-08-08 06:39:02', 167),
(987, 7, '2019-08-08 06:40:08', 167),
(988, 2, '2019-08-08 06:42:06', 167),
(989, 27, '2019-08-05 06:52:45', 167),
(990, 24, '2019-08-05 06:53:36', 167),
(991, 23, '2019-08-05 06:55:55', 167),
(992, 8, '2019-08-07 23:19:55', 169),
(993, 7, '2019-08-07 23:21:26', 169),
(994, 2, '2019-08-07 23:24:33', 169),
(995, 27, '2019-08-05 10:13:20', 169),
(996, 26, '2019-08-05 10:15:01', 169),
(997, 24, '2019-08-05 10:16:43', 169),
(998, 23, '2019-08-05 10:19:46', 169),
(999, 16, '2019-08-05 10:20:41', 169),
(1000, 12, '2019-08-05 10:21:36', 169),
(1001, 9, '2019-08-06 21:04:24', 169),
(1002, 8, '2019-08-07 12:11:19', 170),
(1003, 7, '2019-08-07 12:12:03', 170),
(1004, 24, '2019-08-05 10:48:03', 171),
(1005, 27, '2019-08-05 10:48:55', 3),
(1006, 2, '2019-08-07 12:12:42', 170),
(1007, 27, '2019-08-05 10:52:17', 170),
(1008, 26, '2019-08-05 10:53:01', 170),
(1009, 29, '2019-08-05 10:53:06', 3),
(1010, 26, '2019-08-05 10:53:40', 3),
(1011, 12, '2019-08-05 10:54:07', 170),
(1012, 24, '2019-08-05 10:54:15', 3),
(1013, 24, '2019-08-05 10:55:28', 170),
(1014, 23, '2019-08-05 10:55:39', 3),
(1015, 23, '2019-08-05 10:58:08', 170),
(1016, 8, '2019-08-05 10:59:10', 58),
(1017, 7, '2019-08-05 10:59:43', 58),
(1018, 16, '2019-08-05 10:59:56', 170),
(1019, 2, '2019-08-05 11:00:32', 58),
(1020, 29, '2019-08-05 11:01:48', 170),
(1021, 29, '2019-08-05 11:03:47', 21),
(1022, 29, '2019-08-05 11:06:14', 58),
(1023, 27, '2019-08-05 11:06:47', 58),
(1024, 26, '2019-08-05 11:07:22', 58),
(1025, 24, '2019-08-05 11:08:08', 58),
(1026, 23, '2019-08-05 11:10:22', 58),
(1027, 16, '2019-08-05 11:10:51', 58),
(1028, 12, '2019-08-05 11:11:21', 58),
(1029, 2, '2019-08-05 11:16:20', 173),
(1030, 8, '2019-08-05 11:24:02', 171),
(1031, 7, '2019-08-05 11:24:59', 171),
(1032, 2, '2019-08-05 11:25:42', 171),
(1033, 29, '2019-08-05 11:26:12', 171),
(1034, 26, '2019-08-05 11:26:45', 171),
(1035, 23, '2019-08-05 11:28:27', 171),
(1036, 29, '2019-08-05 11:28:31', 143),
(1037, 16, '2019-08-05 11:29:11', 171),
(1038, 12, '2019-08-05 11:30:30', 171),
(1039, 29, '2019-08-05 11:39:47', 117),
(1040, 29, '2019-08-05 11:57:45', 47),
(1041, 9, '2019-08-05 11:58:24', 47),
(1042, 8, '2019-08-05 12:03:14', 174),
(1043, 7, '2019-08-05 12:04:52', 174),
(1044, 2, '2019-08-05 12:06:15', 174),
(1045, 29, '2019-08-05 12:07:51', 174),
(1046, 26, '2019-08-05 12:10:11', 174),
(1047, 24, '2019-08-05 12:11:02', 174),
(1048, 23, '2019-08-05 12:12:09', 174),
(1049, 16, '2019-08-05 12:13:13', 174),
(1050, 12, '2019-08-05 12:14:38', 174),
(1051, 29, '2019-08-05 12:39:28', 108),
(1052, 29, '2019-08-05 12:49:06', 24),
(1053, 29, '2019-08-05 13:17:35', 72),
(1054, 29, '2019-08-05 13:28:09', 33),
(1055, 29, '2019-08-05 13:32:24', 137),
(1056, 29, '2019-08-05 13:36:07', 148),
(1057, 8, '2019-08-05 13:41:06', 175),
(1058, 7, '2019-08-05 13:42:00', 175),
(1059, 2, '2019-08-05 13:44:02', 175),
(1060, 29, '2019-08-05 13:46:32', 7),
(1061, 29, '2019-08-05 14:00:08', 175),
(1062, 26, '2019-08-05 14:00:56', 175),
(1063, 24, '2019-08-05 14:01:34', 175),
(1064, 23, '2019-08-05 14:04:21', 175),
(1065, 16, '2019-08-05 14:05:04', 175),
(1066, 29, '2019-08-05 14:24:16', 46),
(1067, 8, '2019-08-08 05:39:52', 176),
(1068, 7, '2019-08-08 05:48:18', 176),
(1069, 2, '2019-08-08 05:48:55', 176),
(1070, 29, '2019-08-05 14:55:34', 176),
(1071, 26, '2019-08-05 14:56:33', 176),
(1072, 24, '2019-08-05 14:57:40', 176),
(1073, 23, '2019-08-05 14:59:27', 176),
(1074, 16, '2019-08-05 15:00:42', 176),
(1075, 9, '2019-08-08 10:14:08', 176),
(1076, 8, '2019-08-06 18:32:54', 178),
(1077, 7, '2019-08-06 18:53:39', 178),
(1078, 2, '2019-08-06 18:55:27', 178),
(1079, 29, '2019-08-05 15:32:16', 178),
(1080, 24, '2019-08-05 15:32:47', 178),
(1081, 8, '2019-08-07 17:27:29', 179),
(1082, 7, '2019-08-07 17:28:25', 179),
(1083, 2, '2019-08-07 17:32:41', 179),
(1084, 24, '2019-08-05 15:57:53', 179),
(1085, 23, '2019-08-05 15:59:10', 179),
(1086, 8, '2019-08-07 16:01:28', 90),
(1087, 24, '2019-08-05 16:16:45', 90),
(1088, 23, '2019-08-05 16:18:12', 90),
(1089, 9, '2019-08-07 22:55:36', 90),
(1090, 9, '2019-08-07 02:49:16', 179),
(1091, 7, '2019-08-05 19:55:16', 2),
(1092, 24, '2019-08-05 19:57:00', 2),
(1093, 23, '2019-08-05 19:57:46', 2),
(1094, 8, '2019-08-07 00:01:22', 181),
(1095, 7, '2019-08-07 00:02:17', 181),
(1096, 2, '2019-08-07 00:03:30', 181),
(1097, 24, '2019-08-05 20:36:18', 181),
(1098, 24, '2019-08-05 21:18:57', 70),
(1099, 23, '2019-08-05 21:19:37', 70),
(1100, 24, '2019-08-05 22:25:17', 80),
(1101, 8, '2019-08-08 10:09:51', 182),
(1102, 8, '2019-08-08 08:10:43', 183),
(1103, 7, '2019-08-08 10:10:52', 182),
(1104, 7, '2019-08-08 08:11:53', 183),
(1105, 2, '2019-08-08 10:11:59', 182),
(1106, 24, '2019-08-05 23:42:39', 182),
(1107, 2, '2019-08-08 08:12:57', 183),
(1108, 8, '2019-08-06 08:29:56', 184),
(1109, 7, '2019-08-06 08:31:31', 184),
(1110, 2, '2019-08-06 08:34:55', 184),
(1111, 9, '2019-08-06 08:36:06', 184),
(1112, 8, '2019-08-06 08:36:55', 185),
(1113, 7, '2019-08-06 08:38:00', 185),
(1114, 2, '2019-08-06 08:40:44', 185),
(1115, 9, '2019-08-08 11:13:56', 51),
(1116, 8, '2019-08-06 09:54:13', 186),
(1117, 7, '2019-08-06 09:54:57', 186),
(1118, 2, '2019-08-06 09:55:49', 186),
(1119, 9, '2019-08-06 09:56:38', 186),
(1120, 8, '2019-08-06 10:30:45', 187),
(1121, 7, '2019-08-06 10:31:46', 187),
(1122, 2, '2019-08-06 10:33:33', 187),
(1123, 8, '2019-08-06 10:44:03', 188),
(1124, 7, '2019-08-06 10:44:54', 188),
(1125, 2, '2019-08-06 10:45:46', 188),
(1126, 9, '2019-08-06 10:51:25', 188),
(1127, 8, '2019-08-07 17:00:43', 190),
(1128, 7, '2019-08-07 17:01:54', 190),
(1129, 2, '2019-08-08 00:24:46', 190),
(1130, 31, '2019-08-06 16:33:20', 46),
(1131, 31, '2019-08-06 17:09:19', 179),
(1132, 31, '2019-08-06 17:18:53', 129),
(1133, 31, '2019-08-06 17:50:09', 190),
(1134, 31, '2019-08-06 17:51:00', 7),
(1135, 31, '2019-08-06 18:36:01', 153),
(1136, 31, '2019-08-06 18:37:16', 137),
(1137, 31, '2019-08-06 18:54:41', 178),
(1138, 9, '2019-08-06 18:56:00', 178),
(1139, 31, '2019-08-06 19:20:16', 21),
(1140, 31, '2019-08-06 20:13:20', 169),
(1141, 31, '2019-08-06 20:48:23', 33),
(1142, 31, '2019-08-06 20:54:01', 77),
(1143, 31, '2019-08-06 20:57:22', 100),
(1144, 31, '2019-08-06 21:27:05', 128),
(1145, 31, '2019-08-06 21:33:40', 76),
(1146, 31, '2019-08-07 00:04:30', 181),
(1147, 31, '2019-08-07 00:27:52', 182),
(1148, 9, '2019-08-07 00:28:49', 182),
(1149, 31, '2019-08-07 01:06:54', 49),
(1150, 31, '2019-08-07 01:27:29', 188),
(1151, 8, '2019-08-07 01:43:37', 192),
(1152, 7, '2019-08-07 01:46:19', 192),
(1153, 2, '2019-08-07 01:47:41', 192),
(1154, 31, '2019-08-07 01:48:41', 192),
(1155, 9, '2019-08-07 02:01:51', 192),
(1156, 31, '2019-08-07 03:21:00', 183),
(1157, 31, '2019-08-07 04:41:08', 176),
(1158, 8, '2019-08-07 05:57:10', 32),
(1159, 31, '2019-08-07 06:00:54', 32),
(1160, 31, '2019-08-07 06:32:08', 47),
(1161, 8, '2019-08-07 07:33:52', 193),
(1162, 7, '2019-08-07 07:40:17', 193),
(1163, 31, '2019-08-07 07:50:05', 72),
(1164, 31, '2019-08-07 08:01:36', 120),
(1165, 31, '2019-08-07 08:09:40', 94),
(1166, 31, '2019-08-07 09:02:34', 51),
(1167, 8, '2019-08-07 11:58:00', 194),
(1168, 7, '2019-08-07 11:59:54', 194),
(1169, 2, '2019-08-07 12:00:44', 194),
(1170, 8, '2019-08-07 12:10:55', 195),
(1171, 8, '2019-08-07 12:11:26', 196),
(1172, 7, '2019-08-07 12:12:07', 196),
(1173, 7, '2019-08-07 12:12:24', 195),
(1174, 2, '2019-08-07 12:12:47', 196),
(1175, 7, '2019-08-07 12:15:50', 197),
(1176, 2, '2019-08-07 12:16:59', 197),
(1177, 9, '2019-08-07 12:29:00', 196),
(1178, 34, '2019-08-07 12:39:03', 33),
(1179, 34, '2019-08-07 12:40:18', 182),
(1180, 8, '2019-08-07 14:28:12', 198),
(1181, 7, '2019-08-07 14:37:11', 198),
(1182, 2, '2019-08-07 14:38:00', 198),
(1183, 35, '2019-08-07 15:46:52', 183),
(1184, 9, '2019-08-07 15:53:46', 183),
(1185, 35, '2019-08-07 16:00:53', 90),
(1186, 35, '2019-08-07 16:16:28', 23),
(1187, 35, '2019-08-07 16:17:08', 100),
(1188, 35, '2019-08-07 16:20:28', 76),
(1189, 35, '2019-08-07 16:23:17', 21),
(1190, 9, '2019-08-07 16:23:30', 76),
(1191, 35, '2019-08-07 16:29:58', 199),
(1192, 8, '2019-08-07 16:30:49', 199),
(1193, 35, '2019-08-07 16:31:16', 169),
(1194, 7, '2019-08-07 16:31:40', 199),
(1195, 2, '2019-08-07 16:33:56', 199),
(1196, 9, '2019-08-07 16:35:20', 199),
(1197, 35, '2019-08-07 16:36:16', 94),
(1198, 35, '2019-08-07 16:48:42', 128),
(1199, 35, '2019-08-07 16:56:19', 131),
(1200, 35, '2019-08-07 16:58:00', 70),
(1201, 35, '2019-08-07 16:59:50', 190),
(1202, 35, '2019-08-07 17:05:43', 200),
(1203, 8, '2019-08-07 17:06:17', 200),
(1204, 7, '2019-08-07 17:07:05', 200),
(1205, 2, '2019-08-07 17:07:57', 200),
(1206, 35, '2019-08-07 17:20:46', 97),
(1207, 8, '2019-08-07 17:21:34', 97),
(1208, 35, '2019-08-07 17:26:41', 179),
(1209, 35, '2019-08-07 18:11:17', 118),
(1210, 9, '2019-08-07 18:15:09', 118),
(1211, 35, '2019-08-07 18:22:24', 201),
(1212, 8, '2019-08-07 18:23:44', 201),
(1213, 35, '2019-08-07 18:41:34', 153),
(1214, 35, '2019-08-07 18:42:53', 137),
(1215, 4, '2019-08-07 18:51:05', 23),
(1216, 4, '2019-08-07 19:13:21', 169),
(1217, 35, '2019-08-07 19:25:27', 81),
(1218, 9, '2019-08-07 19:29:14', 81),
(1219, 35, '2019-08-07 21:00:13', 33),
(1220, 35, '2019-08-07 21:24:24', 192),
(1221, 35, '2019-08-07 22:59:10', 202),
(1222, 9, '2019-08-07 23:01:08', 202),
(1223, 2, '2019-08-07 23:01:41', 202),
(1224, 8, '2019-08-07 23:02:09', 202),
(1225, 7, '2019-08-07 23:02:40', 202),
(1226, 35, '2019-08-07 23:05:31', 181),
(1227, 35, '2019-08-07 23:13:04', 46),
(1228, 35, '2019-08-08 00:13:32', 203),
(1229, 8, '2019-08-08 00:14:40', 203),
(1230, 7, '2019-08-08 00:15:42', 203),
(1231, 2, '2019-08-08 00:17:36', 203),
(1232, 35, '2019-08-08 01:46:43', 121),
(1233, 35, '2019-08-08 02:07:20', 104),
(1234, 2, '2019-08-08 06:46:18', 166),
(1235, 9, '2019-08-08 12:10:03', 97);

-- --------------------------------------------------------

--
-- Структура таблицы `db_statday`
--
-- Создание: Авг 08 2019 г., 09:34
-- Последнее обновление: Авг 08 2019 г., 09:34
--

DROP TABLE IF EXISTS `db_statday`;
CREATE TABLE `db_statday` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `time` int(25) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_statday`
--

INSERT INTO `db_statday` (`ip`, `time`) VALUES
('103.26.81.29', 1565211629),
('178.155.4.55', 1565256691),
('95.173.83.164', 1565256614),
('185.112.102.105', 1565256603),
('46.166.142.221', 1565256590),
('39.48.31.255', 1565256548),
('188.138.144.114', 1565256529),
('82.131.189.83', 1565256400),
('37.54.30.98', 1565256317),
('31.163.26.73', 1565256297),
('91.211.246.91', 1565256507),
('176.59.211.142', 1565256167),
('185.104.251.92', 1565256699),
('185.125.33.83', 1565256018),
('85.140.7.90', 1565255954),
('37.212.49.123', 1565255879),
('193.124.89.166', 1565256445),
('85.173.130.237', 1565255598),
('194.58.119.130', 1565256703),
('80.79.124.155', 1565256627),
('178.49.4.243', 1565255979),
('77.222.117.192', 1565255220),
('5.165.234.249', 1565254791),
('188.165.136.110', 1565256552),
('2.93.50.211', 1565254697),
('84.110.232.20', 1565254451),
('37.140.199.205', 1565254310),
('188.165.146.192', 1565256033),
('61.2.170.227', 1565254227),
('46.0.92.1', 1565254372),
('34.230.89.47', 1565254159),
('46.147.112.14', 1565254112),
('107.178.40.242', 1565254051),
('95.78.249.172', 1565254006),
('188.165.146.195', 1565253971),
('91.240.84.88', 1565255770),
('92.222.249.48', 1565254309),
('134.0.118.129', 1565255833),
('176.126.242.212', 1565254700),
('193.0.203.24', 1565254958),
('109.185.185.112', 1565253600),
('90.143.156.209', 1565253423),
('113.182.193.89', 1565253398),
('193.124.202.141', 1565255358),
('176.126.242.251', 1565253532),
('62.213.74.50', 1565253119),
('27.109.17.226', 1565255419),
('34.229.82.130', 1565253354),
('178.16.129.27', 1565252759),
('213.230.85.213', 1565252726),
('31.132.178.221', 1565251785),
('188.190.101.8', 1565252078),
('178.186.216.192', 1565251505),
('89.151.186.60', 1565251448),
('77.43.174.245', 1565251372),
('113.181.237.78', 1565251318),
('213.87.225.180', 1565250732),
('77.111.247.74', 1565250582),
('178.123.208.187', 1565256757),
('178.121.17.140', 1565249867),
('95.132.134.82', 1565249853),
('109.254.192.133', 1565249071),
('94.51.214.85', 1565249020),
('185.193.205.182', 1565248220),
('91.235.185.50', 1565248416),
('54.39.100.61', 1565247334),
('178.46.69.21', 1565253426),
('62.182.29.102', 1565247091),
('37.252.91.3', 1565246958),
('5.143.243.172', 1565246392),
('176.59.146.103', 1565246901),
('110.225.2.244', 1565245838),
('81.95.185.17', 1565245763),
('95.104.243.246', 1565245431),
('46.151.240.228', 1565244622),
('178.128.0.34', 1565244613),
('5.62.19.64', 1565244427),
('171.255.75.242', 1565244364),
('94.232.23.127', 1565244071),
('46.10.26.164', 1565243969),
('178.120.46.166', 1565243301),
('202.67.36.193', 1565243404),
('83.220.237.251', 1565242697),
('213.230.79.140', 1565242516),
('92.55.54.56', 1565241596),
('171.6.243.52', 1565241024),
('178.211.162.231', 1565253548),
('104.248.13.0', 1565241636),
('87.249.249.10', 1565240769),
('109.104.164.143', 1565240378),
('207.46.13.68', 1565240182),
('176.59.44.101', 1565239411),
('188.163.20.52', 1565238956),
('178.213.104.138', 1565238932),
('188.162.194.228', 1565238861),
('178.89.70.110', 1565238640),
('5.166.21.27', 1565238605),
('186.73.237.209', 1565238157),
('37.79.222.90', 1565237643),
('188.68.48.243', 1565237577),
('188.19.33.183', 1565237372),
('117.2.64.128', 1565236848),
('85.140.4.208', 1565244568),
('95.128.163.99', 1565235685),
('182.185.134.100', 1565235565),
('14.181.216.113', 1565235779),
('220.132.107.126', 1565235273),
('176.59.196.119', 1565236168),
('95.163.255.59', 1565234519),
('95.163.255.54', 1565234517),
('188.225.75.122', 1565234580),
('95.129.178.29', 1565254747),
('38.145.115.205', 1565234231),
('14.245.152.39', 1565234003),
('178.205.8.122', 1565233411),
('138.36.78.42', 1565233094),
('77.222.101.91', 1565232568),
('178.129.28.149', 1565232432),
('58.187.163.216', 1565232571),
('188.0.131.214', 1565255631),
('103.221.246.206', 1565232032),
('39.36.205.32', 1565232032),
('190.206.84.243', 1565231714),
('94.233.244.241', 1565231677),
('46.211.93.55', 1565231697),
('213.230.93.63', 1565231674),
('94.241.220.21', 1565231701),
('94.231.136.137', 1565231667),
('185.71.65.92', 1565231224),
('109.252.50.202', 1565231176),
('14.160.52.246', 1565248493),
('188.170.82.143', 1565255873),
('176.59.109.123', 1565230350),
('46.71.115.127', 1565228855),
('54.91.247.26', 1565253974),
('103.84.149.222', 1565227517),
('54.173.157.32', 1565253387),
('18.234.83.71', 1565227359),
('208.80.194.41', 1565227022),
('176.221.166.150', 1565226859),
('190.202.248.247', 1565225888),
('42.118.12.247', 1565244161),
('89.234.68.103', 1565225589),
('176.59.130.216', 1565225321),
('100.25.188.196', 1565225222),
('46.235.72.66', 1565225138),
('36.71.246.170', 1565224815),
('191.101.212.189', 1565224203),
('141.8.132.25', 1565224002),
('24.243.152.254', 1565223579),
('198.58.107.211', 1565223365),
('37.9.113.33', 1565223336),
('185.54.239.180', 1565223317),
('46.0.59.195', 1565223271),
('171.6.243.76', 1565222492),
('201.209.171.162', 1565222658),
('148.251.177.36', 1565222103),
('188.225.75.249', 1565222103),
('66.249.64.93', 1565219723),
('95.69.144.96', 1565219746),
('95.163.36.18', 1565218623),
('171.234.123.182', 1565220590),
('93.124.27.8', 1565217848),
('31.162.25.101', 1565218698),
('95.47.46.231', 1565217759),
('193.106.161.86', 1565217735),
('176.59.49.90', 1565216877),
('109.110.95.230', 1565216105),
('157.46.125.105', 1565216075),
('46.4.61.205', 1565237306),
('190.207.69.179', 1565215359),
('86.126.212.234', 1565215227),
('95.26.189.69', 1565228256),
('78.84.155.35', 1565256664),
('95.163.36.19', 1565214367),
('95.163.36.12', 1565214361),
('176.36.135.131', 1565214339),
('46.45.201.137', 1565214281),
('109.252.36.180', 1565253999),
('109.252.90.198', 1565213452),
('212.3.142.163', 1565212937),
('89.22.145.250', 1565212905),
('46.146.100.52', 1565213818),
('59.13.123.221', 1565212548),
('188.163.27.50', 1565212380),
('37.212.210.33', 1565212866),
('217.54.48.139', 1565211954),
('188.170.196.54', 1565211725),
('2.93.229.223', 1565211655);

-- --------------------------------------------------------

--
-- Структура таблицы `db_statonline`
--
-- Создание: Авг 08 2019 г., 09:34
-- Последнее обновление: Авг 08 2019 г., 09:34
--

DROP TABLE IF EXISTS `db_statonline`;
CREATE TABLE `db_statonline` (
  `user` int(11) NOT NULL DEFAULT '0',
  `away` int(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `db_statonline`
--

INSERT INTO `db_statonline` (`user`, `away`) VALUES
(84, 1565256664),
(17, 1565256757);

-- --------------------------------------------------------

--
-- Структура таблицы `db_stats`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_stats`;
CREATE TABLE `db_stats` (
  `id` int(11) NOT NULL,
  `all_users` int(11) NOT NULL DEFAULT '0',
  `all_payments` double NOT NULL DEFAULT '0',
  `all_insert` double NOT NULL DEFAULT '0',
  `donations` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_stats_btree`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_stats_btree`;
CREATE TABLE `db_stats_btree` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL DEFAULT '',
  `tree_name` varchar(10) NOT NULL DEFAULT '',
  `amount` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_swap_ser`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_swap_ser`;
CREATE TABLE `db_swap_ser` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL DEFAULT '',
  `amount_b` double NOT NULL DEFAULT '0',
  `amount_p` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_users_a`
--
-- Создание: Авг 08 2019 г., 09:36
-- Последнее обновление: Авг 08 2019 г., 09:36
-- Последняя проверка: Авг 08 2019 г., 09:36
--

DROP TABLE IF EXISTS `db_users_a`;
CREATE TABLE `db_users_a` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `pass` varchar(33) NOT NULL DEFAULT '',
  `referer` varchar(10) NOT NULL DEFAULT '',
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `referals` int(11) NOT NULL DEFAULT '0',
  `date_reg` int(11) NOT NULL DEFAULT '0',
  `date_login` int(11) NOT NULL DEFAULT '0',
  `ip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `ava` varchar(255) NOT NULL DEFAULT '',
  `chat_moder` int(1) NOT NULL DEFAULT '0',
  `ban_chat` int(1) NOT NULL DEFAULT '0',
  `plat_pass` varchar(55) NOT NULL,
  `hide` varchar(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_users_b`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:36
--

DROP TABLE IF EXISTS `db_users_b`;
CREATE TABLE `db_users_b` (
  `id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL DEFAULT '',
  `money_b` double NOT NULL DEFAULT '0',
  `money_p` double NOT NULL DEFAULT '0',
  `a_t` int(11) NOT NULL DEFAULT '0',
  `b_t` int(11) NOT NULL DEFAULT '0',
  `c_t` int(11) NOT NULL DEFAULT '0',
  `d_t` int(11) NOT NULL DEFAULT '0',
  `e_t` int(11) NOT NULL DEFAULT '0',
  `a_b` int(11) NOT NULL DEFAULT '0',
  `b_b` int(11) NOT NULL DEFAULT '0',
  `c_b` int(11) NOT NULL DEFAULT '0',
  `d_b` int(11) NOT NULL DEFAULT '0',
  `e_b` int(11) NOT NULL DEFAULT '0',
  `all_time_a` int(11) NOT NULL DEFAULT '0',
  `all_time_b` int(11) NOT NULL DEFAULT '0',
  `all_time_c` int(11) NOT NULL DEFAULT '0',
  `all_time_d` int(11) NOT NULL DEFAULT '0',
  `all_time_e` int(11) NOT NULL DEFAULT '0',
  `last_sbor` int(11) NOT NULL DEFAULT '0',
  `from_referals` double NOT NULL DEFAULT '0',
  `to_referer` double NOT NULL DEFAULT '0',
  `payment_sum` double NOT NULL DEFAULT '0',
  `insert_sum` double NOT NULL DEFAULT '0',
  `chat` int(11) NOT NULL DEFAULT '0',
  `chat_money` double(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `db_users_purse`
--
-- Создание: Авг 08 2019 г., 09:35
-- Последнее обновление: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `db_users_purse`;
CREATE TABLE `db_users_purse` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `system` varchar(30) NOT NULL,
  `purse` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wmrush_pin`
--
-- Создание: Авг 08 2019 г., 09:35
--

DROP TABLE IF EXISTS `wmrush_pin`;
CREATE TABLE `wmrush_pin` (
  `id` int(11) NOT NULL,
  `pin` varchar(55) NOT NULL,
  `summa` double NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `db_advpic`
--
ALTER TABLE `db_advpic`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_bonus_list`
--
ALTER TABLE `db_bonus_list`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_bonus_list3`
--
ALTER TABLE `db_bonus_list3`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_bonus_list4`
--
ALTER TABLE `db_bonus_list4`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_bonus_list5`
--
ALTER TABLE `db_bonus_list5`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_bonus_list6`
--
ALTER TABLE `db_bonus_list6`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_chat_message`
--
ALTER TABLE `db_chat_message`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_chat_online`
--
ALTER TABLE `db_chat_online`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_competition`
--
ALTER TABLE `db_competition`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_competition_users`
--
ALTER TABLE `db_competition_users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_conabrul`
--
ALTER TABLE `db_conabrul`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_config`
--
ALTER TABLE `db_config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_games_coinflip`
--
ALTER TABLE `db_games_coinflip`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_games_kamikadze`
--
ALTER TABLE `db_games_kamikadze`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_games_knb`
--
ALTER TABLE `db_games_knb`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_insert_money`
--
ALTER TABLE `db_insert_money`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_investors`
--
ALTER TABLE `db_investors`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_investors_users`
--
ALTER TABLE `db_investors_users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_lottery`
--
ALTER TABLE `db_lottery`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_lottery_winners`
--
ALTER TABLE `db_lottery_winners`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_mails`
--
ALTER TABLE `db_mails`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_mails_view`
--
ALTER TABLE `db_mails_view`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_news`
--
ALTER TABLE `db_news`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_payeer_insert`
--
ALTER TABLE `db_payeer_insert`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_payment`
--
ALTER TABLE `db_payment`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_recovery`
--
ALTER TABLE `db_recovery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip` (`ip`);

--
-- Индексы таблицы `db_regkey`
--
ALTER TABLE `db_regkey`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `db_sell_items`
--
ALTER TABLE `db_sell_items`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_sender`
--
ALTER TABLE `db_sender`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_serfing`
--
ALTER TABLE `db_serfing`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_serfingb`
--
ALTER TABLE `db_serfingb`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_serfingb_view`
--
ALTER TABLE `db_serfingb_view`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_serfingy`
--
ALTER TABLE `db_serfingy`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_serfingy_view`
--
ALTER TABLE `db_serfingy_view`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_serfing_view`
--
ALTER TABLE `db_serfing_view`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_stats`
--
ALTER TABLE `db_stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_stats_btree`
--
ALTER TABLE `db_stats_btree`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_swap_ser`
--
ALTER TABLE `db_swap_ser`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_users_a`
--
ALTER TABLE `db_users_a`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `ip` (`ip`);

--
-- Индексы таблицы `db_users_b`
--
ALTER TABLE `db_users_b`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `db_users_purse`
--
ALTER TABLE `db_users_purse`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `wmrush_pin`
--
ALTER TABLE `wmrush_pin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `db_advpic`
--
ALTER TABLE `db_advpic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_bonus_list`
--
ALTER TABLE `db_bonus_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=330;

--
-- AUTO_INCREMENT для таблицы `db_bonus_list3`
--
ALTER TABLE `db_bonus_list3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=799;

--
-- AUTO_INCREMENT для таблицы `db_bonus_list4`
--
ALTER TABLE `db_bonus_list4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=316;

--
-- AUTO_INCREMENT для таблицы `db_bonus_list5`
--
ALTER TABLE `db_bonus_list5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=296;

--
-- AUTO_INCREMENT для таблицы `db_bonus_list6`
--
ALTER TABLE `db_bonus_list6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT для таблицы `db_chat_message`
--
ALTER TABLE `db_chat_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_chat_online`
--
ALTER TABLE `db_chat_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_competition`
--
ALTER TABLE `db_competition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `db_competition_users`
--
ALTER TABLE `db_competition_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_conabrul`
--
ALTER TABLE `db_conabrul`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `db_config`
--
ALTER TABLE `db_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `db_games_coinflip`
--
ALTER TABLE `db_games_coinflip`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_games_kamikadze`
--
ALTER TABLE `db_games_kamikadze`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_games_knb`
--
ALTER TABLE `db_games_knb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_insert_money`
--
ALTER TABLE `db_insert_money`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT для таблицы `db_investors`
--
ALTER TABLE `db_investors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_investors_users`
--
ALTER TABLE `db_investors_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_lottery`
--
ALTER TABLE `db_lottery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `db_lottery_winners`
--
ALTER TABLE `db_lottery_winners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `db_mails`
--
ALTER TABLE `db_mails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `db_mails_view`
--
ALTER TABLE `db_mails_view`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `db_news`
--
ALTER TABLE `db_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_payeer_insert`
--
ALTER TABLE `db_payeer_insert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT для таблицы `db_payment`
--
ALTER TABLE `db_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `db_recovery`
--
ALTER TABLE `db_recovery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `db_regkey`
--
ALTER TABLE `db_regkey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=284;

--
-- AUTO_INCREMENT для таблицы `db_sell_items`
--
ALTER TABLE `db_sell_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_sender`
--
ALTER TABLE `db_sender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `db_serfing`
--
ALTER TABLE `db_serfing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT для таблицы `db_serfingb`
--
ALTER TABLE `db_serfingb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `db_serfingb_view`
--
ALTER TABLE `db_serfingb_view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=365;

--
-- AUTO_INCREMENT для таблицы `db_serfingy`
--
ALTER TABLE `db_serfingy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `db_serfingy_view`
--
ALTER TABLE `db_serfingy_view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT для таблицы `db_serfing_view`
--
ALTER TABLE `db_serfing_view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1236;

--
-- AUTO_INCREMENT для таблицы `db_stats`
--
ALTER TABLE `db_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_stats_btree`
--
ALTER TABLE `db_stats_btree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_swap_ser`
--
ALTER TABLE `db_swap_ser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_users_a`
--
ALTER TABLE `db_users_a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `db_users_purse`
--
ALTER TABLE `db_users_purse`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wmrush_pin`
--
ALTER TABLE `wmrush_pin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
