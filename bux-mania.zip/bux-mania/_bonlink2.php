<center>
<table>
    <tr>
        <td align="center" width="46%"><div id="linkslot_247746"><script src="https://linkslot.ru/bancode.php?id=247746" async></script></div></td>
        <td align="center" width="8%"></td>
        <td align="center" width="46%"><div id="linkslot_247747"><script src="https://linkslot.ru/bancode.php?id=247747" async></script></div></td>
    </tr>
</table>
</center>